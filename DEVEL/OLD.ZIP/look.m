
[h,d,nt,nr]=dio2mat('weight.ddd');
time=(0:h(5,1)-1)*h(9,1)/1000;

figure(1); clg; orient landscape; 
for i=1:6, 
  subplot(2,3,i); plot(d(:,i),'k'); 
  title(['channel ' num2str(i)],'fontsize',7)  ;
  set(gca,'fontsize',7);
  %axis([0 20 -60 60]);
end;

figure(2); clg; orient landscape; 
for i=7:12, 
  subplot(2,3,i-6); plot(d(:,i),'k'); 
  title(['channel ' num2str(i-6)],'fontsize',7)  ;
  set(gca,'fontsize',7);
  %axis([0 20 -60 60]);
end;

