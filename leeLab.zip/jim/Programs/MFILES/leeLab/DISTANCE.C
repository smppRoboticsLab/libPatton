static char mc_version[] = "MATLAB Compiler 1.2 Jan 17 1998 infun";
/*
 *  MATLAB Compiler: 1.2
 *  Date: Jan 17 1998
 *  Arguments: distance 
 */
#ifndef ARRAY_ACCESS_INLINING
#error You must use the -inline option when compiling MATLAB compiler generated code with MEX or MBUILD
#endif
#ifndef MATLAB_COMPILER_GENERATED_CODE
#define MATLAB_COMPILER_GENERATED_CODE
#endif

#include <math.h>
#include "mex.h"
#include "mcc.h"

/***************** Compiler Assumptions ****************
 *
 *       CM0_        	complex vector/matrix temporary
 *       CM1_        	complex vector/matrix temporary
 *       CM2_        	complex vector/matrix temporary
 *       CM3_        	complex vector/matrix temporary
 *       CM4_        	complex vector/matrix temporary
 *       d           	complex vector/matrix
 *       dist        	complex vector/matrix
 *       distance    	<function being defined>
 *       l           	complex scalar
 *       mean        	<function>
 *       prox        	complex vector/matrix
 *       sqrt        	<function>
 *       xd          	complex vector/matrix
 *       yd          	complex vector/matrix
 *******************************************************/

void
mexFunction(
    int nlhs_,
    mxArray *plhs_[],
    int nrhs_,
    const mxArray *prhs_[]
)
{
   int ci_;
   int i_;
   mxArray *Mplhs_[1];
   mxArray *Mprhs_[1];
   

   if (nrhs_ > 2 )
   {
      mexErrMsgTxt( "Too many input arguments." );
   }

   if (nlhs_ > 1 )
   {
      mexErrMsgTxt( "Too many output arguments." );
   }

   for (ci_=i_=0; i_<nrhs_; ++i_)
   {
      if ( mccPI(prhs_[i_]) )
      {
         ci_ = 1;
         break;
      }
   }
   if (ci_)
   {
      double l_r=0.0, l_i=0.0;
      mxArray dist;
      mxArray prox;
      mxArray xd;
      mxArray yd;
      mxArray d;
      mxArray CM0_;
      mxArray CM1_;
      mxArray CM2_;
      mxArray CM3_;
      mxArray CM4_;
      
      mccComplexInit(dist);
      mccImport(&dist, ((nrhs_>0) ? prhs_[0] : 0), 0, 0);
      mccComplexInit(prox);
      mccImport(&prox, ((nrhs_>1) ? prhs_[1] : 0), 0, 0);
      mccComplexInit(xd);
      mccComplexInit(yd);
      mccComplexInit(d);
      mccComplexInit(CM0_);
      mccComplexInit(CM1_);
      mccComplexInit(CM2_);
      mccComplexInit(CM3_);
      mccComplexInit(CM4_);
      
      
      /* xd=[dist(:,1) prox(:,1)]; */
      if(mccNOTSET(&dist))
      {
         mexErrMsgTxt( "variable dist undefined, line 7" );
      }
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_CM0_;
         int I_CM0_=1;
         double *q_CM0_;
         double *p_dist;
         int I_dist=1, J_dist;
         double *q_dist;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&dist), 1);
         mccAllocateMatrix(&CM0_, m_, n_);
         mccCheckMatrixSize(&dist, mccM(&dist), 1);
         I_CM0_ = (mccM(&CM0_) != 1 || mccN(&CM0_) != 1);
         p_CM0_ = mccPR(&CM0_);
         q_CM0_ = mccPI(&CM0_);
         if (mccM(&dist) == 1) { I_dist = J_dist = 0;}
         else { I_dist = 1; J_dist=mccM(&dist)-m_; }
         p_dist = mccPR(&dist) + 0 + mccM(&dist) * (1-1);
         q_dist = mccPI(&dist) + 0 + mccM(&dist) * (1-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_dist += J_dist, q_dist += J_dist)
            {
               for (i_=0; i_<m_; ++i_, p_CM0_+=I_CM0_, q_CM0_+=I_CM0_, p_dist+=I_dist, q_dist+=I_dist)
               {
                  *p_CM0_ = *p_dist;
                  *q_CM0_ = *q_dist;
               }
            }
         }
      }
      if(mccNOTSET(&prox))
      {
         mexErrMsgTxt( "variable prox undefined, line 7" );
      }
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_CM1_;
         int I_CM1_=1;
         double *q_CM1_;
         double *p_prox;
         int I_prox=1, J_prox;
         double *q_prox;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&prox), 1);
         mccAllocateMatrix(&CM1_, m_, n_);
         mccCheckMatrixSize(&prox, mccM(&prox), 1);
         I_CM1_ = (mccM(&CM1_) != 1 || mccN(&CM1_) != 1);
         p_CM1_ = mccPR(&CM1_);
         q_CM1_ = mccPI(&CM1_);
         if (mccM(&prox) == 1) { I_prox = J_prox = 0;}
         else { I_prox = 1; J_prox=mccM(&prox)-m_; }
         p_prox = mccPR(&prox) + 0 + mccM(&prox) * (1-1);
         q_prox = mccPI(&prox) + 0 + mccM(&prox) * (1-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_prox += J_prox, q_prox += J_prox)
            {
               for (i_=0; i_<m_; ++i_, p_CM1_+=I_CM1_, q_CM1_+=I_CM1_, p_prox+=I_prox, q_prox+=I_prox)
               {
                  *p_CM1_ = *p_prox;
                  *q_CM1_ = *q_prox;
               }
            }
         }
      }
      mccCatenateColumns(&xd, &CM0_, &CM1_);
      /* yd=[dist(:,2) prox(:,2)]; */
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_CM1_;
         int I_CM1_=1;
         double *q_CM1_;
         double *p_dist;
         int I_dist=1, J_dist;
         double *q_dist;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&dist), 1);
         mccAllocateMatrix(&CM1_, m_, n_);
         mccCheckMatrixSize(&dist, mccM(&dist), 2);
         I_CM1_ = (mccM(&CM1_) != 1 || mccN(&CM1_) != 1);
         p_CM1_ = mccPR(&CM1_);
         q_CM1_ = mccPI(&CM1_);
         if (mccM(&dist) == 1) { I_dist = J_dist = 0;}
         else { I_dist = 1; J_dist=mccM(&dist)-m_; }
         p_dist = mccPR(&dist) + 0 + mccM(&dist) * (2-1);
         q_dist = mccPI(&dist) + 0 + mccM(&dist) * (2-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_dist += J_dist, q_dist += J_dist)
            {
               for (i_=0; i_<m_; ++i_, p_CM1_+=I_CM1_, q_CM1_+=I_CM1_, p_dist+=I_dist, q_dist+=I_dist)
               {
                  *p_CM1_ = *p_dist;
                  *q_CM1_ = *q_dist;
               }
            }
         }
      }
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_CM0_;
         int I_CM0_=1;
         double *q_CM0_;
         double *p_prox;
         int I_prox=1, J_prox;
         double *q_prox;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&prox), 1);
         mccAllocateMatrix(&CM0_, m_, n_);
         mccCheckMatrixSize(&prox, mccM(&prox), 2);
         I_CM0_ = (mccM(&CM0_) != 1 || mccN(&CM0_) != 1);
         p_CM0_ = mccPR(&CM0_);
         q_CM0_ = mccPI(&CM0_);
         if (mccM(&prox) == 1) { I_prox = J_prox = 0;}
         else { I_prox = 1; J_prox=mccM(&prox)-m_; }
         p_prox = mccPR(&prox) + 0 + mccM(&prox) * (2-1);
         q_prox = mccPI(&prox) + 0 + mccM(&prox) * (2-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_prox += J_prox, q_prox += J_prox)
            {
               for (i_=0; i_<m_; ++i_, p_CM0_+=I_CM0_, q_CM0_+=I_CM0_, p_prox+=I_prox, q_prox+=I_prox)
               {
                  *p_CM0_ = *p_prox;
                  *q_CM0_ = *q_prox;
               }
            }
         }
      }
      mccCatenateColumns(&yd, &CM1_, &CM0_);
      /* d=sqrt((xd(:,2)-xd(:,1)).^2+(yd(:,2)-yd(:,1)).^2); */
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_CM0_;
         int I_CM0_=1;
         double *q_CM0_;
         double *p_xd;
         int I_xd=1, J_xd;
         double *q_xd;
         double *p_1xd;
         int I_1xd=1, J_1xd;
         double *q_1xd;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&xd), 1);
         m_ = mcmCalcResultSize(m_, &n_, mccM(&xd), 1);
         mccAllocateMatrix(&CM0_, m_, n_);
         mccCheckMatrixSize(&xd, mccM(&xd), 2);
         mccCheckMatrixSize(&xd, mccM(&xd), 1);
         I_CM0_ = (mccM(&CM0_) != 1 || mccN(&CM0_) != 1);
         p_CM0_ = mccPR(&CM0_);
         q_CM0_ = mccPI(&CM0_);
         if (mccM(&xd) == 1) { I_xd = J_xd = 0;}
         else { I_xd = 1; J_xd=mccM(&xd)-m_; }
         p_xd = mccPR(&xd) + 0 + mccM(&xd) * (2-1);
         q_xd = mccPI(&xd) + 0 + mccM(&xd) * (2-1);
         if (mccM(&xd) == 1) { I_1xd = J_1xd = 0;}
         else { I_1xd = 1; J_1xd=mccM(&xd)-m_; }
         p_1xd = mccPR(&xd) + 0 + mccM(&xd) * (1-1);
         q_1xd = mccPI(&xd) + 0 + mccM(&xd) * (1-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_xd += J_xd, q_xd += J_xd, p_1xd += J_1xd, q_1xd += J_1xd)
            {
               for (i_=0; i_<m_; ++i_, p_CM0_+=I_CM0_, q_CM0_+=I_CM0_, p_xd+=I_xd, q_xd+=I_xd, p_1xd+=I_1xd, q_1xd+=I_1xd)
               {
                  *p_CM0_ = (*p_xd - *p_1xd);
                  *q_CM0_ = (*q_xd - *q_1xd);
               }
            }
         }
      }
      mccArrayPower(&CM1_, &CM0_, mccTempMatrix(2, 0., mccINT, 0 ));
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_CM2_;
         int I_CM2_=1;
         double *q_CM2_;
         double *p_yd;
         int I_yd=1, J_yd;
         double *q_yd;
         double *p_1yd;
         int I_1yd=1, J_1yd;
         double *q_1yd;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&yd), 1);
         m_ = mcmCalcResultSize(m_, &n_, mccM(&yd), 1);
         mccAllocateMatrix(&CM2_, m_, n_);
         mccCheckMatrixSize(&yd, mccM(&yd), 2);
         mccCheckMatrixSize(&yd, mccM(&yd), 1);
         I_CM2_ = (mccM(&CM2_) != 1 || mccN(&CM2_) != 1);
         p_CM2_ = mccPR(&CM2_);
         q_CM2_ = mccPI(&CM2_);
         if (mccM(&yd) == 1) { I_yd = J_yd = 0;}
         else { I_yd = 1; J_yd=mccM(&yd)-m_; }
         p_yd = mccPR(&yd) + 0 + mccM(&yd) * (2-1);
         q_yd = mccPI(&yd) + 0 + mccM(&yd) * (2-1);
         if (mccM(&yd) == 1) { I_1yd = J_1yd = 0;}
         else { I_1yd = 1; J_1yd=mccM(&yd)-m_; }
         p_1yd = mccPR(&yd) + 0 + mccM(&yd) * (1-1);
         q_1yd = mccPI(&yd) + 0 + mccM(&yd) * (1-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_yd += J_yd, q_yd += J_yd, p_1yd += J_1yd, q_1yd += J_1yd)
            {
               for (i_=0; i_<m_; ++i_, p_CM2_+=I_CM2_, q_CM2_+=I_CM2_, p_yd+=I_yd, q_yd+=I_yd, p_1yd+=I_1yd, q_1yd+=I_1yd)
               {
                  *p_CM2_ = (*p_yd - *p_1yd);
                  *q_CM2_ = (*q_yd - *q_1yd);
               }
            }
         }
      }
      mccArrayPower(&CM3_, &CM2_, mccTempMatrix(2, 0., mccINT, 0 ));
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_CM4_;
         int I_CM4_=1;
         double *q_CM4_;
         double *p_CM1_;
         int I_CM1_=1;
         double *q_CM1_;
         double *p_CM3_;
         int I_CM3_=1;
         double *q_CM3_;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&CM1_), mccN(&CM1_));
         m_ = mcmCalcResultSize(m_, &n_, mccM(&CM3_), mccN(&CM3_));
         mccAllocateMatrix(&CM4_, m_, n_);
         I_CM4_ = (mccM(&CM4_) != 1 || mccN(&CM4_) != 1);
         p_CM4_ = mccPR(&CM4_);
         q_CM4_ = mccPI(&CM4_);
         I_CM1_ = (mccM(&CM1_) != 1 || mccN(&CM1_) != 1);
         p_CM1_ = mccPR(&CM1_);
         q_CM1_ = mccPI(&CM1_);
         I_CM3_ = (mccM(&CM3_) != 1 || mccN(&CM3_) != 1);
         p_CM3_ = mccPR(&CM3_);
         q_CM3_ = mccPI(&CM3_);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_)
            {
               for (i_=0; i_<m_; ++i_, p_CM4_+=I_CM4_, q_CM4_+=I_CM4_, p_CM1_+=I_CM1_, q_CM1_+=I_CM1_, p_CM3_+=I_CM3_, q_CM3_+=I_CM3_)
               {
                  *p_CM4_ = (*p_CM1_ + *p_CM3_);
                  *q_CM4_ = (*q_CM1_ + *q_CM3_);
               }
            }
         }
      }
      Mprhs_[0] = &CM4_;
      Mplhs_[0] = &d;
      mccCallMATLAB(1, Mplhs_, 1, Mprhs_, "sqrt", 9);
      /* % plot(d); */
      /* % title('marker distance vs time'); */
      /* l = mean(d); */
      Mprhs_[0] = &d;
      Mplhs_[0] = &CM4_;
      mccCallMATLAB(1, Mplhs_, 1, Mprhs_, "mean", 12);
      l_r = (mccGetRealVectorElement(&CM4_, mccRint(1)));
      l_i = mccGetImagVectorElement(&CM4_, mccRint(1));
      
      mccReturnScalar(&plhs_[0], l_r, l_i, mccCX, 0);
   }
   else
   {
/***************** Compiler Assumptions ****************
 *
 *       CM0_        	complex vector/matrix temporary
 *       RM0_        	real vector/matrix temporary
 *       RM1_        	real vector/matrix temporary
 *       RM2_        	real vector/matrix temporary
 *       d           	complex vector/matrix
 *       dist        	real vector/matrix
 *       distance    	<function being defined>
 *       l           	complex scalar
 *       mean        	<function>
 *       prox        	real vector/matrix
 *       sqrt        	<function>
 *       xd          	real vector/matrix
 *       yd          	real vector/matrix
 *******************************************************/
      double l_r=0.0, l_i=0.0;
      mxArray dist;
      mxArray prox;
      mxArray xd;
      mxArray yd;
      mxArray d;
      mxArray RM0_;
      mxArray RM1_;
      mxArray RM2_;
      mxArray CM0_;
      
      mccRealInit(dist);
      mccImport(&dist, ((nrhs_>0) ? prhs_[0] : 0), 0, 0);
      mccRealInit(prox);
      mccImport(&prox, ((nrhs_>1) ? prhs_[1] : 0), 0, 0);
      mccRealInit(xd);
      mccRealInit(yd);
      mccComplexInit(d);
      mccRealInit(RM0_);
      mccRealInit(RM1_);
      mccRealInit(RM2_);
      mccComplexInit(CM0_);
      
      
      /* xd=[dist(:,1) prox(:,1)]; */
      if(mccNOTSET(&dist))
      {
         mexErrMsgTxt( "variable dist undefined, line 7" );
      }
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_RM0_;
         int I_RM0_=1;
         double *p_dist;
         int I_dist=1, J_dist;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&dist), 1);
         mccAllocateMatrix(&RM0_, m_, n_);
         mccCheckMatrixSize(&dist, mccM(&dist), 1);
         I_RM0_ = (mccM(&RM0_) != 1 || mccN(&RM0_) != 1);
         p_RM0_ = mccPR(&RM0_);
         if (mccM(&dist) == 1) { I_dist = J_dist = 0;}
         else { I_dist = 1; J_dist=mccM(&dist)-m_; }
         p_dist = mccPR(&dist) + 0 + mccM(&dist) * (1-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_dist += J_dist)
            {
               for (i_=0; i_<m_; ++i_, p_RM0_+=I_RM0_, p_dist+=I_dist)
               {
                  *p_RM0_ = *p_dist;
               }
            }
         }
      }
      if(mccNOTSET(&prox))
      {
         mexErrMsgTxt( "variable prox undefined, line 7" );
      }
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_RM1_;
         int I_RM1_=1;
         double *p_prox;
         int I_prox=1, J_prox;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&prox), 1);
         mccAllocateMatrix(&RM1_, m_, n_);
         mccCheckMatrixSize(&prox, mccM(&prox), 1);
         I_RM1_ = (mccM(&RM1_) != 1 || mccN(&RM1_) != 1);
         p_RM1_ = mccPR(&RM1_);
         if (mccM(&prox) == 1) { I_prox = J_prox = 0;}
         else { I_prox = 1; J_prox=mccM(&prox)-m_; }
         p_prox = mccPR(&prox) + 0 + mccM(&prox) * (1-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_prox += J_prox)
            {
               for (i_=0; i_<m_; ++i_, p_RM1_+=I_RM1_, p_prox+=I_prox)
               {
                  *p_RM1_ = *p_prox;
               }
            }
         }
      }
      mccCatenateColumns(&xd, &RM0_, &RM1_);
      /* yd=[dist(:,2) prox(:,2)]; */
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_RM1_;
         int I_RM1_=1;
         double *p_dist;
         int I_dist=1, J_dist;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&dist), 1);
         mccAllocateMatrix(&RM1_, m_, n_);
         mccCheckMatrixSize(&dist, mccM(&dist), 2);
         I_RM1_ = (mccM(&RM1_) != 1 || mccN(&RM1_) != 1);
         p_RM1_ = mccPR(&RM1_);
         if (mccM(&dist) == 1) { I_dist = J_dist = 0;}
         else { I_dist = 1; J_dist=mccM(&dist)-m_; }
         p_dist = mccPR(&dist) + 0 + mccM(&dist) * (2-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_dist += J_dist)
            {
               for (i_=0; i_<m_; ++i_, p_RM1_+=I_RM1_, p_dist+=I_dist)
               {
                  *p_RM1_ = *p_dist;
               }
            }
         }
      }
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_RM0_;
         int I_RM0_=1;
         double *p_prox;
         int I_prox=1, J_prox;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&prox), 1);
         mccAllocateMatrix(&RM0_, m_, n_);
         mccCheckMatrixSize(&prox, mccM(&prox), 2);
         I_RM0_ = (mccM(&RM0_) != 1 || mccN(&RM0_) != 1);
         p_RM0_ = mccPR(&RM0_);
         if (mccM(&prox) == 1) { I_prox = J_prox = 0;}
         else { I_prox = 1; J_prox=mccM(&prox)-m_; }
         p_prox = mccPR(&prox) + 0 + mccM(&prox) * (2-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_prox += J_prox)
            {
               for (i_=0; i_<m_; ++i_, p_RM0_+=I_RM0_, p_prox+=I_prox)
               {
                  *p_RM0_ = *p_prox;
               }
            }
         }
      }
      mccCatenateColumns(&yd, &RM1_, &RM0_);
      /* d=sqrt((xd(:,2)-xd(:,1)).^2+(yd(:,2)-yd(:,1)).^2); */
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_RM0_;
         int I_RM0_=1;
         double *p_xd;
         int I_xd=1, J_xd;
         double *p_1xd;
         int I_1xd=1, J_1xd;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&xd), 1);
         m_ = mcmCalcResultSize(m_, &n_, mccM(&xd), 1);
         mccAllocateMatrix(&RM0_, m_, n_);
         mccCheckMatrixSize(&xd, mccM(&xd), 2);
         mccCheckMatrixSize(&xd, mccM(&xd), 1);
         I_RM0_ = (mccM(&RM0_) != 1 || mccN(&RM0_) != 1);
         p_RM0_ = mccPR(&RM0_);
         if (mccM(&xd) == 1) { I_xd = J_xd = 0;}
         else { I_xd = 1; J_xd=mccM(&xd)-m_; }
         p_xd = mccPR(&xd) + 0 + mccM(&xd) * (2-1);
         if (mccM(&xd) == 1) { I_1xd = J_1xd = 0;}
         else { I_1xd = 1; J_1xd=mccM(&xd)-m_; }
         p_1xd = mccPR(&xd) + 0 + mccM(&xd) * (1-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_xd += J_xd, p_1xd += J_1xd)
            {
               for (i_=0; i_<m_; ++i_, p_RM0_+=I_RM0_, p_xd+=I_xd, p_1xd+=I_1xd)
               {
                  *p_RM0_ = (*p_xd - *p_1xd);
               }
            }
         }
      }
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_RM1_;
         int I_RM1_=1;
         double *p_yd;
         int I_yd=1, J_yd;
         double *p_1yd;
         int I_1yd=1, J_1yd;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&yd), 1);
         m_ = mcmCalcResultSize(m_, &n_, mccM(&yd), 1);
         mccAllocateMatrix(&RM1_, m_, n_);
         mccCheckMatrixSize(&yd, mccM(&yd), 2);
         mccCheckMatrixSize(&yd, mccM(&yd), 1);
         I_RM1_ = (mccM(&RM1_) != 1 || mccN(&RM1_) != 1);
         p_RM1_ = mccPR(&RM1_);
         if (mccM(&yd) == 1) { I_yd = J_yd = 0;}
         else { I_yd = 1; J_yd=mccM(&yd)-m_; }
         p_yd = mccPR(&yd) + 0 + mccM(&yd) * (2-1);
         if (mccM(&yd) == 1) { I_1yd = J_1yd = 0;}
         else { I_1yd = 1; J_1yd=mccM(&yd)-m_; }
         p_1yd = mccPR(&yd) + 0 + mccM(&yd) * (1-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_yd += J_yd, p_1yd += J_1yd)
            {
               for (i_=0; i_<m_; ++i_, p_RM1_+=I_RM1_, p_yd+=I_yd, p_1yd+=I_1yd)
               {
                  *p_RM1_ = (*p_yd - *p_1yd);
               }
            }
         }
      }
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_RM2_;
         int I_RM2_=1;
         double *p_RM0_;
         int I_RM0_=1;
         double *p_RM1_;
         int I_RM1_=1;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&RM0_), mccN(&RM0_));
         m_ = mcmCalcResultSize(m_, &n_, mccM(&RM1_), mccN(&RM1_));
         mccAllocateMatrix(&RM2_, m_, n_);
         I_RM2_ = (mccM(&RM2_) != 1 || mccN(&RM2_) != 1);
         p_RM2_ = mccPR(&RM2_);
         I_RM0_ = (mccM(&RM0_) != 1 || mccN(&RM0_) != 1);
         p_RM0_ = mccPR(&RM0_);
         I_RM1_ = (mccM(&RM1_) != 1 || mccN(&RM1_) != 1);
         p_RM1_ = mccPR(&RM1_);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_)
            {
               for (i_=0; i_<m_; ++i_, p_RM2_+=I_RM2_, p_RM0_+=I_RM0_, p_RM1_+=I_RM1_)
               {
                  *p_RM2_ = (mcmRealPowerInt(*p_RM0_, 2) + mcmRealPowerInt(*p_RM1_, 2));
               }
            }
         }
      }
      Mprhs_[0] = &RM2_;
      Mplhs_[0] = &d;
      mccCallMATLAB(1, Mplhs_, 1, Mprhs_, "sqrt", 9);
      /* % plot(d); */
      /* % title('marker distance vs time'); */
      /* l = mean(d); */
      Mprhs_[0] = &d;
      Mplhs_[0] = &CM0_;
      mccCallMATLAB(1, Mplhs_, 1, Mprhs_, "mean", 12);
      l_r = (mccGetRealVectorElement(&CM0_, mccRint(1)));
      l_i = mccGetImagVectorElement(&CM0_, mccRint(1));
      
      mccReturnScalar(&plhs_[0], l_r, l_i, mccCX, 0);
   }
   return;
}
