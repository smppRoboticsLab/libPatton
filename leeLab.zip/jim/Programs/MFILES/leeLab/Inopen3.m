%______*** MATLAB "M" FUNCTION (Patton, modified from Russo) ***_______
% open an input datio file and get some of the header info.
% NOTE: To close this file: fclose(fileinfo(1))
%  SYNTAX:	[fileinfo,Ntrials,Hz,time]=inopen3(fname,noverbose)
%  INPUTS: 	fname 		file name string of dataio format binary file
%		noverbose 	(optional) nonzero for fprintf or disp commands
%  OUTPUTS: 	fileinfo=[fid pts Ntypes]; 
%			fid: file id 
%			pts:	# of data points per data type; 
%			Ntypes: # of data types per trial
%		if cannont open, fileinfo=-9999.
%		Ntrials	# of trials in the data file	                                                              
%		Hz 	sampling frequency
%		time	time array
%  CALLS: 	
%  CALLED BY:	lots
%  SEE:   	maya//D:/programs/mfiles
%  VERSIONS:	5/12/97 Patton. inopen3.m  More error traps.
%		2/12/97 Patton. Renamed to inopen3 due to conflict with 
%		another inopen.m, which had different outputs.  This is
%		more similar to inopen1.m, which I also found.
%  INITIATED:	6/19/96 by jim patton from A. Russo's inopen.m
%  VERSIONS:	6/19/96 by jim patton from Russo's inopen.m 
%		10/8/97 patton: noverbose option added
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function [fileinfo,trialcnt,Hz,timearray]=inopen3(fname,noverbose)

% ______ SETUP _______
global DEBUGIT;					% NONZERO FOR DEBUG CODE
if ~exist('noverbose'), noverbose=0; end		% INIT IF NOT GIVEN
if ~noverbose, fprintf(' ~ inopen3.m ~ '); end;	%
SIZEofFLOAT=4;						% FLOAT VARIABLE #BYTES
SIZEofSHORT=2;						% SHORT VARIABLE #BYTES 
warning=0;						% set flag variable to OK

% ______ OPEN FILE _______
if DEBUGIT, 						% message
  fprintf('(open & get info on a dataio file)\n'); 	% message
  fprintf(' Open..'); 					% message
end %if							% message 
inputid=fopen(fname,'rb');				% OPEN FILE
if inputid<2,						% IF FILE NOT FOUND
  fprintf('  !! Cannot open %s\n',fname);		%
  fileinfo=-9999;					% set bad data flag
  break;						%
end

% ______ CHECK INTERNAL CONSISTENCY _______
if DEBUGIT, fprintf(' Check if consistent..'); end 	% message
NN=0; s=0; numVALUESvector=[];			% INIT
while ~s,						% WHILE NOT END OF FILE
  NN=NN+1;						%
  [a,count]=fread(inputid,20,'short');		% READ 20 ELEMENT HEADER 
  if a(1,1)==1, break; end; 				% STOP WHEN FIRST#=1 (EOF)
  numVALUESvector(NN)=a(5,1);				% STORE #VALUES THIS RECORD
  if DEBUGIT, 						%
    fprintf('\n%d) NUM%d CHAN%d TRIAL%d CLASS%d',...	%
      NN,a(5,1),a(2,1),a(3,1),a(4,1)); 		%
  end %if						%
  pts=a(5,1);						% NUMBER OF POINTS/RECORD
  s=fseek(inputid,pts*4,'cof');			% ADVANCE TO END OF RECORD
end %while						% END OF FILE 
if max(numVALUESvector)~=min(numVALUESvector),	% IF STRUCTURES AREN'T SAME
  fprintf('\nERROR: this file is inconsistent\n');	% ERROR MSG
  error(' (#samples/record varies)');			% ERROR MSG STOP QUIT EXIT 
end %if							%

% ______ GET INFO FROM HEADER _______
if DEBUGIT, fprintf('\n read header 1..'); end %if	%
frewind(inputid);					% RESET FILE TO BEGINNING 
 [a,count]=fread(inputid,20,'short');			% READ 20 ELEMENT HEADER 
typecnt=1;						% RESET THE #-OF-TYPES 
pts=a(5,1);						% NUMBER OF POINTS/RECORD
interval=a(9,1)/1000;					% SAMPLING INTERVAL
Hz=1/interval;						% SAMPLING FREQUENCY
sampletime=pts*interval; 				% SAMPLING TIME FOR TRIAL 
timearray=0.0:interval:sampletime;			% MAKE AN ARRAY FOR TIME
timearray=timearray(1:pts)';				% ?FIX?
s=fseek(inputid,pts*SIZEofFLOAT,'cof');		% ADVANCE TO END OF RECORD
aLAST=a;						% STORE FOR REF LATER

% ______ EVALUATE # OF DATATYPES PER TRIAL _______
if DEBUGIT, fprintf(' find # datatypes..'); end %if	%
oldtrialnum=a(3,1);					% TRIAL ID #
while inputid>1					% ?UNTIL END OF FILE?
  [a,count]=fread(inputid,20,'short');		% READ 20 ELEMENT HEADER
  if length(a)==2, 					% halt if END is reached
    if ~noverbose, fprintf('<eof>'); end;		% message
    break; 
  end;	
  if a(3,1)~= oldtrialnum, break; end; %if		% STOP WHEN NEW TRIAL 
  s=fseek(inputid,pts*SIZEofFLOAT,0);			% ADVANCE TO END OF RECORD 
  typecnt=typecnt+1;					% COUNT # DATATYPES/TRIAL
  if aLAST==a; fprintf('WARNING: equal hdrs..');end;	% ERROR CHECK: SAME HEADER
  aLAST=a;						% STORE FOR REF LATER
end %while 						%
if DEBUGIT, fprintf('(%d) ', typecnt); end %if	%

% ______ COUNT # OF TRIALS _______ 
if DEBUGIT, fprintf('Count # trials..'); end %if 	%
frewind(inputid);					% RESET FILE TO BEGINNING 
offset=typecnt*(pts*SIZEofFLOAT+20*SIZEofSHORT);	% AMOUNT TO JUMP PER TRIAL 
trialcnt=1;						% RESET #-OF-TRIALS 
while inputid>2					% ?UNTIL END OF FILE?
  s=fseek(inputid,offset,0);				% JUMP 1 TRIAL AHEAD
  [a,count]=fread(inputid,20,'short');		% READ 20 ELEMENT HEADER 
  if a(1,1)==1, break; end; 				% STOP WHEN FIRST#=1 (EOF)
  if DEBUGIT, fprintf('\ntrial %d',a(3,1)); end %if	% DISPLAY TRIAL
  if aLAST==a;						% ERROR CHECK: SAME HEADER 
    fprintf('WARNING: identical headers! '); break;	% STOP IF PROBLEM
  end; %if						%
  aLAST=a;						% STORE FOR REF LATER
  trialcnt=trialcnt+1;					% COUNT # OF TRIALS
  s=fseek(inputid,-40,0);				% BACK TO START OF HEADER 
  if trialcnt~=a(3,1)&	warning==0, bad=a(3,1); end;	% if not consistent, flag
  if trialcnt~=a(3,1),	warning=1; end;		% if not consistent, flag
end %while 						%
if DEBUGIT, fprintf('(%d) ', trialcnt); end %if	%

% ______ DISPLAY WARNING _______ 
if warning,						%
  fprintf(' WARNING: #records/trial varies');	% WARNING MSG 
  fprintf(' starting at trial %d. \n', bad);		% WARNING MSG 
else	
 if ~noverbose, fprintf(' (OK.) \n');	 end;		% say ok &CARRIAGE RETURN
end %if

fileinfo=[inputid pts typecnt];			% CONSTRUCT FILEINFO OUTPUT

if ~noverbose|DEBUGIT, 
  fprintf(' ~ END inopen3.m ~ \n'); 
end %if

