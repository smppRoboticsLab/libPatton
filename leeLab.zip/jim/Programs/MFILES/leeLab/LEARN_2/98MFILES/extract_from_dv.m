%************** MATLAB M file (Patton) **************
% loop, extract, & rewrite  __dv.txt files (from "learn_2" protocol)
% OUTPUT is a text file (OUTname="learn_2.dv")in column format that  
% can be read using TEXTRACT.M, hdrload.m, or a spreadsheet. 
% SYNTAX:     extract_from_dv.m   
% CALLS:      hdrload.m, mat2txt.m
% CALLED BY:  -
% REVISIONS:  7/8/98  (Patton) initaiated from ENGIN.M
% NOTES:      
%             * This only works for matlab 5 or better
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~ begin: ~~~~~~~~~~~~~~~~~~~~~~~~~~~

%____ SETUP ____
global DEBUGIT                                       % nonzero=debugging
prog_name='extract_from_dv.m';                       % this program's name
fprintf('\n~ %s ~ ', prog_name);                     % message
status=0;                                            % start with OK status
verbose=1;                                           % always show messages
trial_start = 1;
block_start = 1;
day_start = 1;
base_dir=cd;
if strcmp(base_dir(length(base_dir)),'\'), 
   base_dir(length(base_dir))=[]; 
end; % if
save c:\jim\matlab\base_dir base_dir 
days=[1 5];		
IDs=['AS';'CK';'EV';'GH';'HI';                ...
         'KM';'MF';'PM';'RP';'YW']; 
OUTname='learn_2.dv';
rowsPerTrial=6;
colsInDVTXTfiles=11;
outVALUES=[];                                        % init matrix



%____ LOAD INPUT DATA FILES (___.dv) ____
disp('*** Begin processing:');
for SUBJ=1:length(IDs)
  id=IDs(SUBJ,:); 
  fprintf(['\n~~~~~~ N E W   S U B J E C T: %s ~~~~~~\n'], id); 

  % _______ sort out the subject number for learn2a ________ 
  for check=1:length(all_IDs), 
    if strcmp(id,all_IDs(check,:)), sub_num=check; end; %if 
  end; %

  % __ get paramter file for subject (c:\jim\lee\learn_2\) ___
  paramfilename=[ base_dir '\' id '.prm'];
  [dummy,subj_param]=hdrload(paramfilename);

  % ____________ loop for each DAY ____________ 
  for day=days(day_start):4:5,
    fprintf('__ DAY: %d ___\n',day); 
    eval(['cd ' base_dir '\' id num2str(day)]); 
    if day==1,Nblocks=12; sk=1; else Nblocks=7; sk=1; end %if

    % ____________ loop for each BLOCK ________ 
    for block=block_start:sk:Nblocks
      fprintf('\n_ BLOCK: #%d: _ \t',block);

      %____________ load BLOCK info ___________
      in_name=fileid(id,day,block,'dv.txt');
      fprintf(' Loading %s..',in_name);
      [h,d]=hdrload(in_name); [rows,cols]=size(d);
      fprintf(' done. (%d by %d) ', rows,cols);

      %_____________ loop for each TRIAL _______
      fprintf(' _TRIAL_ :  ');
      if day==1|block==4, Ntrials=9; else Ntrials=21; end
      for trial=trial_start:1:Ntrials
        
        fprintf(' %d ',trial);
        pointer=(trial-1)*rowsPerTrial+1;            % points 1st row o trial
        values=[SUBJ];
        for row=1:rowsPerTrial
          for col=1:colsInDVTXTfiles
            values=[values d(pointer-1+row,col)];
          end %for col
        end %for row
        outVALUES=[outVALUES; values];               % stack trial's values

      end % for trial
      
    end	 % for block 
   
  end % day
  fprintf(['\n done with subject "%s",'      ...
           ' %d trials so far\n'],            ...
          id,length(outVALUES(:,1)));

end % for SUBJ

%_____ define FINAL header for the output file _____  
labels=['subject number'];                            % init list of col headers
labels=[labels char(9) 'idnum'];                     % # composed from textid
labels=[labels char(9) 'day'];                       % add a tab char & a label
labels=[labels char(9) 'block'];                     % add a tab char & a label
labels=[labels char(9) 'perckr'];                    % add a tab char & a label
labels=[labels char(9) 'self-report'];               % add a tab char & a label
labels=[labels char(9) 'trial'];                     % add a tab char & a label
labels=[labels char(9) 'height (m)'];                % add a tab char & a label
labels=[labels char(9) 'weight (kg)'];               % add a tab char & a label
labels=[labels char(9) 'LC-height (mm)'];            % add a tab char & a label
labels=[labels char(9) 'maxforce (N)'];              % add a tab char & a label
labels=[labels char(9) 'targetforce (N)'];           % add a tab char & a label
labels=[labels char(9) 'Fp baseline mean '];         % add a tab char & a label
labels=[labels char(9) 'Fp tFPon'];                  % add a tab char & a label
labels=[labels char(9) 'Fp tFPoff'];                 % add a tab char & a label
labels=[labels char(9) 'Fp FPpeak'];                 % add a tab char & a label
labels=[labels char(9) 'Fp tFPpeak'];                % add a tab char & a label
labels=[labels char(9) 'Fp impulsetFPon-tFPpeak'];   % add a tab char & a label
labels=[labels char(9) 'Fp impulsetFPpeak-tFPoff'];  % add a tab char & a label
labels=[labels char(9) 'Fp FPerror '];               % add a tab char & a label
labels=[labels char(9) 'Fp %error'];                 % add a tab char & a label
labels=[labels char(9) 'Fp tBASELINEon'];            % add a tab char & a label
labels=[labels char(9) 'Fp tBASELINEoff'];           % add a tab char & a label
labels=[labels char(9) 'CMap_dot baseline mean'];    % add a tab char & a label
labels=[labels char(9) 'CMap_dot tCMon'];            % add a tab char & a label
labels=[labels char(9) 'CMap_dot tCMoff'];           % add a tab char & a label
labels=[labels char(9) 'CMap_dot CM-at-tFPon'];      % add a tab char & a label
labels=[labels char(9) 'CMap_dot -'];                % add a tab char & a label
labels=[labels char(9) 'CMap_dot CMmax'];            % add a tab char & a label
labels=[labels char(9) 'CMap_dot tCMmax'];           % add a tab char & a label
labels=[labels char(9) 'CMap_dot CMmin'];            % add a tab char & a label
labels=[labels char(9) 'CMap_dot tCMmin'];           % add a tab char & a label
labels=[labels char(9) 'CMap_dot -'];                % add a tab char & a label
labels=[labels char(9) 'CMap_dot -'];                % add a tab char & a label
labels=[labels char(9) 'CMap baseline mean'];        % add a tab char & a label
labels=[labels char(9) 'CMap tCMon'];                % add a tab char & a label
labels=[labels char(9) 'CMap tCMoff'];               % add a tab char & a label
labels=[labels char(9) 'CMap CM-at-tFPon'];          % add a tab char & a label
labels=[labels char(9) 'CMap CM-at-tFPpeak'];        % add a tab char & a label
labels=[labels char(9) 'CMap CMmax'];                % add a tab char & a label
labels=[labels char(9) 'CMap tCMmax'];               % add a tab char & a label
labels=[labels char(9) 'CMap CMmin'];                % add a tab char & a label
labels=[labels char(9) 'CMap tCMmin'];               % add a tab char & a label
labels=[labels char(9) 'CMap mean after-offset'];    % add a tab char & a label
labels=[labels char(9) 'CMap -'];                    % add a tab char & a label
labels=[labels char(9) 'Cmvert_dot baseline mean'];  % add a tab char & a label
labels=[labels char(9) 'Cmvert_dot tCMon'];          % add a tab char & a label
labels=[labels char(9) 'Cmvert_dot tCMoff'];         % add a tab char & a label
labels=[labels char(9) 'Cmvert_dot CM-at-tFPon'];    % add a tab char & a label
labels=[labels char(9) 'Cmvert_dot -'];              % add a tab char & a label
labels=[labels char(9) 'Cmvert_dot CMmax'];          % add a tab char & a label
labels=[labels char(9) 'Cmvert_dot tCMmax'];         % add a tab char & a label
labels=[labels char(9) 'Cmvert_dot CMmin'];          % add a tab char & a label
labels=[labels char(9) 'Cmvert_dot tCMmin'];         % add a tab char & a label
labels=[labels char(9) 'Cmvert_dot -'];              % add a tab char & a label
labels=[labels char(9) 'Cmvert_dot -'];              % add a tab char & a label
labels=[labels char(9) 'Cmvert baseline mean'];      % add a tab char & a label
labels=[labels char(9) 'Cmvert tCMon'];              % add a tab char & a label
labels=[labels char(9) 'Cmvert tCMoff'];             % add a tab char & a label
labels=[labels char(9) 'Cmvert CM-at-tFPon'];        % add a tab char & a label
labels=[labels char(9) 'Cmvert CM-at-tFPpeak'];      % add a tab char & a label
labels=[labels char(9) 'Cmvert CMmax'];              % add a tab char & a label
labels=[labels char(9) 'Cmvert tCMmax'];             % add a tab char & a label
labels=[labels char(9) 'Cmvert CMmin'];              % add a tab char & a label
labels=[labels char(9) 'Cmvert tCMmin'];             % add a tab char & a label
labels=[labels char(9) 'Cmvert mean after offset'];  % add tab char & label
labels=[labels char(9) 'Cmvert_dot -'];              % add a tab char & a label

header=['Discreet variables for LEARN_2 subjects'];  %
header=str2mat(header,                           ... %
  ['Generated by "' prog_name '", ' whenis(clock)]); %
header=str2mat(header,                           ... %
  ['this is a tab-delimited data file that '     ... %
   'can be viewed via text editors, spreadsheet '... % 
   'programs, or loaded into MATLAB using  '     ... % 
   'HDRLOAD.M or TEXTRACT.M']);                      %
header=str2mat(header,                           ... %
  ['a value of -9999 means the trial is "bad",'  ... %
   ' missing, or not applicable']);      %
header=str2mat(header,                           ... %
  'a value of -8888 means the data is unavailable'); %
header=str2mat(header,                           ... %
  ['___ The next line contains the labels '      ... %...
   'followed by the values:___']);                   %...
header=str2mat(header,labels);                       % stick in column labels

%_____ WRITE output file _____
eval(['cd ' base_dir]);  cd
if mat2txt(OUTname,header,outVALUES),                % WRITE; IF CANT OPEN,
  error(' Cant write file. Aborting');               % abort
end;%                                                % end if mat2dio
fprintf('\nOUTPUT FILE: %s',OUTname); %              % display out file name

fprintf('\n~ END %s ~ \n\n', prog_name);             % message
