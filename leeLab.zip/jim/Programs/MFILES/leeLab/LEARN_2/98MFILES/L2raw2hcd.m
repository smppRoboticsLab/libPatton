% *********** *** MATLAB M function L2RAW2HCD.M *********** **
% process only Learn 2 filtered elite data and raw acquire data into .hcd files for all subjects and days 
%
% ************  ONLY WORKS FOR LEARN2 DATA  ************
% ************  MUST BE RUN FROM X:DATA\LEARN_2\  ************
%
% SYNTAX:       status=L2raw2hcd(ids,delete_or_not);
% INPUT ARGS:   ids      			matrix of 3 character id root strings
%					 delete_or_not		delete intermediate files or not, 1=delete files, 0=save files
%					 	default is NOT to save files!!!!!!!!!!!!!!!
% INPUT FILES:  fileroot.#			raw acquire data files
%					 fileroot.rif		filtered elite data files
% OUTPUTS       status           =zero if all went well
% CALLS:        raw2scd.m
%					 pull_model.m
%					 scd2hcd1 
%					 scd2hcd2
% CALLED BY:    - 
% EXAMPLE:      L2raw2hcd(['xx1';'xx5';'yy1';'yy5'],1) 
%               will run the steps below on all blocks of subjects xx1, xx5, yy1, and yy5 and delete
%					 intermediate files.
% REVISIONS:    8/4/98 by Markworth. Initiated batch_BOS1a.m
% NOTE:         Spaces, not tabs when writing code make it most portable
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~ begin: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

function status=L2raw2hcd(ids,delete_or_not);

%_____ SETUP VARS _____
global DEBUGIT                                           % nonzero=debugging
if DEBUGIT, fprintf('\nVerbose'); end; %if               % message
prog_name='L2RAW2HCD.M';                                   % this program's name
fprintf('\n ~ %s ~ \n L2RAW2HCD PROCESSING:',prog_name)    % orient user
status=0;                                                % start with ok status
if ~exist('delete_or_not'),delete_or_not=1; end				% make variable if not there
ids                                            		      % list ids
numsubs=length(ids(:,1));									      % number of subjects
sep='\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n'; fprintf(sep)    % separator string

%_____ BEGIN LOOP FOR SUBJECT _____ 
for sub=1:numsubs
   id=deblank(ids(sub,:));              				      % id of subject
   
   id
   
   eval(['cd ' id]);													% change to subject directory																	
   
   %_____ SET FILEROOTS _____
   if id(1,3) == '1'
      fileroots=[id '130';											% set day 1 fileroots	
      id '230';
      id '330'
      id '431';
      id '531';
      id '631';
      id '720';
      id '820';
      id '920';
      id 'a21';
      id 'b21';
      id 'c21'];
   else
      fileroots=[id '101';											% set day 5 fileroots
      id '201';
      id '301';
      id '431';
      id '501';
      id '601';
      id '701'];
   end
   
   %_____ GENERATE .SCD FILES _____ 
   RECS={[101 102 103 104 105 106],   'forceplate';      % cell array of datacodes,
        [201],                        'load cell';       % each cell represents a 
        [1011:10:1111],               'markers x';       % plot window, & is a vector
        [1012:10:1112],               'markers y';       % of which datacodes to put
        [1013:10:1113],               'markers z'};      % on the figure.  
     
   raw2scd(fileroots,4,11,11,[0 0 0],7,1,RECS,'n');		% generate .scd files for current subject
   clf																	
   pull_model([fileroots(1,:) '.scd'],1,[10 40]);			% run pull_model on current subject 			
   clf
   
   %_____ GENERATE .HCD FILES _____ 
   L2scd2hcd(fileroots,delete_or_not);							% generate .hcd files
   
   %_____ PRINT HCD FILES _____ 
   fprintf('\n PLOTTING...');  % MESSAGE
   numblocks=length(fileroots(:,1));                    	% number of blocks for subject
   
   RECS={[5010 5011],					'gha, gha dot';      % cell array of datacodes,
        [1031 1032],						'neck marker x & y'; % each cell represents a 
        [201],								'pulling force';     % plot window, & is a vector
        [5121],							'hcom dot';				% of which datacodes to put on the figure.
        [5040 5050 5060],				'tnet, tgi, tmus'};         

   for block=1:numblocks 
      fileroot=deblank(fileroots(block,:));              % rootname of block
      fprintf(sep);                                      % display separator string 
      plot_DIO([fileroot '.hcd'],RECS,'y','n');      		% do it
   end                                                   % end print loop
   
   cd ..							 										% return to data\Learn_2\ directory

end                                                      % end batch loop

%_____ END OF PROGRAM _____ 
fprintf([sep '\n ~ END %s @%s ~\n\n\n\n'],       ...     % message
  prog_name,whenis(clock))                       
return;

