%************************* MATLAB M function (Patton) *************************
% Establish a rigid body model (mass distrib and geom) from marker data.
% NOTE: This program will ONLY work in MATLAB 5 or later!
% This model is specific to a marker protocol and task, and it assumes the
% following structure:
%
% SEGMENT#    NAME                                                  \\/
% ========    =================                                     (8)    
%        1    foot                                                   o
%        2    leg (calf)                                            /|
%        3    thigh                                                6 5
%        4    pelvis                                              /  o
%        5    thorax & abdomen (l5 to c1)                    --7-o   |4 
%        6    upper_arm                                              o     
%        7    lower_arm_and_hand                                    3
%        8    head above c1                                        /
%                                                                 o    
%                                                                  2 
%                                                                   \
%                                                                ===1o=
%                                                             ~~~~~~~~~~~~~~~
% REFERENCES:  D. A. Winter, Biomechanics and Motor Control 
%              of Human Movement, 2nd ed., 1990, pp 56-57]
%
%              S. Plagenhoef, Patterns of human motion. Engle
%              wood Cliffs, NJ: Prentice-Hall, 1971, 
%              Table 3-5 & fig. 3-2
%
% SYNTAX:	MODEL=pull_model(INname,trial,startend,mkr,OUTname,noverbose);
% INPUTS:	INname		input filename or fileroot for inputs&outputs
%				(binary, dataio formatted file with marker data)
%		trial		specifies the trial to use
%		plot_or_not	=='y' for plots
%		startend	(optional) 2-element a vector specifying 
%				the start and end frame # from the 
%				file which you want to use to determine the 
%				model. (i.e, only look at data from 
%				startend(1) to startend(2)). 
%				If not given, we assume all the data be used.
%		mkr		(optional) list of marker numbers associated with
%				the following markers
%				  mkr(1)  = elite marker # for temple
%				  mkr(2)  = elite marker # for ear     
% 		 		  mkr(3)  = elite marker # for neck    
%				  mkr(4)  = elite marker # for shldr
% 		 		  mkr(5)  = elite marker # for elbow   
%				  mkr(6)  = elite marker # for wrist   
%				  mkr(7)  = elite marker # for waist   
%				  mkr(8)  = elite marker # for hip     
%				  mkr(9)  = elite marker # for knee    
%				  mkr(10) = elite marker # for ankle   
%				  mkr(11) = elite marker # for methead
%				If not given, we assume mkr=(1:11).
%		OUTname		(opitonal) output filename Default is model.txt
%				if name2==0, then do not output a file. If not 
%				given, the default is model.txd
%		noverbose 	(optional) nonzero supresses messages 
% OUTPUT ARGS:	MODEL 		-1 if errors; otherwise an N by 3 matrix, where
%				N is # of segments, and each row 
%				represents a segment of the model, and
%				  COLUMN 1 contains marker numbers that mark 
% 				           the START of the segment vector.
%				  COLUMN 2 contains marker numbers that mark 
% 				           the END of the segment vector.
%				  COLUMN 3 contains desired offset angle 
%				           in radians of the segment vector 
%				  COLUMN 4 
%				           
%				           PUT more HERE!
%				           
%				           
%				the first row of segparams will have the first 
%				segment listed be connected to segment number 
%				zero, which is ground.
%              FILE:		ASCII text file, whose name is specified by name2.
%		 		Contains header info & and the D matrix described. 
% EXAMPLE:	MODEL=pull_model('JLPS1.SCD',1);
%		this would load the file 'JLPS1.SCD' and use the marker 
%		trajectories to determine the model based on data from trial 1.
% CALLS:	dio_rec.m
%		dio2mat.m
%		mat2dio.m
% CALLED BY: 	
% REVISIONS: 	4/28/98 INITIATED by Patton from numerous other M files. Started
%		        out briefly named "modelpul.m"
% NOTES:	* Code is best viewed in MS word, courier new 8pt font
%		* For information on DATAIO (DIO) FORMAT, see Datio_format.doc
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~ begin: ~~~~~~~~~~~~~~~~~~~~~~~~~~~

function [MODEL,col_labels]=pull_model(INname,trial,startend,mkr,OUTname,noverbose);

%____ SETUP ____
prog_name='pull_model.m';                            % this program's name
global DEBUGIT                                       % nonzero=debugging
status=0;                                            % start with OK status
if nargin<2,error(' not enough input args '); end    % if #input arguments <2
num_seg=8;                                           %
if ~exist('OUTname'), OUTname='model.txd'; end;      % set default if not given 
if ~exist('mkr'), mkr=1:11; end;                     % set default if not given
if ~exist('noverbose'), noverbose=0; end;            % set default if not given 
if ~noverbose,                                       % if messaging 'on'
  fprintf('\n~ %s ~ ', prog_name);                   % message
  fprintf('\nProcessing "%s" ',INname);              % message
  fprintf('(%d segments): ', num_seg);               % message
end;                                                 %
if length(mkr)~=11;                                  %
  error(' !Improper #markers in input "mkrs" END!'); %
end                                                  % end if NumColsIn~=4; 
ang=NaN*ones(num_seg,1); %                           % init
r=NaN*ones(num_seg,1);%                              % init
rs=NaN*ones(num_seg,1);%                             % init
m=NaN*ones(num_seg,1); %                             % init
I=NaN*ones(num_seg,1); %                             % init
L=NaN*ones(num_seg,1);%                              % init
Rgyr=NaN*ones(num_seg,1); %                          % init
ms=NaN*ones(num_seg,1); %                            % init
segnames=str2mat( 'foot',                        ... % name
                  'leg',                         ... % name
                  'thigh',                       ... % name
                  'pelvis',                      ... % name
                  'trunk',                       ... % name
                  'humerous',                    ... % name
                  'forearm',                     ... % name
                  'head & neck');                    % name

%____ LOAD INPUT FILE ____
if ~noverbose,fprintf('\nINPUT FILE: %s',INname);end % message
if ~noverbose,fprintf('\nReading..');pause(.01);end  % message
[H,D,Ntrials,Nrecs]=dio2mat(INname,1);               % load/check block
[rows,cols]=size(D);                                 % #time steps & #total recs
if ~exist('startend'), startend=[1,rows]; end;       % set default if not given
if ~noverbose,fprintf('(Looking at frames %d-%d)'... % message
  ,startend(1), startend(2)); pause(.01); end        % 
D=D(startend(1):startend(2),:);                      % snip down to times wanted
[rows,cols]=size(D);                                 % #time steps & #total recs
M=NaN*ones(rows,2,num_seg);                          % init marker array
i_vect=[ ones(rows,1) zeros(rows,1)];                % unit vectors: reference
o_vect=zeros(rows,2);                                % origin vectors: reference
if H==-1,                                            % if cant read
  status=1;%                                         % status to "error"
  fprintf('\n cant read %s. Aborting. \n', INname);  % message
  return; %                                          % abort if cant read
end%                                                 % end if cant read
if ~noverbose, fprintf(' Done. '); pause(.01); end;  % message

%____ EXTRACT 2D VECT TRAJECT OF MARKERS ____
if ~noverbose,fprintf(' Get mkrs..');pause(.01);end  % message
for Mno=1:length(mkr)
  Xcode=1000+10*mkr(Mno)+1;                          % marker code # for X traj
  Ycode=1000+10*mkr(Mno)+2;                          % marker code # for Y traj
  M(:,:,Mno)=[dio_rec(D,H,[3,2],[trial,Xcode],1),... % Extract hypermatrix
               dio_rec(D,H,[3,2],[trial,Ycode],1)];  %...using marker code #.
  plot(M(:,1,Mno), M(:,2,Mno),'o');                  % quick display
  hold on; axis equal                                % 
  if ~noverbose,fprintf('.');pause(.01);end          % blip message
end;                                                 % end for Mno 
%plot(M(:,1,3),M(:,2,3)-Vneck,'*');                  % quick display of 
pause(.01);                                          % update display
temple =M(:,:,1); %                                  % extract to usable name
ear    =M(:,:,2); %                                  % extract to usable name
neck   =M(:,:,3); %                                  % extract to usable name
shldr  =M(:,:,4); %                                  % extract to usable name
elbow  =M(:,:,5); %                                  % extract to usable name
wrist  =M(:,:,6); %                                  % extract to usable name
waist  =M(:,:,7); %                                  % extract to usable name
hip    =M(:,:,8); %                                  % extract to usable name
knee   =M(:,:,9); %                                  % extract to usable name
ankle  =M(:,:,10); %                                 % extract to usable name
methead=M(:,:,11); %                                 % extract to usable name
if ~noverbose,fprintf('DONE.'); end;	% message

%_______ EXTRACT PARAMS:_________
if ~noverbose,fprintf(' Get params..');end           % message 
pause(.01);                                          % update scrn
gender=(textract('readme.txt','gender'));%           % gender code
if gender==77|gender==109|gender==70|gender==102,    % is it appropriate 
  gender=char(gender);                               % convert to text
else                                                 % if sex not specified
  gender='w';					        % set to winter's data
end                                                  % END if gender
H     = textract('readme.txt','height');%            % body height
if ~noverbose,fprintf('.');pause(.01);end            % blip message
mass  = textract('readme.txt','mass');%              % body mass	
if ~noverbose,fprintf('.');pause(.01);end            % blip message
a     = textract('readme.txt',                   ... % horiz ankle to heel 
                'horiz dist ankle to heel');         % ...
if ~noverbose,fprintf('.');pause(.01);end            % blip message
b     = textract('readme.txt',                   ... % vert ankle height	
                'vert dist ank to sole');            % ...	
if ~noverbose,fprintf('.');pause(.01);end            % blip message
lf    = textract('readme.txt','foot length');        % foot length 
if ~noverbose,fprintf('.');pause(.01);end            % blip message
Vneck = textract('readme.txt',                   ... %
                 'vert dist C7 to nec');             % body height
if ~noverbose,fprintf('.');pause(.01);end            % blip message
wrist2hand=textract('readme.txt',                ... %
   'dist wrist to handle');                          % body height
%frankfort_angle=textract('readme.txt',          ... % not needed now..
%                         'frankfort_offset');       % 
if ~noverbose,fprintf('DONE.'); end;%                % message

%_______ CALC VALUES:_________
if ~noverbose,fprintf(' Calc values..'); end         % message
pause(.01);                                          % update scrn
waist2shldr    =distance(waist,shldr); %             % thorax&abdomen length2
ear_temple_ang=angle_2d(o_vect,i_vect,ear,temple,0); % calc ear_temple angle
foot_ang=angle_2d(o_vect,i_vect,ankle,methead,0);    % calc foot angle
foot_offset_ang=pi-mean(foot_ang);                   % mean offset from horiz
trunk_shldr_ang=angle_2d(waist,neck,waist,shldr,0);  % calc foot angle
shldr_offset_ang=mean(trunk_shldr_ang);              % find the mean
if ~noverbose,fprintf('DONE.'); end;%                % message 

%============================================================
%======== MODEL DEFINITION: GEOMETRY & MASS DISTRIB: ========
%============================================================
if ~noverbose,fprintf(' Defining model..'); end      % message
pause(.01);                                          % update screen

%_______ SEGMENT LENGTHS:_________
L(1)=distance(ankle,methead);%                       % foot
L(2)=distance(ankle,knee);; %                        % leg 
L(3)=distance(knee,hip); %                           % thigh 
L(4)=distance(hip,waist);                            % pelv(hip-waist=hip-L4L5)
L(5)=distance(waist,neck)-Vneck;                     % thorax&abdomen(L4L5-C7T1)
L(6)=distance(shldr,elbow);                          % upper arm 
L(7)=distance(elbow,wrist);                          % lower arm&hand
L(8)=distance(neck,ear)+Vneck;                       % head& neck c7t1 2 CM(ear)

%_______ SEGMENT AXES:_________
% This defines the coordinate systems used as a
% reference for each segment. Each row of this 
% matrix is for a segment, and 
%	COL 1 is starting marker (segment's origin)
%	COL 2 is ending   marker
% 	COL 3 is the "offset angle" or how much to 
%	      rotate the line between these 
%	      markers counter cockwise to get 
%	      the desired axis
% 	COL 4 is the "offset distance" or how much 
%	      to add or subtract from the distance 
%	      between these markers to get the 
%            segment's "length,"which is used to 
%            find the CM location & the interita.
MODEL   =[ 10 11  foot_offset_ang 0;             ... % foot
           10  9  0               0;             ... % leg (calf)
            9  8  0               0;             ... % thigh
            8  7  0               0;             ... % pelvis
            7  3  0              -Vneck;         ... % trunk
            4  5  0               0;             ... % humerous
            5  6  0               wrist2hand;    ... % forearm
            3  2  0               Vneck];            %... head & neck
MODEL=[MODEL L];                                     % add lengths to MODEL
col_labels=['start marker #' char(9)             ... % make a row of labels
          'end marker #' char(9)                 ... % separated by tabs (9)
          'offset angle (rad)' char(9)           ... %...
          'offset magnitude' char(9)              ... %...
          'L: segment length' char(9)]; %            %...

%_______ SEGMENT ANGLES :_________
for seg=1:num_seg, %                                 % loop for each segment
  ang(seg)=mean(angle_2d(o_vect,i_vect,          ... % calc angles accordingly
    M(:,:,MODEL(seg,1)),M(:,:,MODEL(seg,2)),0))  ... %...
    + MODEL(seg,3);                                  % add appropriate offset
  if     abs(ang(seg)+2*pi)<abs(ang(seg)), %         % adjust so its +or- 180
    ang(seg)=ang(seg)+2*pi; %                        %
  elseif abs(ang(seg)-2*pi)<abs(ang(seg)), %         %
    ang(seg)=ang(seg)-2*pi; %                        %
  end %                                              % end if abs(...
  if ~noverbose,fprintf('.');pause(.01);end          % blip message
end; %                                               % end for seg loop 
MODEL=[MODEL ang];                                   % add lengths to MODEL
col_labels=[col_labels                           ... % append row of labels
  'ang: horiz posterior to seg axis'  char(9)];  ... % separated by tabs (9)

%___SEG CM LOCATIONS FROM SEGMENT ORIGIN___
%___ rs=fraction of L from segment's origin to CM ___
rs(1)=0.500;%                                        % horiz: ankl to foot CM
rs(2)=0.567;                                         % leg distal end to CM 
rs(3)=0.567;                                         % thigh distal end to CM 
rs(4)=0.895;                                         % pelvis distal end to CM 
rs(5)=0.370;                                         % thorax&abdomen L4L5 to CM
rs(6)=0.436;                                         % upper arm shldr2 to CM
rs(7)=0.682;                                         % lower arm&hand elbow to CM 
rs(8)=1.000;                                         % head& neck c7t1 to CM(ear)
rs(4)=0.522;                                         % pelvis distal end to CM 
rs(5)=0.497;                                         % thorax&abdomen L4L5 to CM 
r=rs.*L;                                             % use scale to find CM dist
phi=zeros(num_seg,1);                                % assume all CMs lie on the 
                                                     % seg axis (for now)
MODEL=[MODEL rs r phi];                              % add CM location to MODEL
col_labels=[col_labels                           ... % append row of labels
  'rs: fract of L from seg origin to CM' char(9) ... % make a row of labels
  'r: seg origin to CM' char(9)                  ... % separated by tabs (9)
  'phi: offset angle (rad)' char(9)];%               %...

%___ SEG CM ANGLE phi FROM SEG AXIS :___
%___ SEG. MASS SCALE FACTORS (WINTER, 1990):___
ms(1)=2*0.0145; %                                    % foot		
ms(2)=2*0.0465; %                                    % leg		
ms(3)=2*0.1000; %                                    % thigh		
ms(4)=1*0.1420; %                                    % pelvis 
ms(5)=1*0.3550; %                                    % thorax & abdomen 
ms(6)=2*0.0160; %                                    % upper arm 
ms(7)=2*0.0280; %                                    % lower arm & hand
ms(8)=1*0.0810; %                                    % head & neck 

%___ REFINE SOME SEGMENTS (PLAGENHOEF Table 3-5):___
if gender=='m',                                      % IF MALE SUBJECT
  ms(2)=0.119; %                                     % leg		
  ms(3)=0.210; %                                     % thigh		
  ms(4)=0.137; %                                     % pelvis 
  ms(5)=0.321; %                                     % thorax & abdomen 
  ms(6)=0.066; %                                     % upper arm 
  ms(7)=0.051; %                                     % lower arm 
  ms(8)=0.096; %                                     % head & neck 
elseif gender=='f',                                  % IF FEMALE SUBJECT 
  ms(2)=0.129; %                                     % leg		
  ms(3)=0.230; %                                     % thigh		
  ms(4)=0.159; %                                     % pelvis 
  ms(5)=0.304; %                                     % thorax & abdomen 
  ms(6)=0.060; %                                     % upper arm 
  ms(7)=0.041; %                                     % lower arm 
  ms(8)=0.077; %                                     % head & neck 
end                                                  % end switch gender
m=ms*mass;                                           % use scale to find masses
MODEL=[MODEL ms m];                                  % add lengths to MODEL
col_labels=[col_labels                           ... % append row of labels
  'ms: fract of bodymass seg mass' char(9)       ... % make a row of labels
  'm: seg mass' char(9)];%                           %...

%__RADII OF GYRATION & Inertia ABOUT CM (WINTER, 1990)__
Rgyr(1)=0.475; %                                     % foot 
Rgyr(2)=0.302; %                                     % leg	
Rgyr(3)=0.323; %                                     % thigh 
Rgyr(4)=0.495; %                                     % ?pelvis: use head
Rgyr(5)=0.400; %                                     % ?thorax&abdomen: use .4
Rgyr(6)=0.322; %                                     % upper arm 
Rgyr(7)=0.303; %                                     % lower arm 
Rgyr(8)=0.495; %                                     % head & neck
I=m.*(Rgyr.*L).^2; %                                 % I=f(Rgyr,m,L) see Winter
MODEL=[MODEL Rgyr I];                                % add mass to MODEL
col_labels=[col_labels                           ... % append row of labels
  'Rgyr: radii of gyration per seg length' char(9)... % make a row of labels
  'I: seg Inertia about its CM' char(9)];%           %...

%___ DEFINE HOW EACH SEGMENT IS CONNECTED TO __
% OTHERS (VECT FROM CONNECTING SEGMENT'S ORIGIN 
% TO CURRENT SEGMENT'S ORIGIN). Each row of this 
%  matrix represents a segment, and 
%	COL 1 is the CONNECTING SEGMENT'S 
% 	      Number, i.e., the head's connecting 
%             segment is the trunk (5).
%	COL 2 is the CONNECTING SEGMENT'S 
%	      magnitude of the vector connecting 
%	      segment's origin to the current 
%	      segment's origin.
%	COL 3 is the CONNECTING SEGMENT'S 
%	      vector angle of the vector connecting 
%	      segment's origin to the current 
%	      segment's origin. Angle is measured 
% 	      counterclockwise from the connecting 
%	      segment's major axis to the 
%	      connecting vector.
MODEL=[MODEL [0 0           0;                      ... % ground to foot
              1 0           0;                      ... % foot to leg (calf)
              2 L(1)        0;                      ... % leg to thigh
              3 L(2)        0;                      ... % thigh to pelvis
              4 L(3)        0;                      ... % pelvis to trunk
              5 waist2shldr shldr_offset_ang;       ... % trunk to humerous
              6 L(6)        0;                      ... % humerous to forearm
              5 L(5)        0                ]];        % head&neck to trunk 
col_labels=[col_labels                              ... % append to labels
          'connects to seg #' char(9)		       ... %...
          'connecting seg vect mag' char(9)	       ... %...
          'connecting seg vect ang (rad)'];             %...
if ~noverbose,fprintf(' DONE.'); end;%                  % message

%__ CONSTUCT HEADER __
Hout=str2mat(                                        ...% put lines in header
      ['Model structure definition file.'],          ...%...
      ['Created ' whenis(clock)                      ...%...
       ' using ' prog_name '.'],                     ...%...
      ['This was generated from datafile ' INname    ...%...
       ', trial #' num2str(trial) ', frames '        ...%...
       num2str(startend(1)) ' through '              ...%...
       num2str(startend(2)) '.'],                    ...%...
      ['Each row below represents a segment:'],      ...%...
      [32*ones(num_seg,4) segnames],                 ...%...
      ['The average ankle location (x,y) [m]: '      ...%...
       char(9) num2str(mean(ankle(:,1)))             ...%...
       char(9) num2str(mean(ankle(:,2)))],           ...%...
      ['The average angle from horizontal-'          ...%...
       'posterior to the ear-temple axis [rad]: '    ...%...
       char(9) num2str(mean(ear_temple_ang))],       ...%...
      [' - - - '],                                   ...%... 
      ['data begins below:'],	                       ...%... 
      col_labels);                                      %...

%__  WRITE TEXT OUTPUT FILE __
if OUTname, 					           % if outputname exists
  if ~noverbose|DEBUGIT,                                %
    fprintf(' writing..'); pause(.01);                  % message
  end                                                   %
  if mat2txt(OUTname,Hout,MODEL),                       % WRITE; IF CANT OPEN,
    error(' cant write file. Aborting');                % abort
  end;%                                                 % end if mat2dio
  if ~noverbose,fprintf(' DONE.'); end;%                % message
end; %                                                  % end if OUTname

fprintf('\nOUTPUT FILE: %s',OUTname); %                 % display out file name
 
fprintf(' ~ END %s ~ \n ', prog_name);                  % message

