% function errorflag=scd2htmus(fstem) - scd to muscle torque - Bedford '98
% Calculates torque on head due to tissues of the neck. 
%
%
% SYNTAX:	errorflag=scd2htmus(fstem);
% INPUTS:	fstem		filename root of scd file (is also used for output filename
% OUTPUTS:	[fstem.hti head net torque dataio file
%           errorflag == 0 (FALSE see param.m) if executes correctly
% CALLS:	ghk3.m 
% CALLED BY: 	
% REVISIONS: 	MAY/15/1998 initiated by D.F. Bedford
%                          based on scd2htgi.m, which was
%                          based on scd2htnet.m, which was
%                          based on scd2gha.m, which was
%                          based on Patton's scd2cop.m
% 
% NOTES:	An attempt was made to keep format similar to 
%		   Patton's scd2___ family of programs
%        and IO routines were taken from Patton's scd2cop.m
%        see also 'Information About Head Angles.doc',
%                 'Inverse Model Information.doc',
%                  datatype_list.doc,
%                  and Datio_format.doc.
%
% ~~~~~~~~~~~~~~~~~~~~~~   Bedford 1998   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~





% ~~~~~~~~~~~~~~~~~~~~~~~~~~~ begin: ~~~~~~~~~~~~~~~~~~~~~~~~~~~

function errorflag=scd2htmus(fstem);

param;

OFEXTEN='htmus'; % output file extension; see datatype_list.doc
DATATYPENUMBER=5060; % see datatype_list.doc
outputheadermessage=abs(['HTMUS Nm'])'; % create ascii header code


errorflag=FALSE; % will be set true if there's a problem

if nargin==0
   error('SCD2HTMUS: You must supply the stem of the scd filename.');	% if #input arguments == 0
elseif nargin==1,					% if just root is given
   INname=[ fstem,['.scd']];				% add on correct extension
   OUTname=[ fstem,['.', OFEXTEN]];				% add on correct extension 
else							% if input & output given
   error('SCD2HTMUS: Supply only the stem of the scd filename.');
end




%____ LOAD INPUT FILE ____

[H,D,Ntrials,Nrecs]=dio2mat(INname,1);	% load/check block
len=length(D(:,1));	% number of time steps

if H==-1, 						% if cant read
   errorflag=TRUE;						% set error flag to return an error status
   fprintf('\nSCD2HTMUS: cant read %s. Aborting. \n', INname);	% message
   return; 						% abort if cant read
end							% end if cant read



% calculate graviational head angle for each trial
Htmus=[];
Dtmus=[];

for trial=1:Ntrials % loop for each trial
   
   % get head kinematics
   [com cor gha h]=ghk3(H,D,trial);
   
   % create etime vector
   ttv=0; %temp time value
   for ttvi=1:len % temp time vector index
      etime(ttvi)=ttv;
      ttv=ttv+(h(9,1)/1000);
   end 
   
   
   % estimate mass of head
   bodymassinkg=textract('readme.txt','mass(kg)');
   mhead= fobmih * bodymassinkg; % calculate mass of head from mass of body                           
   
   % run inverse model and calculate torque components
   [tnet tgi tmus ti]=ssidm(com,cor,gha,etime,mhead);
   
   
   if h(10)==-9999 | h(10)==-99999,     % if bad trial, dont change
      fprintf('\nSCD2HTMUS: Bad trial %d: keeping -9999 in header.\n',trial);	% message
      tmus=zeros(len,1);					 % out data is zeros
      h(2,:)=[-9999];				       % make sure we have -9999
   end % end if h(10)==-99999
   
   %____ ADJUST HEADER FOR THIS RECORD ____ 
   h(2,:)=[DATATYPENUMBER];					% put new data type #s
   h(13:20,:)=outputheadermessage;		   % put header info in end
   Htmus=[Htmus h];			% append ouput header
   Dtmus=[Dtmus tmus];		% append ouput data (tnet) 
   
end % looping through trials


%__  WRITE DATAIO OUTPUT FILE __ 

if mat2dio(OUTname,Htmus,Dtmus),			% WRITE FILE; IF CANT OPEN,
   error('SCD2HTMUS: cannot write output file. Aborting');		% abort
end 							% end if mat2dio

fprintf('\nSCD2HTMUS: OUTPUT FILE: %s',OUTname); 		% display output file name
