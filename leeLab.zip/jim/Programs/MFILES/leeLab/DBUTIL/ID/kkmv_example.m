% kkmv.m -  kinematic and kinetic measures; Vision; (single segment model)
% Kkmv calculates kinematic and kinetic measures for trials from the Vision experiment. 
% It calls ssidm.m, the single segment inverse dynamic model. 
%
% Bedford 1997 & 1998


% ~~~~~~~~~~~~~~~~~~~~~~~~~~~  begin  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

% ... clear variables used in the program

clear subjectlist; % the concatentation of the two-letter subject identifiers
clear subj;        % as the program loops through subjects, 
                   % subj stores the subject id of the current subject
clear firstblock;  % at which block is analysis to begin? 
clear lastblock;   % at which block is analysis to end? 


% over which blocks to calculate measures
% note: can exclude adaptation now or later
firstblock=1;     %  1 for whole experiment,  6 or 8 to exclude adaptation
lastblock=12;     % 12 for whole experiment, 10 to exclude vision
% IMPORTANT NOTE: rp.m can easily screen for correct blocks.

% load software, anatomical and heuristic parameters - see param.m
param;


fid=fopen('kkmvout.dat','w');
for i0=1:2:length(subjectlist)     % loop through subjects  
   subj=subjectlist(i0:i0+1);		  % identify the subject
   
   permat = [3 6]; % pull force bins centered at 35% and 65%
   
   for block=firstblock:lastblock
      
      clear eeeinfo;    % used to trap bad trials
      clear Ntrials;    % number of trials in block
      clear efreq;      % elite collection frequency
      clear etime;      % marker trajectory time vector
      clear fname;      % file name (elite eee files)
      clear pathfname;  % path and file name (elite eee files)
      clear dname;      % file name (___dv.txt files)
      clear pathdname;  % path and file name for ___dv.txt
      clear dvdata;     % subject and block specific summary data
      clear vtok2check; % output of vtok2 for this trial
      
      %READ IN APPROPRIATE FILES
      %Read in the .eee and dv.txt files
      fname=fileid3(subj,block,'.eee');
      pathfname=[drive,'\data\vision\',subj,'\',fname];
       if exist(pathfname,'file')==0
          fprintf('\n KKMV: warning %s block %d does not exist; skipping.\n',subj,block);
       else
          
          
          [eeeinfo,Ntrials,efreq,etime]=inopen3(pathfname,1); % ',1' is noverbose
          dname=fileid3(subj,block,'dv.txt');
          pathdname=[drive,'\data\vision\',subj,'\',dname];
          dvdata=loadf(pathdname);
          
          if eeeinfo~=-9999 % if the block does not exist go no further
             
             
             for trial=1:10
                
                % clear trial-specific variables
                clear emark;      % elite marker positions
                clear eheader;    % elite header information
                clear D;          % trial-specific portion of dvdata
                clear visi;       % output of vision function for this trial
                clear tCMon;      % index to time vector (ITTV) at initiation of BODY CoM movement
                clear tCMoff;     % ITTV at zero velocity (pseudo-cessation) of BODY CoM movement
                clear tFon;       % ITTV at pulling force onset
                clear tFoff;      % ITTV at pulling force offset
                clear tBon;       % ITTV at beginning of baseline condition
                clear tBoff;	   % ITTV at end of baseline condition
                clear tstart;     % ITTV for start of measure calculation
                clear tend;       % ITTV for end of measure calculation
                clear ear;        % ear marker trajectory
                clear temple;     % temple marker trajectory
                clear ha;         % head angle trajectory
                clear tnet;       % net torque
                clear tgi;        % gravito-inertial torque
                clear tmus;       % muscle (aggregate tissue) torque
                clear com;        % HEAD CoM trajectory
                clear cor;        % head-neck CoR trajectory
                clear emark;      % raw marker trajectories
                clear header1;    % eeefile header: used for trapping bad trials
                clear D;          % trial specific entry in dvdata file
                clear per;        % returned value from neartarv  0, 3, or 6 depending on pull
                clear pullperc;   % used for force output column label
                clear vtok2check; % flag used with old vision trial integrity checking routine
                clear visi;       % flag used to label whether trial is with or without vision
                clear m1;         % first measure column - see mcalc.m
                clear m2;         % second measure column - see mcalc.m
                clear m3;         % third measure column - see mcalc.m
                clear m4;         % fourth measure column - see mcalc.m
                clear m5;         % fifth measure column - see mcalc.m
                clear m6;         % sixth measure column - see mcalc.m
                clear m7;         % seventh measure column - see mcalc.m
                clear m8;         % eighth measure column - see mcalc.m
                clear m9;         % ninth measure column - see mcalc.m
                clear m10;        % tenth measure column - see mcalc.m
                
                drawnow; % flush the event queue
                
                vtok2check=vtok2(subj,block,trial);
                
                if vtok2check==0 | vtok2check==2
                   if vtok2check==2
                      fprintf('\nKKMV: VTOK failure. Exiting.\n');
                   end %if vtok2 failed
                else
                   
                   % read the eee data for this trial
                   [emark,header1]=readdio(eeeinfo,trial);
                   % ... and change emark from mm to m
                   emark=emark/1000;
                   
                   % select this trials piece of dvdata
                   D=dvdata((trial-1)*6+1:(trial-1)*6+6,:);
                   
                   if (header1(10,1)==-9999 | D(2,1:11)==-99999)  %BAD DATA
                      fprintf('%s b:%d t:%d is bad. Skipping this trial\n'...
                         ,subj, block, trial);
                   else	
                      per=neartarv(D,permat,pullaccuracy);  % 10 percent bin width 
                      
                      pullperc=0; % will persist if pull for this trial is near neither target force
                      
                      if per==3
                         pullperc=35; % 35% pull
                      end
                      
                      if per==6
                         pullperc=65; % 65% pull
                      end
                      
                      
                      visi=vision(subj,block); % vis is 1, eyes were open, if vis is 2, eyes were closed              
                      
                      %DEFINE TIME PERIODS:
                      %N.B. define all times then select tstart and tend below
                      tCMon=round(D(3,2)*efreq)+1;
                      tCMoff=round(D(3,3)*efreq)+1;
                      tFon=round(D(2,2)*efreq)+1;
                      tFoff=round(D(2,3)*efreq)+1;
                      tBon=round(D(2,10)*efreq)+1;
                      tBoff=round(D(2,11)*efreq)+1;	
                      
                      
                      % set start and end time for calculations
                      % just the pull for Neuroscience Letters
                      tstart=tFon;
                      tend=tFoff;
                      %tstart=tCMon;
                      %tend=tCMoff;
                      
                      % get head angle, CoM and CoR position from elite markers	
                      [com cor ha]=ghk2(emark, tBon, tBoff); % note: RADIANS!
                      
                      % computer head angular velocity
                      hav=vel(etime, ha);
                      
                      %COMPUTE TORQUE COMPONENTS
                      mhead= fobmih * D(1,8); % calculate mass of head from mass of body                           
                      [tnet tgi tmus ti]=ssidm(com,cor,ha,etime,mhead);
                      
                      
                      % CALCULATE MEASURES
                      [m1 m2 m3 m4 m5 m6 m7 m8 m9 m10 m11 m12 m13]=mcalc(hav,tnet,tgi,tmus,ti,tstart,tend);
                      % --- see mcalc for measure definitions
                      
                      
                      % BEGIN FILTERING FOR BAD TRIALS
                      % important note: following filter is by J.W. Steege. 
                      % vtok2 now only allows trial which pass its test to be
                      % output by kkmv. So: all trials which are output by kkmv
                      % would have their vtok entry = 1. We use this fact and 
                      % use this effectively spare column setting this value
                      % to zero where the trial fails Julie's test for angle
                      % continuity. BEDFORD '98
                      % ..................
                      % begin Steege continuity filter
                      
                      % set head angular velocity cutoff in degrees per second
                      dpscutoff=250;
                      % (1) at 250 degrees per second,  cutoff < 1% trials fail
                      % (2) of the failng trials, visual inspection certifed 63% as suspect
                      % (3) quality of remainder unclear
                      
                      for i_ha=2:length(ha)
                         if abs(ha(i_ha)) - abs(ha(i_ha-1))>10*2*pi/360 % ha is in radians (* first # by 50 for max deg /s)
                            fprintf('KKMV: %s b:%d t:%d failed angle continuity; setting vtokcheck=0.\n', subj, block, trial);
                            vtok2check=0; 
                            break;
                         end % if fail angle continuity
                      end % looping through head angle
                      clear i_ha;
                      if max(ha)-min(ha)>70*2*pi/360
                         fprintf('KKMV: %s b:%d t:%d failed angle change magnitude test; setting vtokcheck=0.\n', subj, block, trial);
                         vtok2check=0; 
                      end % if head angle change is not feasible
                      % end Steege angle continuity and change magnitude filter
                      % ..................
                      
                      % subject JM, block 8 is dodgy see inopen3's report on records/trial
                      % for these trials set the vtok2check
                      %if subj=='jm' & block==8 & trial>3
                      %  vtok2check=0;
                      %end %if
                      % 
                      % VISUAL INSPECTION OF JM B8 T4:8 INDICATES THAT THESE ARE OK
                      % JM B8 T9:10 ARE BAD TRIALS AND WILL NOT BE PROCESSED
                      
                      
                      animate=0;
                      if animate                 
                         %~~~~~~~~~~~~~ validation animatation ~~~~~~~~~~~~~~~~~~~~~
                         [temple ear]=ghm(emark); % need for validation plot
                         %tic
                         
                         % set up validation figure boxes
                         
              
                         figure(1);
                         set(gcf,'position',[200 450 300 300]);
                         set(gcf,'menubar','none');
                         figure(2);
                         set(gcf,'position',[600 450 300 300]);
                         set(gcf,'menubar','none');
                         
                         for animate=tCMon:3:length(com(1:tCMoff,X))
                            
                            figure(1);
                            clf;
                            hold on;
                            plot(com(animate,X)-cor(animate,X),com(animate,Y)-cor(animate,Y),'+');
                            plot(cor(animate,X)-cor(animate,X),cor(animate,Y)-cor(animate,Y),'o');
                            plot(temple(animate,X)-cor(animate,X),temple(animate,Y)-cor(animate,Y),'p');
                            plot(ear(animate,X)-cor(animate,X),ear(animate,Y)-cor(animate,Y),'*');
                            axis([-0.08 0.02 0 0.1])
                            
                            figure(2);
                            clf;
                            hold on;
                            plot(com(animate,X),com(animate,Y),'+');
                            plot(cor(animate,X),cor(animate,Y),'o');
                            plot(temple(animate,X),temple(animate,Y),'p');
                            plot(ear(animate,X),ear(animate,Y),'*');
                            %axis([min(min(temple(:,X))) max(max(cor(:,X))) min(min(cor(:,Y))) max(max(temple(:,Y)))]);
                            axis([-0.3 0.2 1.1 1.6]);                       
                            
                            for j=1:10
                               drawnow;
                            end
                            
                            hold off;
                         end % for animate
                         %toc 
                         %pause(1);
                         close(1);
                         close(2);
                      end % if animate
                      %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                      
                      
                      % add line to file
                      fprintf(fid,'%d %d %d %d %d %d %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f\n',...
                         i0,block,trial,pullperc,visi,vtok2check,m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13);
                      fprintf('%d %d %d %d %d %d %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f %6.6f\n',...
                         i0,block,trial,pullperc,visi,vtok2check,m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13);
                      
                      % ..................
                   end % if block does not exist ... ELSE ...
                end % if vtok2check BAD ... ELSE ...
             end % if not a bad trial 
          end % looping through trials
       end % if eeeinfo not equal to -9999
    end % looping through blocks
end % subject loop

fclose('all');

% ################################ FIN ##################################


