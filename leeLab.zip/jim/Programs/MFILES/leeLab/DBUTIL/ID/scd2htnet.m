% function errorflag=scd2htnet(fstem) - scd to head "net" torque - Bedford'98
% Calculates net torque on head from scd data file. 
%
% SYNTAX:	errorflag=scd2htnet(fstem);
% INPUTS:	fstem		filename root of scd file (is also used for output filename
% OUTPUTS:	[fstem.htnet head net torque dataio file
%           errorflag == 0 (FALSE see param.m) if executes correctly
% CALLS:	ghk3.m 
% CALLED BY: 	
% REVISIONS: 	MAY/12/1998 initiated by D.F. Bedford
%                          based on scd2gha.m, which was
%                          based on Patton's scd2cop.m
% NOTES:	An attempt was made to keep format similar to 
%		   Patton's scd2___ family of programs
%        and IO routines were taken from Patton's scd2cop.m
%        see also 'Information About Head Angles.doc',
%                 'Inverse Model Information.doc',
%                  datatype_list.doc,
%                  and Datio_format.doc
%
% ~~~~~~~~~~~~~~~~~~~~~~ Bedford 1998 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~





% ~~~~~~~~~~~~~~~~~~~~~~~~~~~ begin: ~~~~~~~~~~~~~~~~~~~~~~~~~~~
function errorflag=scd2htnet(fstem);


param;

OFEXTEN='htnet'; % output file extension; see datatype_list.doc
DATATYPENUMBER=5040; % see datatype_list.doc
outputheadermessage=abs(['HTNET Nm'])'; % create ascii header code



errorflag=FALSE; % will be set true if there's a problem

if nargin==0
   error('SCD2HTNET: You must supply the stem of the scd filename. ');	% if #input arguments == 0
elseif nargin==1,					% if just root is given
   INname=[ fstem,['.scd']];				% add on correct extension
   OUTname=[ fstem,['.', OFEXTEN]];				% add on correct extension 
else							% if input & output given
   error('SCD2HTNET: Supply only the stem of the scd filename.');
end




%____ LOAD INPUT FILE ____

[H,D,Ntrials,Nrecs]=dio2mat(INname,1);	% load/check block
len=length(D(:,1));	% number of time steps

if H==-1, 						% if cant read
   status=1;						% status to "error"
   fprintf('\nSCD2HTNET: cant read %s. Aborting. \n', INname);	% message
   return; 						% abort if cant read
end							% end if cant read



% calculate graviational head angle for each trial
Htnet=[];
Dtnet=[];

for trial=1:Ntrials % loop for each trial
   
   % get head kinematics
   [com cor gha h]=ghk3(H,D,trial);
   
   % create etime vector
   ttv=0; %temp time value
   for ttvi=1:len % temp time vector index
      ttv=ttv+(h(9,1)/1000);
      etime(ttvi)=ttv;
   end 
   
   save etime etime
   
   % estimate mass of head
   mhead=fobmih * D(1,8); % calculate mass of head from mass of body                           
   
   % run inverse model and calculate torque components
   [tnet tgi tmus ti]=ssidm(com,cor,gha,etime,mhead);
   
   if h(10)==-9999 | h(10)==-99999,     % if bad trial, dont change
      fprintf('\nSCD2HTNET: Bad trial %d: keeping -9999 in header.\n',trial);	% message
      tnet=zeros(len,1);					 % out data is zeros
      h(2,:)=[-9999];				       % make sure we have -9999
   end % end if h(10)==-99999
   
   %____ ADJUST HEADER FOR THIS RECORD ____ 
   h(2,:)=[DATATYPENUMBER];					% put new data type #s
   h(13:20,:)=outputheadermessage;		   % put header info in end
   Htnet=[Htnet h];			% append ouput header
   Dtnet=[Dtnet tnet];		% append ouput data (tnet) 
   
end % looping through trials



%__  WRITE DATAIO OUTPUT FILE __ 

if mat2dio(OUTname,Htnet,Dtnet),			% WRITE FILE; IF CANT OPEN,
   error('SCD2HTNET: cannot write output file. Aborting');		% abort
end 							% end if mat2dio

fprintf('\nSCD2HTNET: OUTPUT FILE: %s',OUTname); 		% display output file name




