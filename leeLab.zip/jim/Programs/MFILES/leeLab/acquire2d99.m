% *********** *** MATLAB M function ACQUIRE2D99.M *********** **
% Batch the processing of output from the ACQUIRE program (force, EMG, etc.)
% SYNTAX:       status=acquire2d99(fileroots,loadcelChannel,duration);
% INPUT ARGS:   fileroots      filename root string list (extensions removed)
%                              Each line is a file (block) root.
%               loadcelChannel (optional) Acquire ch for loadcell
%               duration       (optional) desired final time (s) 
% INPUT FILES:  fileroot.DDD   ACQUIRE file created from pc-proc(DATAIO FORMAT)
% OUTPUTS       status         =zero if all went well
% CALLS:        dcheck.m       CHECK AND REPAIR MOTION  FILE
%               loadcell.m     CONVERT LOAD CELL VOLTS TO FORCE (N)
%               dtrans.m       transform forceplate coords to "lab" coords
% CALLED BY:    - 
% EXAMPLE:      acquire2d99(['lx1';'lx2';'lx3';'lx4';'lx5';'lx6';'lx7';'lx8']) 
%               will run the steps below on blocks 1-8 of subject lx 
% REVISIONS:    5/28/97 by Patton. Initiated from scd.m
%               6/8/98 named batch_BOS1.m
%               6/15/98 split the acquire & elite post processing apart & 
%                       named it "batch_BOS1a.m"
%					 8/10/98 batch_bos1a renamed acquire2d99 
% NOTE:         Spaces, not tabs when writing code make it most portable
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~ begin: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

function status=acquire2d99(fileroots,loadcelChannel,duration);

%_____ SETUP VARS _____
global DEBUGIT                                       % nonzero=debugging
if DEBUGIT, fprintf('\nVerbose'); end; %if           % MESSAGE
prog_name='ACQUIRE2D99.M';                              % this program's name
fprintf('\n ~ %s ~ \n BATCH PROCESSING:',prog_name)  % orient user
fileroots                                            % list filerootnames
status=0;                                            % START WITH OK STATUS
numblocks=length(fileroots(:,1));                    % NUMBER OF FILES IN LIST
sep='\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n'; fprintf(sep)% separator string
if ~exist('loadcelChannel'), loadcelChannel=9, end   % Acquire ch for loadcell
if ~exist('duration'), duration=5, end               % desired final time (s)

%_____ BEGIN LOOP FOR ACQUIRE PROCESSING _____ 
for block=1:numblocks 

  %_____ SETUP PROCESSING THIS BLOCK _____ 
  fileroot=deblank(fileroots(block,:));              % ROOTNAME OF BLOCK
  eval(['diary ' fileroot '.log']); fprintf(sep);    % enter commands in logfile 
  fprintf('\n%s ACQUIRE post-processing of %s',  ... % message
    prog_name,fileroot);                             %
  fprintf('\n~%s(%s)~',prog_name,whenis(clock));     % message
  fprintf('\n PROCESSING block "%s": \n',fileroot);  % MESSAGE
  fprintf('BEGIN at %s,\n\n',whenis(clock));         % 

  %_____ acquire processing _____ 
  fprintf(sep);                                      % display separator string
  pc_proc2(fileroot);                                % ACQUIRE to DIO format
  [status,Ntrials]=dcheck(fileroot);                 % CHECK AND REPAIR 
  fprintf(sep);                                      % display separator string 
  loadcell(fileroot,loadcelChannel);                 % CONVERT VOLTS TO FORCE
  fprintf(sep);                                      % display separator string 
  dtrans(fileroot);                                  % ROTATE TO "LAB" COORDs
  fprintf(sep);                                      % display separator string 
  d992cop(fileroot);                                 % COP calculations

  %_____ wrap up this block _____
  fprintf('\n%s ACQUIRE post-processing of %s',  ... % message
    prog_name,fileroot);                             %
  fprintf('DONE at %s,\n\n',whenis(clock));          % 
  fprintf(sep); diary off;                           % turn off logfile

end %for block                                       % end block loop

%_____ END OF PROGRAM _____ 
fprintf([sep '\n ~ END %s @%s ~\n\n\n\n'],       ... % message
  prog_name,whenis(clock))                       % 
return;

