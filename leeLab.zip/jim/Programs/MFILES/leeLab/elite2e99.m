% *********** *** MATLAB M function ELITE2E99.M (Aaron Markworth)*********** **
% Batch the processing of output from the ELITE program (Motion), combines w/ ACQUIRE and makes .scd.
% SYNTAX:       status=elite2e99(fileroots,duration, ...
%                                  Nmrkrs,rezero_marker,rezero_offset,noSynchLight,RECS,print_or_not);
% INPUT ARGS:   fileroots      filename root string list (extensions removed)
%                              Each line is a file (block) root.
%               duration       (optional) desired final time (s) 
%               Nmrkrs         (optional) desired # markers tracked  
%               rezero_marker  (optional) subtract this marker's
%                              average location from 
%                              all ELITE data 
%               rezero_offset  (optional) subtract this from 
%                               all ELITE data
%               noSynchLight   (optional)nonzero for no synchlight
%               RECS           (optional)list of records that yu want to plot 
%                              using plot_DIO.m see plot_DIO.m to see how to make RECS
%               print_or_not   (optional)if you want a post script plot file generated
% INPUT FILES:  fileroot.EEE   ELITE file created from el-proc (DATAIO FORMAT)
% OUTPUTS       status         =zero if all went well
%               fileroot.scd   FINAL COMBINED, INTERPOLATED, & SYNCHRONIZED DATA
%                              PLUS MULTIPLE INTERMEDIATE FILES.(see protocols) 
% CALLS:        el_proc2.m     ELITE output to DIO
%               echeck         CHECK AND REPAIR ACQUIRE FILE
%               etrans.m       transform forceplate coords to "lab" coords
%               scd.m          SYNCRONIZE & COMBINE DATA
% CALLED BY:    - 
% EXAMPLE:      elite2e99(['lx1';'lx2';'lx3';'lx4';'lx5';'lx6';'lx7';'lx8']) 
%               will run the steps below on blocks 1-8 of subject lx 
% REVISIONS:    5/28/97 by Patton. Initiated from scd.m
%               6/8/98 named batch_BOS1.m
%               6/15/98 split the acquire & elite post processing apart & 
%                       named it "batch_BOS1b.m"
%					 8/4/98 batch_bos1b renamed raw2scd2
% NOTE:         Spaces, not tabs when writing code make it most portable
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~ begin: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

function status=elite2e99(fileroots,duration,Nmrkrs,rezero_marker,rezero_offset,noSynchLight,RECS,print_or_not);

%_____ SETUP VARS _____
global DEBUGIT                                       % nonzero=debugging
if DEBUGIT, fprintf('\nVerbose'); end; %if           % MESSAGE
prog_name='ELITE2E99.M';                            % this program's name
fprintf('\n ~ %s ~ \n BATCH PROCESSING:',prog_name)  % orient user
fileroots                                            % list filerootnames
status=0;                                            % START WITH OK STATUS
numblocks=length(fileroots(:,1));                    % NUMBER OF FILES IN LIST
sep='\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n'; fprintf(sep)% separator string
if ~exist('duration'), duration=5, end               % assume final time(s)
if ~exist('Nmrkrs'), Nmrkrs=14, end                  % desired # markers tracked
if ~exist('rezero_marker'), rezero_marker=13, end    % subtract this marker's
                                                     % average location from 
                                                     % all ELITE data 
if ~exist('rezero_offset'),rezero_offset=[0 0 0],end % subtract this from 
																	  % all ELITE data
if ~exist('RECS'),RECS=[],end								  % assume BOS plotting format
if ~exist('print_or_not'),print_or_not='y'; end;     % set default if no entry	

%_____ BEGIN LOOP FOR EACH FILE IN fileroots _____ 
for block=1:numblocks 

  %_____ SETUP PROCESSING THIS BLOCK _____ 
  fileroot=deblank(fileroots(block,:));              % ROOTNAME OF BLOCK
  eval(['diary ' fileroot '.log']); fprintf(sep);    % enter commands in logfile 
  fprintf('\n%s ELITE post-processing of %s',    ... % message
    prog_name,fileroot);                             %
  fprintf('BEGIN at %s,\n\n',whenis(clock));         % 

  %_____ Check for ACQUIRE files _____ 
  [h,d,Ntrials]=dio2mat([fileroot '.d99'],1);
  if h==-1, 
    fprintf('\nNOTE: ACQUIRE .d99 file missing!\n'); 
    error(['cannot find "' fileroot '.d99".  ']);
  end

  %_____ elite processing _____ 
  fprintf(sep);                                      % display separator string 
  el_proc2(fileroot,Ntrials,duration,Nmrkrs,'rif');  % ELITE output to DIO
  fprintf(sep);                                      % display separator string 
  echeck(fileroot);                                  % CHECK AND REPAIR
  fprintf(sep);                                      % display separator string 
  e2meters(fileroot);                                % CONVERT MM TO M 
  fprintf(sep);                                      % display separator string 
  etrans(fileroot,rezero_marker,rezero_offset);      % TRANSLATE ORIGIN 
  
  %___ synchronize & combine with acquire data ___
  fprintf(sep);                                      % display separator string 
  if exist([fileroot '.d99'])
     scd(fileroot,noSynchLight);                     % SYNCRONIZE&COMBINE DATA
  else
     fprintf('no .d99 found, not combining by scd.m!');         
  end 
     
  %_____ wrap up this block _____
  fprintf('\n%s ELITE post-processing of %s',    ... % message
    prog_name,fileroot);                             %
  fprintf('DONE at %s,\n\n',whenis(clock));          % 
  fprintf(sep); diary off;                           % turn off logfile

end %for block                                       % end block loop

%_____ PRINT SCD FILES _____ 
fprintf('\n PLOTTING...');  									% MESSAGE
for block=1:numblocks 
  fileroot=deblank(fileroots(block,:));              % ROOTNAME OF BLOCK
  fprintf(sep);                                      % display separator string 
  plot_DIO([fileroot '.scd'],RECS,'y',print_or_not);          % do it
end %for block                                       % end block loop

%_____ END OF PROGRAM _____ 
fprintf([sep '\n ~ END %s @%s ~\n\n\n\n'],       ... % message
  prog_name,whenis(clock))                           % 
return;

