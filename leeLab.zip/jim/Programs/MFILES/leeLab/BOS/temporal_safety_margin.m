% ************** MATLAB "M" file  (jim Patton) *************
% Calculate the minimum time to edge ("temporal safety margin").
% (PREDICT THE COP FUTURE & BOUNDARY CROSSING BASED ON POS, VEL, AND ACCEL)
%  INPUTS:      COP    center of pressure in the posterior direction, 
%                      rezeroed so that zero is the toe. (A column vector)
%               lf     length of the foot (scalar)
%               freq   sampling frequency in Hz (scalar)
%  OUTPUTS:     TSM
%  CALLS:       
%  INITIATIED:	4/3/99 jim patton from 'fcp5bdy.m' in the fcp project
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~


function [TSM, at_toe]=temporal_safety_margin(COP,lf,freq,plot_or_not,verbose)

%______ SETUP ______
if ~exist('verbose'),                   % if not given as input arg
  verbose=1;                            % do not plot
end                                     %
if verbose, 
  fprintf(' ~ temporal_safety_margin.m ~ ')
end
if ~exist('plot_or_not'),               % if not given as input arg
  plot_or_not='n';                      % do not plot
end                                     %
TTE=NaN*ones(length(COP),1);            % init
t_epsilon=.01;                          % extrap. time incr (sec)
len=length(COP);                        % # of time records
PJ=10;
time=(0:length(COP)-1)/freq; time=time';% reconstruct a time vect
TTE=Inf*ones(length(COP),1);            % predimention
E_at_toe=Inf*ones(length(COP),1);
maxjump=.7;                             % stop extrapolations (sec)

%______ PLOT SETUP & COP  ______
if plot_or_not=='y'                 ... % if ploting, 
  plot(time,COP,'r','linewidth',5);
  hold on;   
  %disp('  Pausing, pressa key..'); pause
  pause(.01);
  
  plot(  [0 5], [0 0],'b:',         ... % landmarks
         [0 5], [lf lf],'b:');
  text(0,lf, ' posterior limit',    ... %
     'fontsize',7,                  ... %
     'HorizontalAlignment','right');    %
  text(0,0,  ' anterior limit',     ... %
    'fontsize',7,                   ... %
    'HorizontalAlignment','right');     %
  title('COP Extrapolations');          %
end                                     % END if plot_or_not...
  
  
  %____ FILTER & DIFFERENTIATE COP ___      
  [B6,A6]=butter(3,6/(freq/2));           % design filter 6hz
  fCOP=filtfilt(B6, A6, COP);             % 2-pass-filter COP
  [dCOP,ddCOP]=dbl_diff(fCOP,freq,0);     % differentiate 2X

  %______ EXTRAPOLATIONS ______
  if verbose, 
    fprintf('\n Extrapolations: ');       % message
  end
  for i=1:len,                            % loop ea. instant
    if i/100==round(i/100),fprintf('.');end	 % message
    
      %___ 2nd ORDER EXTRAPOLATION ___
      ECOP=[]; Etime=[]; toe=.5;          % initialize
      for jump=1:1/t_epsilon,             % loop extrap.time
        Etime(jump)=jump*t_epsilon;       %
        ECOP(jump)=fCOP(i)            ... % predict COP
             + dCOP(i)*Etime(jump)    ... %
             +.5*ddCOP(i)*Etime(jump)^2;  %
        if ECOP(jump)>lf,                 % if at boundry-cross
          toe=0;                          % indicate no at toe
          break;                          % stop
        end;                              %
        if ECOP(jump)<0,                  % if at boundry-cross
          toe=1;                          % indicate at toe
          break;                          % stop
        end;                              %
      end                                 % END for jump
      
      TTE(i)=Etime(jump);                 % this instant's TIME2EDGE 
      E_at_toe(i)=toe;
      
      %___ PLOT ___
      if plot_or_not=='y'             ... %
       & i/PJ==round(i/PJ),               % not every time
        plot(Etime+time(i),ECOP,'b:')     %
        hold on;                          % 
      end                                 % END if plot_or_not...
      pause(.01)
    end                                   % END for i (ea. instant)

  if verbose, 
    fprintf('  Extrapolations Complete.\n '); 			% message
  end
  
  if plot_or_not=='y'                 ... %
    plot(time,fCOP,'y','linewidth',2);   
  end                                     % END if plot_or_not...

%___ TEMPORAL SAFETY MARGINS ___
  %fprintf('\n TTEsize=%d \n',size(TTE));
  [TSM,i]=min(TTE);                       % ''
  at_toe=E_at_toe(i);                     % indicate whether at toe