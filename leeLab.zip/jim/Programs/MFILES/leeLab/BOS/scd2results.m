% ************** MATLAB "M" functionn (jim Patton) *************
% Calc & Plot results for the BOS study and store in tabular text file.
%  SYNTAX:     
%  REVISIONS:  INITATED 3/31/99 by patton from junkplot.m
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function scd2results(verbose)

% _____SETUP & GET INFO_____
global DEBUGIT
prog_name='scd2results.m';
rfile=['readme.txt'];
fprintf('\n\n ~ %s function ~',prog_name);pause(.05);% display info
nb=12;                                               % number of blocks
MAXaxle=0;                                           % overall max
MINaxle=-5;                                          % overall min
blockNames='123456789abcde';                         % block codes in filenames
if ~exist('verbose'), verbose=1; end                 % if not given as input 
sep='\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n'; fprintf(sep)% separator string
fsz=6;                                               % 'fontsize'
%ID=IDs(10,:);  % FIX THIS LATER!

% _____SUBJ INFO_____
IDs=   ['AHX';                                        % subject namecodes
        'BSX';
        'CWX';
        'DBX';
        'EDX';
        'KHX';
        'KTX';
        'LMX';
        'LVX';
        'SGX';
        'SMX'];
Nsubj=length(IDs(:,1));
dir_name=cd;
ID=dir_name(1,length(dir_name)-2:length(dir_name));
ID=upper(ID)
for check=1:length(IDs), 
  if strcmp(ID,IDs(check,:)), subj=check, end;       % search for number
end; %

% _____ SET FORCEPLATE PARAMS _____
fp_origin_m  =[   0.0005  -0.0014   0.0365;     ...  % FP ORIGINS VECTs, where:
                  0.0005  -0.0014   0.1181;     ...  %  row 1=FP surface, 2=pvt 
                  0.0005  -0.0014   0.1007];         %  brd ht, & 3=axle ht
fp_center  =0.254;                                   % AP EDGE TO CNTR(M)
fp_origin=fp_origin_m(2,:);                          %

% _____ LOAD PARAMS _____
if ~(exist(rfile)-2)                                 % IF READ_ME EXISTS
  fprintf('\n loading: %s (readme file)...',rfile);  % MESSAGE
  ank2fp=textract(rfile,'horiz dist ankle to back'); % HEEL TO BACK OF FP
  lf    =textract(rfile,'foot length');              % LENGTH OF FOOT(M)
  a     =textract(rfile,'horiz dist ankle to heel'); % HORIZ ANKLE2HEEL
  mass  =textract(rfile,'mass');                     % BODY MASS (KG)
  height=textract(rfile,'height');                   % BODY HEIGHT (M)
  htSurf=textract(rfile,'BOS surface height');       %
  htAxle=textract(rfile,'BOS axle height');          %
  BOSa  =textract(rfile,'BOS anterior axle to toe'); %
  BOSp  =textract(rfile,'BOS posterior axle to toe');%
  pultarg=textract(rfile,'maxpul')*.6;               % pulling force target
  fprintf(' DONE. ');                                % MESSAGE
else error(['?? Cant find ' rfile '. Aborting.'])    %
end                                                  % 

% _____ DERIVE PARAMS _____
ankle=fp_center-ank2fp;
heel=ankle+a;
toe=heel-lf;
anterior_axle=toe+BOSa-.05;
posterior_axle=toe+BOSp+.05;

% _____ LOOP FOR EACH BLOCK _____
OUTPUT=[];
for block=1:nb,  %%2%1%
  
  fileroot=[ID blockNames(block)];
  eval(['diary ' fileroot '.log']); fprintf(sep);    % enter commds in logfile 
  
  %__ Calc COP w/appropriate Force plate __
  %__  instrument center depth (FPICD)   __
  if block<5 | (block>8&block<12),                   % thee blocks were "wide"
    FPICD=fp_origin_m(2,3);                          % pivot board surface ht
    narrow=0;
  else                                               % otherwise, "narrow" 
    FPICD=fp_origin_m(3,3);                          % use pivot board axle ht
    narrow=1;
  end                                                %
  if (exist([fileroot '.cop'])-2)                    % IF NO COP FILE EXISTs
    scd2cop(fileroot,FPICD);                         % calulate COP
  end                                                %
  
  %____ LOAD COP FILE ____
  INname= [fileroot '.cop'];
  if verbose,fprintf('\nINPUT: %s',INname);end    % message
  [COPh,COPd,Ntrials,Nrecs]=dio2mat(INname,1);       % load/check block
  if COPh==-1,                                       % if cant read
    status=1;                                        % status to "error"
    fprintf('\n cant read %s. Aborting. \n', INname);% message
    textappend([prog_name ' cannont find ' INname]);  % add to trouble.log
    diary off
    return;                                          % abort if cant read
  end                                                % end if cant read
  len=length(COPd(:,1));                                % number of time steps
  freq=COPh(12,1);                                   % get sampling freq
  if verbose, fprintf(' Done. '); pause(.01); end;   % message
  
  %____ LOAD AXLE DATA FROM SCD FILE ____
  INname= [fileroot '.scd'];
  if verbose,fprintf('\nINPUT: %s',INname);end       % message
  [SCDh,SCDd,Ntrials,Nrecs]=dio2mat(INname,1);       % load/check block
  if SCDh(1,1)==-1|COPh(1,1)==-1,                    % if cant read
    status=1;                                        % status to "error"
    fprintf('\n cant read a file! Aborting.\n');     % message
    textappend([prog_name ' cannont find ' INname]);  % add to trouble.log
    diary off
    return;                                          % abort if cant read
  end                                                % end if cant read
  if verbose,fprintf(' Extracting axle data..');end  % message
  [R_AXLEsD,R_AXLEsH]=dio_rec(SCDd,SCDh,2,451,1);    % EXTRACT REAR AXLE DATA
  [F_AXLEsD,F_AXLEsH]=dio_rec(SCDd,SCDh,2,452,1);    % EXTRACT FRONT AXLE DATA
  if length(R_AXLEsD)==0,
    [R_AXLEsD,R_AXLEsH]=dio_rec(SCDd,SCDh,2,7,1);    % EXTRACT REAR AXLE DATA
    [F_AXLEsD,F_AXLEsH]=dio_rec(SCDd,SCDh,2,8,1);    % EXTRACT FRONT AXLE DATA
  end  
  if verbose, fprintf(' Done. '); pause(.01); end;   % message
  
  % _____ LOOP FOR EACH TRIAL _____
  if verbose,                                        % message
    fprintf('\nProcessing Trial: ');                 %
    pause(.01);                                      %
  end;                                               %
  for trial=1:Ntrials,                               % LOOP FOR TRIALS1%
    if verbose,fprintf(' %d',trial);pause(.01);end;  % message
    
    peakPull=max(dio_rec(SCDd,SCDh,[3 2],[trial 201],1)); % THIS TRIAL's force
    normPeakPull=peakPull/(mass*height*8);           % fract of max
    pullError=(peakPull-pultarg)/pultarg;             % fract of target
    COP=dio_rec(COPd,COPh,[3 2],[trial 401],1);      % THIS TRIAL's COP
    R_AXLE=dio_rec(R_AXLEsD,R_AXLEsH,[3],[trial],1); % THIS TRIAL's REAR AXLE
    F_AXLE=dio_rec(F_AXLEsD,F_AXLEsH,[3],[trial],1); % THIS TRIAL's FRONT AXLE
    time=(0:length(COP)-1)./200; time=time';         % construct a time vector
    
    % ____________________________________
    % ________ CALC DATA BELOW HERE ______
    % ____________________________________
    
    % _____ DETERMINE A wobble FROM AXLE DATA ______
    if (min(R_AXLE)<-.5|min(F_AXLE)<-.5)&narrow,     %
      C='m'; lw=.1; wobble=1;                        %
    else                                             %
      C='k'; lw=2;  wobble=0;                        %
    end                                              % 
    
    % _____ CALC SSM ______
    if DEBUGIT,fprintf('SSM.');pause(.01);end;       % message             
    if block<5 | (block>8&block<12),                 % thee blocks were "wide"
      [SSM,idx]=min([heel-max(COP) min(COP)-toe]);   %
    else                                             %
      [SSM,idx]=min([posterior_axle-max(COP)     ... %
          min(COP)-anterior_axle]);                  %
    end                                              %
    SSM_at_toe=idx-1;                                % 1 for toe, 0 for heel
    
    % _____ CALC TSM ______
    if DEBUGIT,fprintf('TSM.');pause(.01);end;       % message             
    %figure(3); clf                       %
    if block<5 | (block>8&block<12),                 % thee blocks were "wide"
      [TSM,TSM_at_toe]=temporal_safety_margin(   ... %
        COP-toe,                                 ... %
        lf,freq,'n',0);                              %
    else                                             %
      [TSM,TSM_at_toe]=temporal_safety_margin(    ...%
        COP-anterior_axle,                        ...%
        posterior_axle-anterior_axle,freq,'n',0);    %
    end                                              %
    
    % _____ store data ______    
    newdata=[subj                                ... %
             block                               ... %
             trial                               ... %
             peakPull                            ... % 
             normPeakPull                        ... % fract of max
             pullError                           ... % error as a fract of targ
             narrow                              ... % 1 for nearrow base
             wobble                              ... % 1 if axles detect wobble  
             mean(COP)                           ... % 
             median(COP)                         ... %
             max(COP)                            ... %
             min(COP)                            ... %
             range(COP)                          ... %
             i95(COP)                            ... %
             std(COP)                            ... %
             SSM                                 ... %
             SSM/lf                              ... %
             SSM_at_toe                          ... %
             TSM                                 ... %
             TSM_at_toe];                        ... %
             disp('')
             [SSM,SSM_at_toe,TSM,TSM_at_toe];
    OUTPUT=[OUTPUT;  newdata];                       % add new data
            
  end; %for trial
  
  diary off;

end % for block

% _____ construct output data header ______    
if verbose,fprintf([sep 'Saving..']);pause(.01);end  % message
header=['BOS data results from ' prog_name       ... %
        ' for subject ' ID ' generated '         ... 
        whenis(clock)];
header=str2mat(header, ' ');
header=str2mat(header,[                          ... %
            'subj' setstr(9)                     ... %
            'block' setstr(9)                    ... %
            'trial' setstr(9)                    ... %
            'peakPull' setstr(9)                 ... % 
            'normPeakPull' setstr(9)             ... % fract of max
            'pullError' setstr(9)                ... % error as a fract of targ
            'narrow' setstr(9)                   ... % 1 for nearrow base
            'wobble' setstr(9)                   ... % 1 if axles detect wobble  
            'mean(COP)' setstr(9)                ... % 
            'median(COP)' setstr(9)              ... %
            'max(COP)' setstr(9)                 ... %
            'min(COP)' setstr(9)                 ... %
            'range(COP)' setstr(9)               ... %
            'i95(COP)' setstr(9)                 ... %
            'std(COP)' setstr(9)                 ... %
            'SSM' setstr(9)                      ... %
            'SSMnorm' setstr(9)                  ... %
            'SSM_at_toe' setstr(9)               ... %
            'TSM' setstr(9)                      ... %
            'TSM_at_toe']);                      ... %
mat2txt('results.txd',header,OUTPUT);                % store data

fprintf('\n ~ END %s ~\n\n',prog_name);
return;


% ************** MATLAB "M" function (Patton) *************
% calulate the inner-95 percentile interval
%~~~~~~~~~~~~~~~~~~~~~~ Begin Function: ~~~~~~~~~~~~~~~~~~~
function y=i95(x);
  y=prctile(x,97.5)-prctile(x,2.5);
return 







% NOT USED:

      %fprintf('\n newdata size=%d \n',size(newdata));
