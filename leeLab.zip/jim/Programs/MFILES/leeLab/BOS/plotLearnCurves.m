% ************** MATLAB "M" functionn (jim Patton) *************
% Calc & Plot results for the BOS study and store in tabular text file.
%  SYNTAX:     
%  REVISIONS:  INITATED 3/31/99 by patton from junkplot.m
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function plotLearnCurves(verbose);

% _____SETUP & GET INFO_____
global DEBUGIT
prog_name='plotLearnCurves.m';
if ~exist('verbose'), verbose=1; end                 % if not given as input arg
if verbose,       % display info
  fprintf('\n ~ %s ~',prog_name); 
  sep='\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n';           % separator string
  fprintf(sep)                
  pause(.01);
end
fsz=10;                                               % 'fontsize'
dir_name=cd
ID=dir_name(1,length(dir_name)-2:length(dir_name))
fp_center  =0.254;                                   % AP EDGE TO CNTR(M)

% _____ SET PLOTTING _____
colors=[.7 .7 .7;   ...                              % colors for plots 
        .1 .7 .7;   ...
        .7 .1 .7;   ...
        .7 .7 .1;   ...
        .1 .1 .7];
figure(2); clf; orient tall; 
figure(1); clf; orient tall; 
put_fig(1,.05,.1,.4,.8);
put_fig(2,.3,.1,.4,.8);

% _____ LOAD PARAMS FROM readme.txt _____
rfile=['readme.txt'];
if ~(exist(rfile)-2)                                 % IF READ_ME EXISTS
  fprintf('\n loading: %s (readme file)...',rfile);  % MESSAGE
  ank2fp=textract(rfile,'horiz dist ankle to back'); % HEEL TO BACK OF FP
  lf    =textract(rfile,'foot length');              % LENGTH OF FOOT(M)
  a     =textract(rfile,'horiz dist ankle to heel'); % HORIZ ANKLE2HEEL
  mass  =textract(rfile,'mass');                     % BODY MASS (KG)
  height=textract(rfile,'height');                   % BODY HEIGHT (M)
  htSurf=textract(rfile,'BOS surface height');       %
  htAxle=textract(rfile,'BOS axle height');          %
  BOSa  =textract(rfile,'BOS anterior axle to toe'); %
  BOSp  =textract(rfile,'BOS posterior axle to toe');%
  maxpul=textract(rfile,'maxpul');                   % max est pulling force
  fprintf(' DONE. ');                                % MESSAGE
else error(['?? Cant find ' rfile '. Aborting.'])    %
end                                                  % 

% _____ DERIVE PARAMS _____
pultarg=maxpul*.6;                                   % pulling force target
ankle=fp_center-ank2fp; 
heel=ankle+a; 
toe=heel-lf; 
anterior_axle=toe+BOSa-.05; 
posterior_axle=toe+BOSp+.05;

% _____ LOAD MEASURES FROM results.txd _____
mfile=['results.txd'];
if ~(exist(mfile)-2)                                 % IF READ_ME EXISTS
  fprintf('\n loading: %s (measures)...',mfile);     % MESSAGE
  subj=textract(mfile,'subj'); subj=subj(1);         %
  blocks=textract(mfile,'block');                    %
  trials=textract(mfile,'trial');                    %
  peakPull=textract(mfile,'peakPull');               %
  normPeakPull=textract(mfile,'normPeakPull');       %
  pullError=textract(mfile,'pullError');             %
  narrow=textract(mfile,'narrow');                   %
  wobble=textract(mfile,'wobble');                   %
  meanCOP=textract(mfile,'mean(COP)');               %
  medianCOP=textract(mfile,'median(COP)');           %
  maxCOP=textract(mfile,'max(COP)');                 %
  minCOP=textract(mfile,'min(COP)');                 %
  rangeCOP=textract(mfile,'range(COP)');             %
  i95COP=textract(mfile,'i95(COP)');                 %
  stdCOP=textract(mfile,'std(COP)');                 %
  SSM=textract(mfile,'SSM');                         %
  SSMnorm=textract(mfile,'SSMnorm');                 %
  SSM_at_toe=textract(mfile,'SSM_at_toe');           %
  TSM=textract(mfile,'TSM');                         %
  TSM_at_toe=textract(mfile,'TSM_at_toe');           %
  fprintf(' DONE. ');                                % MESSAGE
else error(['?? Cant find ' mfile '. Aborting.'])    %
end                                                  % 
Nobs=length(trials);                                 % # of observations (rows) 
Ntrials=max(trials);

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%~~~~~~~~~~~~  SETUP PLOT WINDOWS  ~~~~~~~~~~
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

% _____ SETUP WINDOW FOR FORCEPEAK______
%subplot(4,1,1);                                      %
figure(1);
subplot(2,1,1);
plot([0 120], [pultarg pultarg],'b:',            ... % landmarks
     [0 120], [maxpul maxpul].*.7,'r:',          ... %
     [0 120], [maxpul maxpul].*.5,'r:');             %
hold on;                                             %
plot([0 120], [0 0],'b:');                           % landmarks
ax=axis; ymin=ax(1,3); ymax=ax(1,4);                 %
plot([40.5,40.5],  [ymin,ymax],'g:',             ... % CONDITION LINES
     [80.5,80.5],  [ymin,ymax],'g:',             ... %
     [110.5,110.5],[ymin,ymax],'g:');                %
set(gca,'fontsize',fsz);                             %
title(['Force Peak']);                               %
ylabel(['N']);                                       %
axis([0 120 0 1000])
set(gca,'yTick',[0 500 1000],                   ...  %
  'yTickLabel',['   0'; ' 500'; '1000'])
text(0,pultarg,' pull target',                   ... %
   'fontsize',fsz,                               ... %
   'HorizontalAlignment','right');                   %
text(0,maxpul.*.7,' target+10%',                 ... %
   'fontsize',fsz,                               ... %
   'HorizontalAlignment','right');                   %
text(0,maxpul.*.5,' target-10%',                 ... %
   'fontsize',fsz,                               ... %
   'HorizontalAlignment','right');                   %
text(20,100,' - wide BOS trials -',              ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %
text(60,100,' - narrow BOS trials -',            ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %
text(95,100,' - wide BOS trials -',              ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %
text(115,100,' - narrow -',                      ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %

% _____ SETUP WINDOW FOR COP wings ______
%subplot(4,1,2);                                     %
subplot(2,1,2);
plot([0 120],[ankle ankle],'b:',                 ... % landmarks
     [0 120],[anterior_axle anterior_axle],'b:', ... %
     [0 120],[toe toe],'r:',                     ... %
     [0 120],[heel heel],'r:');                      %
hold on;                                             %
set(gca,'fontsize',fsz);                             %
title(['COP medians and range'])                     %
%set(gca,'yTickLabel',[])
ax=axis; ymin=ax(1,3); ymax=ax(1,4);                 %
plot([40.5,40.5],  [ymin,ymax],'g:',             ... % CONDITION LINES
     [80.5,80.5],  [ymin,ymax],'g:',             ... % 
     [110.5,110.5],[ymin,ymax],'g:');
text(0,ankle,' ankle and posterior axle',        ... %
   'fontsize',fsz,                               ... %
  'HorizontalAlignment','right');                    %
text(0,anterior_axle , ' anterior axle',         ... %
   'fontsize',fsz,                               ... %
  'HorizontalAlignment','right');                    %
text(0,heel, ' heel',                            ... %
   'fontsize',fsz,                               ... %
   'HorizontalAlignment','right');                   %
text(0,toe,  ' toe',                             ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','right');                    %
text(20,-.21,' - wide BOS trials -',              ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %
text(60,-.21,' - narrow BOS trials -',            ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %
text(95,-.21,' - wide BOS trials -',              ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %
text(115,-.21,' - narrow -',                      ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %

% _____  SETUP WINDOW FOR SSM _____
%subplot(4,1,3);                                     %
figure(2)
subplot(2,1,1);
plot([0 120], [0 0],'b:');                           % landmarks
hold on;
plot([0 120], [lf/2 lf/2],'b:');                     % landmarks
ax=axis; ymin=ax(1,3); ymax=ax(1,4);
plot([40.5,40.5],  [ymin,ymax],'g:',             ... % CONDITION LINES
     [80.5,80.5],  [ymin,ymax],'g:',             ...
     [110.5,110.5],[ymin,ymax],'g:');
set(gca,'fontsize',fsz);                             %
set(gca,'yTick',[0 .1],                         ...  %
  'yTickLabel',['  0'; '0.1'])
ylabel(['meters']);                                  %
text(0,lf/2,  ' maximum possible SSM',           ... %
  'fontsize',fsz,                                ... %
  'VerticalAlignment','Bottom');                     %
%plot(10,.1,'ro','markersize',2,                  ... %
%     'MarkerFaceColor','r');                         %
%text(10,.1,'   nearest to anterior edge',        ... %
%  'fontsize',fsz);                                   %
%plot(10,.09,'bo','markersize',2,                 ... %
%     'MarkerFaceColor','none');                      %
%text(10,.09,'   nearest to posterior edge',      ... %
%  'fontsize',fsz);                                   %
title(['Spatial Safety Margins']);
axis([0 120 -.1*lf .6*lf])
text(20,-.02,' - wide BOS trials -',             ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %
text(60,-.02,' - narrow BOS trials -',           ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %
text(95,-.02,' - wide BOS trials -',             ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %
text(115,-.02,' - narrow -',                     ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %

% _____  SETUP WINDOW FOR TSM _____
subplot(2,1,2);
%subplot(4,1,4);                                     %
plot([0 120], [0 0],'b:');                           % landmarks
hold on;
ax=axis; ymin=ax(1,3); ymax=ax(1,4);
plot([40.5,40.5],  [ymin,ymax],'g:',             ... % CONDITION LINES
     [80.5,80.5],  [ymin,ymax],'g:',             ... %
     [110.5,110.5],[ymin,ymax],'g:');                %
set(gca,'fontsize',fsz);                             %
set(gca,'yTick',[0 .1 .2 .3 .4 .5],                   ...  %
  'yTickLabel',['  0'; '0.1'; '0.2'; '0.3'; '0.4'; '0.5'])
ylabel(['seconds']);                                       %
%plot(10,.4,'ro','markersize',2,                  ... %
%     'MarkerFaceColor','r');                         %
%text(10,.4,'   at heel',                          ... %
%  'fontsize',fsz);                                   %
%plot(10,.38,'bo','markersize',2,                 ... %
%     'MarkerFaceColor','none');                      %
%text(10,.38,'   at toe',                          ... %
%  'fontsize',fsz);                                   %
title(['Temporal Safety Margins']);                  %
axis([0 120 0 .5])
text(20,.05,' - wide BOS trials -',              ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %
text(60,.05,' - narrow BOS trials -',            ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %
text(95,.05,' - wide BOS trials -',              ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %
text(115,.05,' - narrow -',                      ... %
  'fontsize',fsz,                                ... %
  'HorizontalAlignment','center');                   %


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%~~~~~ LOOP FOR EACH observation (row) ~~~~~
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if verbose,fprintf('\nRendering plots.');end;        % message
for obs=1:Nobs,
  
  if verbose,fprintf('.');pause(.01);end;            % message
  if verbose&obs==60,fprintf('\n');pause(.01);end;   % message
  trial=trials(obs);                                 % for this observation
  block=blocks(obs);                                 % for this observation
  if DEBUGIT,
    fprintf('\ntrial %d, block %d: ');
    pause(.01);
  end;           
  
  xpos=(block-1)*Ntrials+trial;                      % accumulated trial #    
  
  % _____ PLOT FORCE PEAKS ______
  if DEBUGIT,fprintf('FORCE PEAK.');pause(.01);end;  % message             
  figure(1)
  subplot(2,1,1);
  %subplot(4,1,1);                                   %
  plot(xpos,peakPull(obs),'.'); hold on;            %
  text(0,pultarg,' target',                     ... %
      'fontsize',fsz,                           ... %
      'HorizontalAlignment','right');               %
  
  % _____ PLOT WINGSPLOT____
  if DEBUGIT,fprintf('COP WINGS.');pause(.01);end;  % message             
  subplot(2,1,2);
  %subplot(4,1,2);                                   %
  if wobble(obs),
    C='m';lw=.1;
    if SSM_at_toe(obs),
      minCOP(obs)=anterior_axle;
    else
      maxCOP(obs)=posterior_axle;
    end
  else 
    C='k';lw=2;
  end    %
  plot([xpos xpos],                             ... %
       [maxCOP(obs) minCOP(obs)],C,             ... %
       'linewidth',lw);                             %
  hold on;                                          %
  plot(xpos,medianCOP(obs),'b.')
  %text(xpos,medianCOP(obs),'M','fontsize',fsz,  ... %
  %   'HorizontalAlignment','center');               %
  %text(xpos,meanCOP(obs),'A','fontsize',fsz,    ... %
  %   'HorizontalAlignment','center');               %
  axis([0 120 toe heel])
 
  % _____ PLOT SSM _____
  if DEBUGIT,fprintf('SSM.');pause(.01);end;        % message             
  figure(2)
  subplot(2,1,1);
  %subplot(4,1,3);                                   %
  if SSM_at_toe(obs), mkr='bo'; mfc='none';         %
  else                mkr='ro'; mfc='r';            %
  end                                               %
  if wobble(obs), plot(xpos,0,'mx');         %
  else
    plot(xpos,SSM(obs),'b.');
    %plot(xpos,SSM(obs),mkr,'markersize',2      ... %
    %     ,'MarkerFaceColor',mfc);                    %
  end                                               %
  axis([0 120 -.1*lf .6*lf])
   
  % _____ PLOT TSM ______
  if DEBUGIT,fprintf('TSM.');pause(.01);end;        % message             
  subplot(2,1,2);
  %subplot(4,1,4);                                   %
  if TSM_at_toe(obs), mkr='bo'; mfc='none';         %
  else                mkr='ro'; mfc='r';            %
  end                                               %
  if wobble(obs), plot(xpos,0,'mx');         %
  else
    plot(xpos,TSM(obs),'b.');
    %plot(xpos,TSM(obs),mkr,'markersize',2      ... %
    %     ,'MarkerFaceColor',mfc);                    %
  end                                               %
  axis([0 120 0 .5])
  
end; %for obs
 
% __  ps file for learning curves __
%subplot(4,1,4);                                     %
figure(1); subplot(2,1,2); xlabel('trials');
print -depsc2 learning_curves_F_R
figure(2); subplot(2,1,2); xlabel('trials');
print -depsc2 learning_curves_SM
%suptitle(['BOS project learning curves for ' ID]);

fprintf('\n ~ END %s ~\n\n',prog_name);
return;



