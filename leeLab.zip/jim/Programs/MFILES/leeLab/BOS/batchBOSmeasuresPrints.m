% ************** MATLAB "M" functionn (jim Patton) *************
% Calc & Plot results for the BOS study and store in tabular text file.
%  SYNTAX:     
%  REVISIONS:  INITATED 3/31/99 by patton from junkplot.m
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function batchBOSmeasures(start_subject,verbose)

% _____SETUP & GET INFO_____
global DEBUGIT
prog_name='batchBOSmeasures.m';
if ~exist('verbose'), verbose=1; end                 % if not given as input 
if ~exist('start_subject'), start_subject=1; end     % if not given as input 
fprintf('\n\n ~ %s function ~',prog_name);pause(.05);% display info
sep='\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n'; fprintf(sep)% separator string

% _____SUBJ INFO_____
IDs=   ['AHX';                                        % subject namecodes
        'BSX';
        'CWX';
        'DBX';
        'EDX';
        'KHX';
        'KTX';
        'LMX';
        'LVX';
        'SGX';
        'SMX'];
Nsubj=length(IDs(:,1));
base_dir=cd;

% _____ LOOP FOR EACH subj _____
for subj=start_subject:Nsubj,  %%2%1%
  fprintf(sep)
  
  % _____ change to the right diretory_____
  ID=IDs(subj,:)
  eval(['cd ' ID])
  cd
    
  % _____ do the work_____
  plotLearnCurves(verbose);
  
  % _____ change back to the base diretory_____
  cd .. 
  cd
  fprintf(sep)
  
  % _____ print_____
  if subj==1, print -dpsc2 BOS_learning_curves 
  else        print -dpsc2 -append BOS_learning_curves
  end
  
end % for subj
  

fprintf('\n ~ END %s ~\n\n',prog_name);
return;




%if subj~=1, end  
