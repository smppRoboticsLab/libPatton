static char mc_version[] = "MATLAB Compiler 1.2 Jan 17 1998 infun";
/*
 *  MATLAB Compiler: 1.2
 *  Date: Jan 17 1998
 *  Arguments: etrans -h -r -v -w 
 */
#ifndef ARRAY_ACCESS_INLINING
#error You must use the -inline option when compiling MATLAB compiler generated code with MEX or MBUILD
#endif
#ifndef MATLAB_COMPILER_GENERATED_CODE
#define MATLAB_COMPILER_GENERATED_CODE
#endif

#include <math.h>
#include "mex.h"
#include "mcc.h"

static void dio2mat_(mxArray *,mxArray *,mxArray *,mxArray *, mxArray *, int);
static void mat2dio_(int *, mxArray *, mxArray *, mxArray *);
/* static array S0_ (1 x 3) int, line 67 */
static int S0r_[] =
{
	0, 0, 0, 
};
static mxArray S0_ = mccCINIT( mccINT, 1, 3, S0r_, 0 );
/* static array S1_ (1 x 34) text, line 38: '\n ~ ETRANS.M ~ Processin...' */
static unsigned short S1__r_[] =
{
         92,  110,   32,  126,   32,   69,   84,   82,
         65,   78,   83,   46,   77,   32,  126,   32,
         80,  114,  111,   99,  101,  115,  115,  105,
        110,  103,   32,   34,   37,  115,   44,   34,
         46,   46,
};
static mxArray S1_ = mccCINIT( mccTEXT,  1, 34, S1__r_, 0);
/* static array S2_ (1 x 9) text, line 42: '\nVerbose' */
static unsigned short S2__r_[] =
{
         92,  110,   86,  101,  114,   98,  111,  115,
        101,
};
static mxArray S2_ = mccCINIT( mccTEXT,  1, 9, S2__r_, 0);
/* static array S3_ (1 x 29) text, line 44: ' not enough input argueme...' */
static unsigned short S3__r_[] =
{
         32,  110,  111,  116,   32,  101,  110,  111,
        117,  103,  104,   32,  105,  110,  112,  117,
        116,   32,   97,  114,  103,  117,  101,  109,
        101,  110,  116,  115,   32,
};
static mxArray S3_ = mccCINIT( mccTEXT,  1, 29, S3__r_, 0);
/* static array S4_ (1 x 4) text, line 46: '.e20' */
static unsigned short S4__r_[] =
{
         46,  101,   50,   48,
};
static mxArray S4_ = mccCINIT( mccTEXT,  1, 4, S4__r_, 0);
/* static array S5_ (1 x 4) text, line 47: '.e99' */
static unsigned short S5__r_[] =
{
         46,  101,   57,   57,
};
static mxArray S5_ = mccCINIT( mccTEXT,  1, 4, S5__r_, 0);
/* static array S6_ (1 x 16) text, line 54: '\nINPUT FILE: %s' */
static unsigned short S6__r_[] =
{
         92,  110,   73,   78,   80,   85,   84,   32,
         70,   73,   76,   69,   58,   32,   37,  115,
};
static mxArray S6_ = mccCINIT( mccTEXT,  1, 16, S6__r_, 0);
/* static array S7_ (1 x 29) text, line 60: '\n cant read %s. Aborting...' */
static unsigned short S7__r_[] =
{
         92,  110,   32,   99,   97,  110,  116,   32,
        114,  101,   97,  100,   32,   37,  115,   46,
         32,   65,   98,  111,  114,  116,  105,  110,
        103,   46,   32,   92,  110,
};
static mxArray S7_ = mccCINIT( mccTEXT,  1, 29, S7__r_, 0);
/* static array S8_ (1 x 38) text, line 69: ' ERRROR: Marker # for etr...' */
static unsigned short S8__r_[] =
{
         32,   69,   82,   82,   82,   79,   82,   58,
         32,   77,   97,  114,  107,  101,  114,   32,
         35,   32,  102,  111,  114,   32,  101,  116,
        114,   97,  110,  115,   32,  116,  111,  111,
         32,  104,  105,  103,  104,   32,
};
static mxArray S8_ = mccCINIT( mccTEXT,  1, 38, S8__r_, 0);
/* static array S9_ (1 x 8) text, line 72: 'cleannan' */
static unsigned short S9__r_[] =
{
         99,  108,  101,   97,  110,  110,   97,  110,
};
static mxArray S9_ = mccCINIT( mccTEXT,  1, 8, S9__r_, 0);
/* static array S10_ (1 x 18) text, line 84: ' writing to file..' */
static unsigned short S10__r_[] =
{
         32,  119,  114,  105,  116,  105,  110,  103,
         32,  116,  111,   32,  102,  105,  108,  101,
         46,   46,
};
static mxArray S10_ = mccCINIT( mccTEXT,  1, 18, S10__r_, 0);
/* static array S11_ (1 x 26) text, line 86: ' cant write file. Abortin...' */
static unsigned short S11__r_[] =
{
         32,   99,   97,  110,  116,   32,  119,  114,
        105,  116,  101,   32,  102,  105,  108,  101,
         46,   32,   65,   98,  111,  114,  116,  105,
        110,  103,
};
static mxArray S11_ = mccCINIT( mccTEXT,  1, 26, S11__r_, 0);
/* static array S12_ (1 x 17) text, line 89: '\nOUTPUT FILE: %s' */
static unsigned short S12__r_[] =
{
         92,  110,   79,   85,   84,   80,   85,   84,
         32,   70,   73,   76,   69,   58,   32,   37,
        115,
};
static mxArray S12_ = mccCINIT( mccTEXT,  1, 17, S12__r_, 0);
/* static array S13_ (1 x 21) text, line 91: '\n ~ END ETRANS.M ~  ' */
static unsigned short S13__r_[] =
{
         92,  110,   32,  126,   32,   69,   78,   68,
         32,   69,   84,   82,   65,   78,   83,   46,
         77,   32,  126,   32,   32,
};
static mxArray S13_ = mccCINIT( mccTEXT,  1, 21, S13__r_, 0);
/* static array S14_ (2 x 1) int, line 33 */
static int S14r_[] =
{
	1, 8564, 
};
static mxArray S14_ = mccCINIT( mccINT, 2, 1, S14r_, 0 );
/* static array S15_ (1 x 4) int, line 34 */
static int S15r_[] =
{
	1, 0, 8564, 
	0, 
};
static mxArray S15_ = mccCINIT( mccINT, 1, 4, S15r_, 0 );
static void indiorec_(mxArray *,mxArray *, int);
/* static array S16_ (1 x 9) text, line 31: 'noverbose' */
static unsigned short S16__r_[] =
{
        110,  111,  118,  101,  114,   98,  111,  115,
        101,
};
static mxArray S16_ = mccCINIT( mccTEXT,  1, 9, S16__r_, 0);
/* static array S17_ (1 x 15) text, line 32: ' ~ DIO2MAT.M ~ ' */
static unsigned short S17__r_[] =
{
         32,  126,   32,   68,   73,   79,   50,   77,
         65,   84,   46,   77,   32,  126,   32,
};
static mxArray S17_ = mccCINIT( mccTEXT,  1, 15, S17__r_, 0);
/* static array S18_ (1 x 1) text, line 38: 'r' */
static unsigned short S18__r_[] =
{
        114,
};
static mxArray S18_ = mccCINIT( mccTEXT,  1, 1, S18__r_, 0);
/* static array S19_ (1 x 19) text, line 41: ' ?  %s not found.\n' */
static unsigned short S19__r_[] =
{
         32,   63,   32,   32,   37,  115,   32,  110,
        111,  116,   32,  102,  111,  117,  110,  100,
         46,   92,  110,
};
static mxArray S19_ = mccCINIT( mccTEXT,  1, 19, S19__r_, 0);
/* static array S20_ (1 x 10) text, line 47: ' scan %s..' */
static unsigned short S20__r_[] =
{
         32,  115,   99,   97,  110,   32,   37,  115,
         46,   46,
};
static mxArray S20_ = mccCINIT( mccTEXT,  1, 10, S20__r_, 0);
/* static array S21_ (1 x 37) text, line 55: 'corrupt format. Reading u...' */
static unsigned short S21__r_[] =
{
         99,  111,  114,  114,  117,  112,  116,   32,
        102,  111,  114,  109,   97,  116,   46,   32,
         82,  101,   97,  100,  105,  110,  103,   32,
        117,  112,   32,  116,  111,   32,  101,  114,
        114,  111,  114,   46,   46,
};
static mxArray S21_ = mccCINIT( mccTEXT,  1, 37, S21__r_, 0);
/* static array S22_ (1 x 17) text, line 61: 'found %d records.' */
static unsigned short S22__r_[] =
{
        102,  111,  117,  110,  100,   32,   37,  100,
         32,  114,  101,   99,  111,  114,  100,  115,
         46,
};
static mxArray S22_ = mccCINIT( mccTEXT,  1, 17, S22__r_, 0);
/* static array S23_ (1 x 13) text, line 71: ' Reading %s..' */
static unsigned short S23__r_[] =
{
         32,   82,  101,   97,  100,  105,  110,  103,
         32,   37,  115,   46,   46,
};
static mxArray S23_ = mccCINIT( mccTEXT,  1, 13, S23__r_, 0);
/* static array S24_ (1 x 26) text, line 91: '\ntrial %d has %d records...' */
static unsigned short S24__r_[] =
{
         92,  110,  116,  114,  105,   97,  108,   32,
         37,  100,   32,  104,   97,  115,   32,   37,
        100,   32,  114,  101,   99,  111,  114,  100,
        115,   46,
};
static mxArray S24_ = mccCINIT( mccTEXT,  1, 26, S24__r_, 0);
/* static array S25_ (1 x 19) text, line 95: ' ~ END DIO2MAT.M ~ ' */
static unsigned short S25__r_[] =
{
         32,  126,   32,   69,   78,   68,   32,   68,
         73,   79,   50,   77,   65,   84,   46,   77,
         32,  126,   32,
};
static mxArray S25_ = mccCINIT( mccTEXT,  1, 19, S25__r_, 0);
/* static array S26_ (1 x 2) text, line 96: '\n' */
static unsigned short S26__r_[] =
{
         92,  110,
};
static mxArray S26_ = mccCINIT( mccTEXT,  1, 2, S26__r_, 0);
/* static array S27_ (2 x 1) int, line 16 */
static int S27r_[] =
{
	1, 8564, 
};
static mxArray S27_ = mccCINIT( mccINT, 2, 1, S27r_, 0 );
/* static array S28_ (1 x 4) int, line 17 */
static int S28r_[] =
{
	1, 0, 8564, 0, 
};
static mxArray S28_ = mccCINIT( mccINT, 1, 4, S28r_, 0 );
/* static array S29_ (1 x 18) text, line 15: '\n ~ indiorec.M ~ ' */
static unsigned short S29__r_[] =
{
         92,  110,   32,  126,   32,  105,  110,  100,
        105,  111,  114,  101,   99,   46,   77,   32,
        126,   32,
};
static mxArray S29_ = mccCINIT( mccTEXT,  1, 18, S29__r_, 0);
/* static array S30_ (1 x 15) text, line 20: '\nRead Header..' */
static unsigned short S30__r_[] =
{
         92,  110,   82,  101,   97,  100,   32,   72,
        101,   97,  100,  101,  114,   46,   46,
};
static mxArray S30_ = mccCINIT( mccTEXT,  1, 15, S30__r_, 0);
/* static array S31_ (1 x 5) text, line 22: 'short' */
static unsigned short S31__r_[] =
{
        115,  104,  111,  114,  116,
};
static mxArray S31_ = mccCINIT( mccTEXT,  1, 5, S31__r_, 0);
/* static array S32_ (1 x 1) text, line 23: '=' */
static unsigned short S32__r_[] =
{
         61,
};
static mxArray S32_ = mccCINIT( mccTEXT,  1, 1, S32__r_, 0);
/* static array S33_ (1 x 3) text, line 23: ' %d' */
static unsigned short S33__r_[] =
{
         32,   37,  100,
};
static mxArray S33_ = mccCINIT( mccTEXT,  1, 3, S33__r_, 0);
/* static array S34_ (1 x 16) text, line 26: '\nError reading ' */
static unsigned short S34__r_[] =
{
         92,  110,   69,  114,  114,  111,  114,   32,
        114,  101,   97,  100,  105,  110,  103,   32,
};
static mxArray S34_ = mccCINIT( mccTEXT,  1, 16, S34__r_, 0);
/* static array S35_ (1 x 21) text, line 29: '\nReading %d values..' */
static unsigned short S35__r_[] =
{
         92,  110,   82,  101,   97,  100,  105,  110,
        103,   32,   37,  100,   32,  118,   97,  108,
        117,  101,  115,   46,   46,
};
static mxArray S35_ = mccCINIT( mccTEXT,  1, 21, S35__r_, 0);
/* static array S36_ (1 x 5) text, line 31: 'float' */
static unsigned short S36__r_[] =
{
        102,  108,  111,   97,  116,
};
static mxArray S36_ = mccCINIT( mccTEXT,  1, 5, S36__r_, 0);
/* static array S37_ (1 x 17) text, line 33: ' %d records read.' */
static unsigned short S37__r_[] =
{
         32,   37,  100,   32,  114,  101,   99,  111,
        114,  100,  115,   32,  114,  101,   97,  100,
         46,
};
static mxArray S37_ = mccCINIT( mccTEXT,  1, 17, S37__r_, 0);
/* static array S38_ (1 x 20) text, line 37: ' ~ END indiorec.M ~ ' */
static unsigned short S38__r_[] =
{
         32,  126,   32,   69,   78,   68,   32,  105,
        110,  100,  105,  111,  114,  101,   99,   46,
         77,   32,  126,   32,
};
static mxArray S38_ = mccCINIT( mccTEXT,  1, 20, S38__r_, 0);
/* static array S39_ (2 x 1) int, line 17 */
static int S39r_[] =
{
	1, 
	8564, 
};
static mxArray S39_ = mccCINIT( mccINT, 2, 1, S39r_, 0 );
/* static array S40_ (1 x 17) text, line 16: '\n ~ MAT2DIO.M ~ ' */
static unsigned short S40__r_[] =
{
         92,  110,   32,  126,   32,   77,   65,   84,
         50,   68,   73,   79,   46,   77,   32,  126,
         32,
};
static mxArray S40_ = mccCINIT( mccTEXT,  1, 17, S40__r_, 0);
/* static array S41_ (1 x 1) text, line 19: 'w' */
static unsigned short S41__r_[] =
{
        119,
};
static mxArray S41_ = mccCINIT( mccTEXT,  1, 1, S41__r_, 0);
/* static array S42_ (1 x 18) text, line 22: ' writing to file..' */
static unsigned short S42__r_[] =
{
         32,  119,  114,  105,  116,  105,  110,  103,
         32,  116,  111,   32,  102,  105,  108,  101,
         46,   46,
};
static mxArray S42_ = mccCINIT( mccTEXT,  1, 18, S42__r_, 0);
/* static array S43_ (1 x 5) text, line 24: 'short' */
static unsigned short S43__r_[] =
{
        115,  104,  111,  114,  116,
};
static mxArray S43_ = mccCINIT( mccTEXT,  1, 5, S43__r_, 0);
/* static array S44_ (1 x 5) text, line 25: 'float' */
static unsigned short S44__r_[] =
{
        102,  108,  111,   97,  116,
};
static mxArray S44_ = mccCINIT( mccTEXT,  1, 5, S44__r_, 0);
/* static array S45_ (1 x 5) text, line 28: 'short' */
static unsigned short S45__r_[] =
{
        115,  104,  111,  114,  116,
};
static mxArray S45_ = mccCINIT( mccTEXT,  1, 5, S45__r_, 0);
/* static array S46_ (1 x 19) text, line 31: ' ~ END MAT2DIO.M ~ ' */
static unsigned short S46__r_[] =
{
         32,  126,   32,   69,   78,   68,   32,   77,
         65,   84,   50,   68,   73,   79,   46,   77,
         32,  126,   32,
};
static mxArray S46_ = mccCINIT( mccTEXT,  1, 19, S46__r_, 0);
/***************** Compiler Assumptions ****************
 *
 *       B0_         	boolean scalar temporary
 *       BM0_        	boolean vector/matrix temporary
 *       D           	real vector/matrix
 *       DEBUGIT     	global real vector/matrix
 *       H           	real vector/matrix
 *       I0_         	integer scalar temporary
 *       I1_         	integer scalar temporary
 *       IM0_        	integer vector/matrix temporary
 *       IM1_        	integer vector/matrix temporary
 *       INname      	real vector/matrix
 *       N           	real vector/matrix
 *       Nr          	real vector/matrix
 *       Nt          	real vector/matrix
 *       OUTname     	real vector/matrix
 *       Q           	integer vector/matrix
 *       R0_         	real scalar temporary
 *       R1_         	real scalar temporary
 *       R2_         	real scalar temporary
 *       RM0_        	real vector/matrix temporary
 *       RM1_        	real vector/matrix temporary
 *       RM2_        	real vector/matrix temporary
 *       RM3_        	real vector/matrix temporary
 *       S0_         	<constant>
 *       TM0_        	string vector/matrix temporary
 *       cleannan    	real vector/matrix
 *       colN        	real scalar
 *       colT        	real vector/matrix
 *       dio2mat     	<function>
 *       error       	<function>
 *       etrans      	<function being defined>
 *       fprintf     	<function>
 *       len         	integer scalar
 *       length      	<function>
 *       mat2dio     	<function>
 *       mean        	<function>
 *       mkrAv       	real vector/matrix
 *       name1       	real vector/matrix
 *       name2       	real vector/matrix
 *       nargin      	<function>
 *       offset      	real vector/matrix
 *       ones        	<function>
 *       status      	integer scalar
 *       triad       	real scalar
 *       trial       	integer scalar
 *******************************************************/

void
mexFunction(
    int nlhs_,
    mxArray *plhs_[],
    int nrhs_,
    const mxArray *prhs_[]
)
{
   mxArray *Mplhs_[1];
   mxArray *Mprhs_[2];
   

   if (nrhs_ > 4 )
   {
      mexErrMsgTxt( "Too many input arguments." );
   }

   if (nlhs_ > 1 )
   {
      mexErrMsgTxt( "Too many output arguments." );
   }

   {
      int status = 0;
      mxArray name1;
      mxArray N;
      mxArray offset;
      mxArray name2;
      mxArray DEBUGIT;
      mxArray INname;
      mxArray OUTname;
      mxArray H;
      mxArray D;
      mxArray Nt;
      mxArray Nr;
      int len = 0;
      mxArray Q;
      int trial = 0;
      mxArray mkrAv;
      double colN = 0.0;
      mxArray cleannan;
      mxArray colT;
      double triad = 0.0;
      int I0_ = 0;
      unsigned short B0_ = 0;
      mxArray TM0_;
      mxArray RM0_;
      mxArray BM0_;
      mxArray IM0_;
      mxArray RM1_;
      mxArray IM1_;
      mxArray RM2_;
      double R0_ = 0.0;
      double R1_ = 0.0;
      double R2_ = 0.0;
      mxArray RM3_;
      int I1_ = 0;
      
      mccRealInit(name1);
      mccImport(&name1, ((nrhs_>0) ? prhs_[0] : 0), 0, 0);
      mccRealInit(N);
      mccImport(&N, ((nrhs_>1) ? prhs_[1] : 0), 0, 0);
      mccRealInit(offset);
      mccImportCopy(&offset, ((nrhs_>2) ? prhs_[2] : 0), 0, 0);
      mccRealInit(name2);
      mccImport(&name2, ((nrhs_>3) ? prhs_[3] : 0), 0, 0);
      mccRealInit(DEBUGIT);
      mccRealInit(INname);
      mccRealInit(OUTname);
      mccRealInit(H);
      mccRealInit(D);
      mccRealInit(Nt);
      mccRealInit(Nr);
      mccIntInit(Q);
      mccRealInit(mkrAv);
      mccRealInit(cleannan);
      mccRealInit(colT);
      mccTextInit(TM0_);
      mccRealInit(RM0_);
      mccBoolInit(BM0_);
      mccIntInit(IM0_);
      mccRealInit(RM1_);
      mccIntInit(IM1_);
      mccRealInit(RM2_);
      mccRealInit(RM3_);
      
      /* fprintf('\n ~ ETRANS.M ~ Processing "%s,"..', name1) */
      if(mccNOTSET(&name1))
      {
         mexErrMsgTxt( "variable name1 undefined, line 38" );
      }
      Mprhs_[0] = &S1_;
      Mprhs_[1] = &name1;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 2, Mprhs_, "fprintf", 38);
      mccPrint(Mplhs_[0], 0);
      
      /* % ____ SETUP VARS ____ */
      /* global DEBUGIT                                         % nonzero for verbose */
      /* GLOBAL */
      /* if DEBUGIT, fprintf('\nVerbose'); end;                 % message */
      mccGetGlobal(&DEBUGIT, "DEBUGIT");
      if (mccIfCondition(&DEBUGIT))
      {
         Mprhs_[0] = &S2_;
         Mplhs_[0] = 0;
         mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 42);
      }
      /* status=0;                                              % start with OK status */
      status = 0;
      /* if nargin<3, error(' not enough input arguements ');   % if #input arguments <2 */
      I0_ = mccNargin();
      B0_ = (I0_ < 3);
      if ((double)B0_)
      {
         mccError(&S3_);
      }
      else
      {
         /* elseif nargin==3,                                      % if just root is given */
         I0_ = mccNargin();
         B0_ = (I0_ == 3);
         if ((double)B0_)
         {
            /* INname=[ name1,['.e20']];                            % add on correct extension */
            mccCatenateColumns(&INname, &name1, &S4_);
            mccSTRING(&INname) = 1;
            /* OUTname=[ name1,['.e99']];                           % add on correct extension  */
            mccCatenateColumns(&OUTname, &name1, &S5_);
            mccSTRING(&OUTname) = 1;
         }
         else
         {
            /* else                                                   % if input & output given */
            /* INname=name1;                                        % copy filename    */
            mccCopy(&INname, &name1);
            mccSTRING(&INname) = mccSTRING(&name1);
            /* OUTname=name2;                                       % copy filename    */
            mccCopy(&OUTname, &name2);
            mccSTRING(&OUTname) = mccSTRING(&name2);
            /* end                                                    % end if #input arguments  */
         }
      }
      
      /* % ____ GET INPUT ____ */
      /* fprintf('\nINPUT FILE: %s',INname);                    % display input file name */
      Mprhs_[0] = &S6_;
      Mprhs_[1] = &INname;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 2, Mprhs_, "fprintf", 54);
      /* [H,D,Nt,Nr]=dio2mat(INname,1);                         % read dio file not verbose */
      mccCopy(&TM0_, &INname);
      dio2mat_(&H,&D,&Nt,&Nr, &TM0_, 1);
      /* len=length(D(:,1));                                    % number of time steps */
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_RM0_;
         int I_RM0_=1;
         double *p_D;
         int I_D=1, J_D;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&D), 1);
         mccAllocateMatrix(&RM0_, m_, n_);
         mccCheckMatrixSize(&D, mccM(&D), 1);
         I_RM0_ = (mccM(&RM0_) != 1 || mccN(&RM0_) != 1);
         p_RM0_ = mccPR(&RM0_);
         if (mccM(&D) == 1) { I_D = J_D = 0;}
         else { I_D = 1; J_D=mccM(&D)-m_; }
         p_D = mccPR(&D) + 0 + mccM(&D) * (1-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_D += J_D)
            {
               for (i_=0; i_<m_; ++i_, p_RM0_+=I_RM0_, p_D+=I_D)
               {
                  *p_RM0_ = *p_D;
               }
            }
         }
      }
      len = mccGetLength(&RM0_);
      /* Q=ones(len,1);                                         % dummy vect of 1's */
      mccOnesMN(&Q, len, 1);
      /* if H==-1,                                              % if cant read */
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         unsigned short *p_BM0_;
         int I_BM0_=1;
         double *p_H;
         int I_H=1;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&H), mccN(&H));
         mccAllocateMatrix(&BM0_, m_, n_);
         I_BM0_ = (mccM(&BM0_) != 1 || mccN(&BM0_) != 1);
         p_BM0_ = mccSPR(&BM0_);
         I_H = (mccM(&H) != 1 || mccN(&H) != 1);
         p_H = mccPR(&H);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_)
            {
               for (i_=0; i_<m_; ++i_, p_BM0_+=I_BM0_, p_H+=I_H)
               {
                  *p_BM0_ = ( (*p_H ==  -1) && !mccREL_NAN(*p_H) );
               }
            }
         }
      }
      if (mccIfCondition(&BM0_))
      {
         /* status=1;                                            % status to "error" */
         status = 1;
         /* fprintf('\n cant read %s. Aborting. \n', INname);    % message */
         Mprhs_[0] = &S7_;
         Mprhs_[1] = &INname;
         Mplhs_[0] = 0;
         mccCallMATLAB(0, Mplhs_, 2, Mprhs_, "fprintf", 60);
         /* return;                                              % abort if cant read */
         goto MretR;
         /* end                                                    % end if cant read */
      }
      
      /* % __ TRANSLATE/ZERO COORDINATE SYSTEM __ */
      /* for trial=1:Nt                                         % loop for each trial */
      for (I0_ = 1; I0_ <= mccGetRealVectorElement(&Nt, 1); I0_ = I0_ + 1)
      {
         trial = I0_;
         /* if N==0                                              % if no mkr offset */
         if(mccNOTSET(&N))
         {
            mexErrMsgTxt( "variable N undefined, line 66" );
         }
         {
            int i_, j_;
            int m_=1, n_=1, cx_ = 0;
            unsigned short *p_BM0_;
            int I_BM0_=1;
            double *p_N;
            int I_N=1;
            m_ = mcmCalcResultSize(m_, &n_, mccM(&N), mccN(&N));
            mccAllocateMatrix(&BM0_, m_, n_);
            I_BM0_ = (mccM(&BM0_) != 1 || mccN(&BM0_) != 1);
            p_BM0_ = mccSPR(&BM0_);
            I_N = (mccM(&N) != 1 || mccN(&N) != 1);
            p_N = mccPR(&N);
            if (m_ != 0)
            {
               for (j_=0; j_<n_; ++j_)
               {
                  for (i_=0; i_<m_; ++i_, p_BM0_+=I_BM0_, p_N+=I_N)
                  {
                     *p_BM0_ = ( (*p_N == 0) && !mccREL_NAN(*p_N) );
                  }
               }
            }
         }
         if (mccIfCondition(&BM0_))
         {
            /* mkrAv=[0 0 0];                                     % use zero offset */
            mccCopy(&mkrAv, &S0_);
         }
         else
         {
            /* elseif N>Nr/3,                                       % if marker # is too high */
            {
               int i_, j_;
               int m_=1, n_=1, cx_ = 0;
               unsigned short *p_BM0_;
               int I_BM0_=1;
               double *p_N;
               int I_N=1;
               double *p_Nr;
               int I_Nr=1;
               m_ = mcmCalcResultSize(m_, &n_, mccM(&N), mccN(&N));
               m_ = mcmCalcResultSize(m_, &n_, mccM(&Nr), mccN(&Nr));
               mccAllocateMatrix(&BM0_, m_, n_);
               I_BM0_ = (mccM(&BM0_) != 1 || mccN(&BM0_) != 1);
               p_BM0_ = mccSPR(&BM0_);
               I_N = (mccM(&N) != 1 || mccN(&N) != 1);
               p_N = mccPR(&N);
               I_Nr = (mccM(&Nr) != 1 || mccN(&Nr) != 1);
               p_Nr = mccPR(&Nr);
               if (m_ != 0)
               {
                  for (j_=0; j_<n_; ++j_)
                  {
                     for (i_=0; i_<m_; ++i_, p_BM0_+=I_BM0_, p_N+=I_N, p_Nr+=I_Nr)
                     {
                        *p_BM0_ = ( (*p_N > (*p_Nr / (double) 3)) && !mccREL_NAN(*p_N) && !mccREL_NAN((*p_Nr / (double) 3)) );
                     }
                  }
               }
            }
            if (mccIfCondition(&BM0_))
            {
               /* error(' ERRROR: Marker # for etrans too high ') */
               mccError(&S8_);
            }
            else
            {
               /* else                                                 % otherwise  */
               /* colN=(trial-1)*Nr+3*N-2;                           % start column for marker N */
               colN = ((((trial - 1) * (double) mccGetRealVectorElement(&Nr, 1)) + (3 * (double) mccGetRealVectorElement(&N, 1))) - 2);
               /* mkrAv=mean(cleannan(D(:,colN:colN+2),0));          % DETERMINE ZERO LOCATION */
               mccUndefVariable(&cleannan, &S9_);
               mccColon2(&RM0_, colN, (colN + 2));
               mccFindIndex(&IM0_, &RM0_);
               {
                  int i_, j_;
                  int m_=1, n_=1, cx_ = 0;
                  double *p_RM1_;
                  int I_RM1_=1;
                  double *p_D;
                  int I_D=1;
                  int *p_IM0_;
                  int I_IM0_=1;
                  m_ = mcmCalcResultSize(m_, &n_, mccM(&D), (mccM(&IM0_) * mccN(&IM0_)));
                  mccAllocateMatrix(&RM1_, m_, n_);
                  mccCheckMatrixSize(&D, mccM(&D), mccGetMaxIndex(&IM0_ ,mccN(&D)));
                  I_RM1_ = (mccM(&RM1_) != 1 || mccN(&RM1_) != 1);
                  p_RM1_ = mccPR(&RM1_);
                  I_IM0_ = (mccM(&IM0_) != 1 || mccN(&IM0_) != 1);
                  p_IM0_ = mccIPR(&IM0_);
                  if (m_ != 0)
                  {
                     for (j_=0; j_<n_; ++j_, p_IM0_ += I_IM0_)
                     {
                        p_D = mccPR(&D) + mccM(&D) * ((int)(*p_IM0_ - .5)) + 0;
                        for (i_=0; i_<m_; ++i_, p_RM1_+=I_RM1_, p_D+=I_D)
                        {
                           *p_RM1_ = *p_D;
                        }
                     }
                  }
               }
               mccLOG(&RM1_) = mccLOG(&D);
               mccFindIndex(&IM1_, &RM1_);
               {
                  int i_, j_;
                  int m_=1, n_=1, cx_ = 0;
                  double *p_RM2_;
                  int I_RM2_=1;
                  double *p_cleannan;
                  int I_cleannan=1, J_cleannan;
                  int *p_IM1_;
                  int I_IM1_=1;
                  m_ = mcmCalcResultSize(m_, &n_, (mccM(&IM1_) * mccN(&IM1_)), 1);
                  mccAllocateMatrix(&RM2_, m_, n_);
                  mccCheckMatrixSize(&cleannan, mccGetMaxIndex(&IM1_ ,mccM(&cleannan)), 0);
                  I_RM2_ = (mccM(&RM2_) != 1 || mccN(&RM2_) != 1);
                  p_RM2_ = mccPR(&RM2_);
                  J_cleannan = ((mccM(&cleannan) != 1 || mccN(&cleannan) != 1) ? mccM(&cleannan) : 0);
                  p_cleannan = mccPR(&cleannan) + mccM(&cleannan) * (0-1);
                  I_IM1_ = (mccM(&IM1_) != 1 || mccN(&IM1_) != 1);
                  if (m_ != 0)
                  {
                     for (j_=0; j_<n_; ++j_, p_cleannan += J_cleannan)
                     {
                        p_IM1_ = mccIPR(&IM1_);
                        for (i_=0; i_<m_; ++i_, p_RM2_+=I_RM2_, p_IM1_+=I_IM1_)
                        {
                           *p_RM2_ = p_cleannan[((int)(*p_IM1_ - .5))];
                        }
                     }
                  }
               }
               Mprhs_[0] = &RM2_;
               Mplhs_[0] = &mkrAv;
               mccCallMATLAB(1, Mplhs_, 1, Mprhs_, "mean", 72);
               /* end                                                  %  */
            }
         }
         /* mkrAv=[mkrAv(1)*Q mkrAv(2)*Q mkrAv(3)*Q];            % stretch mkrAv out  */
         R0_ = (mccGetRealVectorElement(&mkrAv, mccRint(1)));
         {
            int i_, j_;
            int m_=1, n_=1, cx_ = 0;
            double *p_RM2_;
            int I_RM2_=1;
            int *p_Q;
            int I_Q=1;
            m_ = mcmCalcResultSize(m_, &n_, mccM(&Q), mccN(&Q));
            mccAllocateMatrix(&RM2_, m_, n_);
            I_RM2_ = (mccM(&RM2_) != 1 || mccN(&RM2_) != 1);
            p_RM2_ = mccPR(&RM2_);
            I_Q = (mccM(&Q) != 1 || mccN(&Q) != 1);
            p_Q = mccIPR(&Q);
            if (m_ != 0)
            {
               for (j_=0; j_<n_; ++j_)
               {
                  for (i_=0; i_<m_; ++i_, p_RM2_+=I_RM2_, p_Q+=I_Q)
                  {
                     *p_RM2_ = (R0_ * (double) ((int)*p_Q));
                  }
               }
            }
         }
         R1_ = (mccGetRealVectorElement(&mkrAv, mccRint(2)));
         {
            int i_, j_;
            int m_=1, n_=1, cx_ = 0;
            double *p_RM1_;
            int I_RM1_=1;
            int *p_Q;
            int I_Q=1;
            m_ = mcmCalcResultSize(m_, &n_, mccM(&Q), mccN(&Q));
            mccAllocateMatrix(&RM1_, m_, n_);
            I_RM1_ = (mccM(&RM1_) != 1 || mccN(&RM1_) != 1);
            p_RM1_ = mccPR(&RM1_);
            I_Q = (mccM(&Q) != 1 || mccN(&Q) != 1);
            p_Q = mccIPR(&Q);
            if (m_ != 0)
            {
               for (j_=0; j_<n_; ++j_)
               {
                  for (i_=0; i_<m_; ++i_, p_RM1_+=I_RM1_, p_Q+=I_Q)
                  {
                     *p_RM1_ = (R1_ * (double) ((int)*p_Q));
                  }
               }
            }
         }
         mccCatenateColumns(&RM0_, &RM2_, &RM1_);
         R2_ = (mccGetRealVectorElement(&mkrAv, mccRint(3)));
         {
            int i_, j_;
            int m_=1, n_=1, cx_ = 0;
            double *p_RM3_;
            int I_RM3_=1;
            int *p_Q;
            int I_Q=1;
            m_ = mcmCalcResultSize(m_, &n_, mccM(&Q), mccN(&Q));
            mccAllocateMatrix(&RM3_, m_, n_);
            I_RM3_ = (mccM(&RM3_) != 1 || mccN(&RM3_) != 1);
            p_RM3_ = mccPR(&RM3_);
            I_Q = (mccM(&Q) != 1 || mccN(&Q) != 1);
            p_Q = mccIPR(&Q);
            if (m_ != 0)
            {
               for (j_=0; j_<n_; ++j_)
               {
                  for (i_=0; i_<m_; ++i_, p_RM3_+=I_RM3_, p_Q+=I_Q)
                  {
                     *p_RM3_ = (R2_ * (double) ((int)*p_Q));
                  }
               }
            }
         }
         mccCatenateColumns(&mkrAv, &RM0_, &RM3_);
         /* offset=[offset(1)*Q offset(2)*Q offset(3)*Q];        % stretch offset out  */
         if(mccNOTSET(&offset))
         {
            mexErrMsgTxt( "variable offset undefined, line 75" );
         }
         R2_ = (mccGetRealVectorElement(&offset, mccRint(1)));
         {
            int i_, j_;
            int m_=1, n_=1, cx_ = 0;
            double *p_RM3_;
            int I_RM3_=1;
            int *p_Q;
            int I_Q=1;
            m_ = mcmCalcResultSize(m_, &n_, mccM(&Q), mccN(&Q));
            mccAllocateMatrix(&RM3_, m_, n_);
            I_RM3_ = (mccM(&RM3_) != 1 || mccN(&RM3_) != 1);
            p_RM3_ = mccPR(&RM3_);
            I_Q = (mccM(&Q) != 1 || mccN(&Q) != 1);
            p_Q = mccIPR(&Q);
            if (m_ != 0)
            {
               for (j_=0; j_<n_; ++j_)
               {
                  for (i_=0; i_<m_; ++i_, p_RM3_+=I_RM3_, p_Q+=I_Q)
                  {
                     *p_RM3_ = (R2_ * (double) ((int)*p_Q));
                  }
               }
            }
         }
         if(mccNOTSET(&offset))
         {
            mexErrMsgTxt( "variable offset undefined, line 75" );
         }
         R1_ = (mccGetRealVectorElement(&offset, mccRint(2)));
         {
            int i_, j_;
            int m_=1, n_=1, cx_ = 0;
            double *p_RM0_;
            int I_RM0_=1;
            int *p_Q;
            int I_Q=1;
            m_ = mcmCalcResultSize(m_, &n_, mccM(&Q), mccN(&Q));
            mccAllocateMatrix(&RM0_, m_, n_);
            I_RM0_ = (mccM(&RM0_) != 1 || mccN(&RM0_) != 1);
            p_RM0_ = mccPR(&RM0_);
            I_Q = (mccM(&Q) != 1 || mccN(&Q) != 1);
            p_Q = mccIPR(&Q);
            if (m_ != 0)
            {
               for (j_=0; j_<n_; ++j_)
               {
                  for (i_=0; i_<m_; ++i_, p_RM0_+=I_RM0_, p_Q+=I_Q)
                  {
                     *p_RM0_ = (R1_ * (double) ((int)*p_Q));
                  }
               }
            }
         }
         mccCatenateColumns(&RM1_, &RM3_, &RM0_);
         if(mccNOTSET(&offset))
         {
            mexErrMsgTxt( "variable offset undefined, line 75" );
         }
         R0_ = (mccGetRealVectorElement(&offset, mccRint(3)));
         {
            int i_, j_;
            int m_=1, n_=1, cx_ = 0;
            double *p_RM2_;
            int I_RM2_=1;
            int *p_Q;
            int I_Q=1;
            m_ = mcmCalcResultSize(m_, &n_, mccM(&Q), mccN(&Q));
            mccAllocateMatrix(&RM2_, m_, n_);
            I_RM2_ = (mccM(&RM2_) != 1 || mccN(&RM2_) != 1);
            p_RM2_ = mccPR(&RM2_);
            I_Q = (mccM(&Q) != 1 || mccN(&Q) != 1);
            p_Q = mccIPR(&Q);
            if (m_ != 0)
            {
               for (j_=0; j_<n_; ++j_)
               {
                  for (i_=0; i_<m_; ++i_, p_RM2_+=I_RM2_, p_Q+=I_Q)
                  {
                     *p_RM2_ = (R0_ * (double) ((int)*p_Q));
                  }
               }
            }
         }
         mccCatenateColumns(&offset, &RM1_, &RM2_);
         /* colT=(trial-1)*Nr+1;                                 % start column for trial */
         I1_ = (trial - 1);
         {
            int i_, j_;
            int m_=1, n_=1, cx_ = 0;
            double *p_colT;
            int I_colT=1;
            double *p_Nr;
            int I_Nr=1;
            m_ = mcmCalcResultSize(m_, &n_, mccM(&Nr), mccN(&Nr));
            mccAllocateMatrix(&colT, m_, n_);
            I_colT = (mccM(&colT) != 1 || mccN(&colT) != 1);
            p_colT = mccPR(&colT);
            I_Nr = (mccM(&Nr) != 1 || mccN(&Nr) != 1);
            p_Nr = mccPR(&Nr);
            if (m_ != 0)
            {
               for (j_=0; j_<n_; ++j_)
               {
                  for (i_=0; i_<m_; ++i_, p_colT+=I_colT, p_Nr+=I_Nr)
                  {
                     *p_colT = ((I1_ * (double) *p_Nr) + 1);
                  }
               }
            }
         }
         /* for triad=colT:3:colT+Nr-3                           % loop for ea marker triad */
         mccColon(&RM2_, (*mccPR(&colT)), (double)3, ((mccGetRealVectorElement(&colT, 1) + mccGetRealVectorElement(&Nr, 1)) - 3));
         for (I1_ = 0; I1_ < mccN(&RM2_); ++I1_)
         {
            triad = mccPR(&RM2_)[I1_];
            /* D(:,triad:triad+2)=D(:,triad:triad+2)          ... % re-zero this triad  */
            mccColon2(&RM0_, triad, (triad + 2));
            mccColon2(&RM1_, triad, (triad + 2));
            {
               int i_, j_;
               int m_=1, n_=1, cx_ = 0;
               double *p_D;
               int I_D=1;
               double *p_RM1_;
               int I_RM1_=1;
               double *p_1D;
               int I_1D=1;
               double *p_RM0_;
               int I_RM0_=1;
               double *p_mkrAv;
               int I_mkrAv=1;
               double *p_offset;
               int I_offset=1;
               m_ = mcmCalcResultSize(m_, &n_, mccM(&D), (mccM(&RM0_) * mccN(&RM0_)));
               m_ = mcmCalcResultSize(m_, &n_, mccM(&mkrAv), mccN(&mkrAv));
               m_ = mcmCalcResultSize(m_, &n_, mccM(&offset), mccN(&offset));
               mccGrowMatrix(&D, m_, mccGetMaxIndex(&RM1_ ,mccN(&D)));
               mccCheckMatrixSize(&D, mccM(&D), mccGetMaxIndex(&RM0_ ,mccN(&D)));
               I_RM1_ = (mccM(&RM1_) != 1 || mccN(&RM1_) != 1);
               p_RM1_ = mccPR(&RM1_);
               I_RM0_ = (mccM(&RM0_) != 1 || mccN(&RM0_) != 1);
               p_RM0_ = mccPR(&RM0_);
               I_mkrAv = (mccM(&mkrAv) != 1 || mccN(&mkrAv) != 1);
               p_mkrAv = mccPR(&mkrAv);
               I_offset = (mccM(&offset) != 1 || mccN(&offset) != 1);
               p_offset = mccPR(&offset);
               if (m_ != 0)
               {
                  for (j_=0; j_<n_; ++j_, p_RM1_ += I_RM1_, p_RM0_ += I_RM0_)
                  {
                     p_D = mccPR(&D) + mccM(&D) * ((int)(*p_RM1_ - .5)) + 0;
                     p_1D = mccPR(&D) + mccM(&D) * ((int)(*p_RM0_ - .5)) + 0;
                     for (i_=0; i_<m_; ++i_, p_D+=I_D, p_1D+=I_1D, p_mkrAv+=I_mkrAv, p_offset+=I_offset)
                     {
                        *p_D = ((*p_1D - *p_mkrAv) - *p_offset);
                     }
                  }
               }
            }
            /* end                                                  % end for triad */
         }
         /* end */
      }
      
      /* % __  WRITE DATAIO OUTPUT FILE __ */
      /* if DEBUGIT, fprintf(' writing to file..'); end         % message */
      mccGetGlobal(&DEBUGIT, "DEBUGIT");
      if (mccIfCondition(&DEBUGIT))
      {
         Mprhs_[0] = &S10_;
         Mplhs_[0] = 0;
         mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 84);
      }
      /* if mat2dio(OUTname,H,D),                               % WRITE FILE; IF CANT OPEN, */
      mccCopy(&TM0_, &OUTname);
      mccSTRING(&TM0_) = mccSTRING(&OUTname);
      mat2dio_(&I0_, &TM0_, &H, &D);
      if ((double)I0_)
      {
         /* error(' cant write file. Aborting');                 % abort */
         mccError(&S11_);
         /* end                                                    % end if mat2dio */
      }
      
      /* fprintf('\nOUTPUT FILE: %s',OUTname);                  % display output file name */
      Mprhs_[0] = &S12_;
      Mprhs_[1] = &OUTname;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 2, Mprhs_, "fprintf", 89);
      
      /* fprintf('\n ~ END ETRANS.M ~  ') */
      Mprhs_[0] = &S13_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 91);
      mccPrint(Mplhs_[0], 0);
      
      MretR: ;
      mccReturnScalar(&plhs_[0], status, 0., mccREAL, 0);
   }
   return;
}
/*
[RRRR] = dio2mat(Ti)
*/
/***************** Compiler Assumptions ****************
 *
 *       B0_         	boolean scalar temporary
 *       D           	real vector/matrix
 *       DEBUGIT     	global real vector/matrix
 *       H           	real vector/matrix
 *       I0_         	integer scalar temporary
 *       IM0_        	integer vector/matrix temporary
 *       IM1_        	integer vector/matrix temporary
 *       N           	integer scalar
 *       NaN         	<function>
 *       Nrecs       	real vector/matrix
 *       Ntrials     	real vector/matrix
 *       R0_         	real scalar temporary
 *       RM0_        	real vector/matrix temporary
 *       RM1_        	real vector/matrix temporary
 *       S14_        	<constant>
 *       S15_        	<constant>
 *       count       	integer scalar
 *       d           	real vector/matrix
 *       diff        	<function>
 *       dio2mat     	<function being defined>
 *       dleng       	integer scalar
 *       endrec      	integer vector/matrix
 *       endrec2     	integer vector/matrix
 *       exist       	<function>
 *       fclose      	<function>
 *       fid         	integer scalar
 *       filename    	string vector/matrix
 *       find        	<function>
 *       fopen       	<function>
 *       fprintf     	<function>
 *       frewind     	<function>
 *       h           	real vector/matrix
 *       i           	integer scalar
 *       indiorec    	<function>
 *       length      	<function>
 *       max         	<function>
 *       noverbose   	integer scalar
 *       ones        	<function>
 *       pause       	<function>
 *       trial       	integer scalar
 *       trialchange 	integer vector/matrix
 *       trialrecords	real vector/matrix
 *******************************************************/
static void dio2mat_(mxArray *H_PP_, mxArray *D_PP_, mxArray *Ntrials_PP_, mxArray *Nrecs_PP_, mxArray *filename_P_, int noverbose )
{
   mxArray *Mplhs_[1];
   mxArray *Mprhs_[3];
   mxArray H;
   mxArray D;
   mxArray Ntrials;
   mxArray Nrecs;
   mxArray endrec;
   mxArray endrec2;
   int fid = 0;
   int count = 0;
   mxArray h;
   mxArray d;
   int dleng = 0;
   int i = 0;
   int N = 0;
   mxArray trialchange;
   mxArray trialrecords;
   int trial = 0;
   mxArray DEBUGIT;
   int I0_ = 0;
   unsigned short B0_ = 0;
   double R0_ = 0.0;
   mxArray IM0_;
   mxArray RM0_;
   mxArray RM1_;
   mxArray IM1_;
   
   mccRealInit(H);
   mccRealInit(D);
   mccRealInit(Ntrials);
   mccRealInit(Nrecs);
   mccIntInit(endrec);
   mccIntInit(endrec2);
   mccRealInit(h);
   mccRealInit(d);
   mccIntInit(trialchange);
   mccRealInit(trialrecords);
   mccRealInit(DEBUGIT);
   mccIntInit(IM0_);
   mccRealInit(RM0_);
   mccRealInit(RM1_);
   mccIntInit(IM1_);
   
   
   /* % _____ SETUP VARS _____ */
   /* global DEBUGIT						% nonzero for verbose */
   /* GLOBAL */
   /* if ~exist('noverbose') noverbose=0; end		% if not inputted */
   Mprhs_[0] = &S16_;
   Mplhs_[0] = 0;
   mccCallMATLAB(1, Mplhs_, 1, Mprhs_, "exist", 31);
   I0_ = mccImportReal(0, 0, Mplhs_[ 0 ], 1, " (dio2mat, line 31): I0_");
   B0_ = (!I0_);
   if ((double)B0_)
   {
      noverbose = 0;
   }
   /* if ~noverbose, fprintf(' ~ DIO2MAT.M ~ '); end	% message */
   if ((double)(!noverbose))
   {
      Mprhs_[0] = &S17_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 32);
   }
   /* endrec=[1; 8564]; 					% EOF INDICATOR (DATAIO) */
   mccCopy(&endrec, &S14_);
   /* endrec2=[1 0 8564 0]; 					% opt. EOF INDICATOR(FMC) */
   mccCopy(&endrec2, &S15_);
   /* H=[];	D=[];						% initialize */
   mccCreateEmpty(&H);
   mccCreateEmpty(&D);
   
   /* % _____ OEPN FILE _____ */
   /* fid=fopen(filename,'r');				% open file for read */
   Mprhs_[0] = filename_P_;
   Mprhs_[1] = &S18_;
   Mplhs_[0] = 0;
   mccCallMATLAB(1, Mplhs_, 2, Mprhs_, "fopen", 38);
   fid = mccImportReal(0, 0, Mplhs_[ 0 ], 1, " (dio2mat, line 38): fid");
   /* if fid==-1, H=-1; D=[];				% if cant open, return */
   if ((fid ==  -1))
   {
      {
         double tr_ =  -1;
         mccAllocateMatrix(&H, 1, 1);
         *mccPR(&H) = tr_;
      }
      mccCreateEmpty(&D);
      /* if ~noverbose,					% if messages wanted */
      if ((double)(!noverbose))
      {
         /* fprintf(' ?  %s not found.\n',filename);		% message */
         Mprhs_[0] = &S19_;
         Mprhs_[1] = filename_P_;
         Mplhs_[0] = 0;
         mccCallMATLAB(0, Mplhs_, 2, Mprhs_, "fprintf", 41);
         /* end 							% */
      }
      /* return;						% stop */
      goto MretH;
      /* end  */
   }
   
   /* % _____ SCAN FILE _____ */
   /* if ~noverbose,fprintf(' scan %s..',filename);end	% message */
   if ((double)(!noverbose))
   {
      Mprhs_[0] = &S20_;
      Mprhs_[1] = filename_P_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 2, Mprhs_, "fprintf", 47);
   }
   /* pause(.05);						% wait 50 msec to update  */
   Mprhs_[0] = mccTempMatrix(.05, 0., mccREAL, 0 );
   Mplhs_[0] = 0;
   mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "pause", 48);
   /* count=0;						% init record counter */
   count = 0;
   /* while (1)						% loop for loading records */
   while ((double)1)
   {
      /* [h,d]=indiorec(fid); 				% read a record */
      indiorec_(&h,&d, fid);
      /* if h(1)==endrec(1)&h(2)==endrec(2),break; end;	% EOF detect */
      B0_ = ( ((mccGetRealVectorElement(&h, mccRint(1))) == ((int)mccGetRealVectorElement(&endrec, mccRint(1)))) && !mccREL_NAN((mccGetRealVectorElement(&h, mccRint(1)))) );
      if ((double)B0_)
      {
         B0_ = ( ((mccGetRealVectorElement(&h, mccRint(2))) == ((int)mccGetRealVectorElement(&endrec, mccRint(2)))) && !mccREL_NAN((mccGetRealVectorElement(&h, mccRint(2)))) );
      }
      if ((double)B0_)
      {
         break;
      }
      /* if h(1)==endrec2(1)&h(3)==endrec2(3),break; end;	% optional EOF detect */
      B0_ = ( ((mccGetRealVectorElement(&h, mccRint(1))) == ((int)mccGetRealVectorElement(&endrec2, mccRint(1)))) && !mccREL_NAN((mccGetRealVectorElement(&h, mccRint(1)))) );
      if ((double)B0_)
      {
         B0_ = ( ((mccGetRealVectorElement(&h, mccRint(3))) == ((int)mccGetRealVectorElement(&endrec2, mccRint(3)))) && !mccREL_NAN((mccGetRealVectorElement(&h, mccRint(3)))) );
      }
      if ((double)B0_)
      {
         break;
      }
      /* if h(1)<19, 						% misc problem */
      if (( ((mccGetRealVectorElement(&h, mccRint(1))) < 19) && !mccREL_NAN((mccGetRealVectorElement(&h, mccRint(1)))) ))
      {
         /* fprintf('corrupt format. Reading up to error..')	% message */
         Mprhs_[0] = &S21_;
         Mplhs_[0] = 0;
         mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 55);
         mccPrint(Mplhs_[0], 0);
         /* break; 						% */
         break;
         /* end;	 */
      }
      /* count=count+1;					% increment recrod counter */
      count = (count + 1);
      /* dleng=length(d);            % patch for matlab 5 (d will be empty on final pass) */
      dleng = mccGetLength(&d);
      /* end 							% End while */
   }
   /* if ~noverbose,fprintf('found %d records.',count);end	% message */
   if ((double)(!noverbose))
   {
      Mprhs_[0] = &S22_;
      Mprhs_[1] = mccTempMatrix(count, 0., mccINT, 0 );
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 2, Mprhs_, "fprintf", 61);
   }
   
   /* % _____ DIMENSION OUTPUT VARIABLES _____ */
   /* H=NaN*ones(20,count);					% header dimen 20 by count */
   R0_ = mxGetNaN();
   mccOnesMN(&IM0_, 20, count);
   {
      int i_, j_;
      int m_=1, n_=1, cx_ = 0;
      double *p_H;
      int I_H=1;
      int *p_IM0_;
      int I_IM0_=1;
      m_ = mcmCalcResultSize(m_, &n_, mccM(&IM0_), mccN(&IM0_));
      mccAllocateMatrix(&H, m_, n_);
      I_H = (mccM(&H) != 1 || mccN(&H) != 1);
      p_H = mccPR(&H);
      I_IM0_ = (mccM(&IM0_) != 1 || mccN(&IM0_) != 1);
      p_IM0_ = mccIPR(&IM0_);
      if (m_ != 0)
      {
         for (j_=0; j_<n_; ++j_)
         {
            for (i_=0; i_<m_; ++i_, p_H+=I_H, p_IM0_+=I_IM0_)
            {
               *p_H = (R0_ * (double) ((int)*p_IM0_));
            }
         }
      }
   }
   /* D=NaN*ones(dleng,count);				% header dimen N by count  */
   R0_ = mxGetNaN();
   mccOnesMN(&IM0_, dleng, count);
   {
      int i_, j_;
      int m_=1, n_=1, cx_ = 0;
      double *p_D;
      int I_D=1;
      int *p_IM0_;
      int I_IM0_=1;
      m_ = mcmCalcResultSize(m_, &n_, mccM(&IM0_), mccN(&IM0_));
      mccAllocateMatrix(&D, m_, n_);
      I_D = (mccM(&D) != 1 || mccN(&D) != 1);
      p_D = mccPR(&D);
      I_IM0_ = (mccM(&IM0_) != 1 || mccN(&IM0_) != 1);
      p_IM0_ = mccIPR(&IM0_);
      if (m_ != 0)
      {
         for (j_=0; j_<n_; ++j_)
         {
            for (i_=0; i_<m_; ++i_, p_D+=I_D, p_IM0_+=I_IM0_)
            {
               *p_D = (R0_ * (double) ((int)*p_IM0_));
            }
         }
      }
   }
   mccLOG(&D) = 0;
   mccSTRING(&D) = 0;
   
   /* % _____ rewind FILE _____ */
   /* frewind(fid);						% set pointer to file begin */
   Mprhs_[0] = mccTempMatrix(fid, 0., mccINT, 0 );
   Mplhs_[0] = 0;
   mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "frewind", 68);
   
   /* % _____ READ FILE _____ */
   /* if ~noverbose,fprintf(' Reading %s..',filename);end	% message */
   if ((double)(!noverbose))
   {
      Mprhs_[0] = &S23_;
      Mprhs_[1] = filename_P_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 2, Mprhs_, "fprintf", 71);
   }
   /* pause(.05);						% wait 5 msec to update  */
   Mprhs_[0] = mccTempMatrix(.05, 0., mccREAL, 0 );
   Mplhs_[0] = 0;
   mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "pause", 72);
   /* for i=1:count */
   for (I0_ = 1; I0_ <= count; I0_ = I0_ + 1)
   {
      i = I0_;
      /* [h,d]=indiorec(fid); 				% read a record */
      indiorec_(&h,&d, fid);
      /* H(:,i)=h;						% append record's header */
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_H;
         int I_H=1, J_H;
         double *p_h;
         int I_h=1;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&h), mccN(&h));
         mccGrowMatrix(&H, m_, i);
         if (mccM(&H) == 1) { I_H = J_H = 0;}
         else { I_H = 1; J_H=mccM(&H)-m_; }
         p_H = mccPR(&H) + 0 + mccM(&H) * (i-1);
         I_h = (mccM(&h) != 1 || mccN(&h) != 1);
         p_h = mccPR(&h);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_H += J_H)
            {
               for (i_=0; i_<m_; ++i_, p_H+=I_H, p_h+=I_h)
               {
                  *p_H = *p_h;
               }
            }
         }
      }
      /* D(:,i)=d;						% append record's data */
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_D;
         int I_D=1, J_D;
         double *p_d;
         int I_d=1;
         m_ = mcmCalcResultSize(m_, &n_, mccM(&d), mccN(&d));
         mccGrowMatrix(&D, m_, i);
         if (mccM(&D) == 1) { I_D = J_D = 0;}
         else { I_D = 1; J_D=mccM(&D)-m_; }
         p_D = mccPR(&D) + 0 + mccM(&D) * (i-1);
         I_d = (mccM(&d) != 1 || mccN(&d) != 1);
         p_d = mccPR(&d);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_D += J_D)
            {
               for (i_=0; i_<m_; ++i_, p_D+=I_D, p_d+=I_d)
               {
                  *p_D = *p_d;
               }
            }
         }
      }
      /* end 							% End while */
   }
   
   /* % _____ CLOSE FILE _____ */
   /* fclose(fid); */
   Mprhs_[0] = mccTempMatrix(fid, 0., mccINT, 0 );
   Mplhs_[0] = 0;
   mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fclose", 80);
   
   /* % _____ ANALYSIS OF FILE _____ */
   /* Ntrials=max(H(3,:));					% number of trials */
   {
      int i_, j_;
      int m_=1, n_=1, cx_ = 0;
      double *p_RM0_;
      int I_RM0_=1;
      double *p_H;
      int I_H=1, J_H;
      m_ = mcmCalcResultSize(m_, &n_, 1, mccN(&H));
      mccAllocateMatrix(&RM0_, m_, n_);
      mccCheckMatrixSize(&H, 3, mccN(&H));
      I_RM0_ = (mccM(&RM0_) != 1 || mccN(&RM0_) != 1);
      p_RM0_ = mccPR(&RM0_);
      if (mccN(&H) == 1) { I_H = J_H = 0;}
      else { I_H = 1; J_H=mccM(&H)-m_; }
      p_H = mccPR(&H) + (3-1) + mccM(&H) * 0;
      if (m_ != 0)
      {
         for (j_=0; j_<n_; ++j_, p_H += J_H)
         {
            for (i_=0; i_<m_; ++i_, p_RM0_+=I_RM0_, p_H+=I_H)
            {
               *p_RM0_ = *p_H;
            }
         }
      }
   }
   mccMax(&Ntrials, &RM0_);
   /* N=length(H(1,:));					% total # columns */
   {
      int i_, j_;
      int m_=1, n_=1, cx_ = 0;
      double *p_RM0_;
      int I_RM0_=1;
      double *p_H;
      int I_H=1, J_H;
      m_ = mcmCalcResultSize(m_, &n_, 1, mccN(&H));
      mccAllocateMatrix(&RM0_, m_, n_);
      mccCheckMatrixSize(&H, 1, mccN(&H));
      I_RM0_ = (mccM(&RM0_) != 1 || mccN(&RM0_) != 1);
      p_RM0_ = mccPR(&RM0_);
      if (mccN(&H) == 1) { I_H = J_H = 0;}
      else { I_H = 1; J_H=mccM(&H)-m_; }
      p_H = mccPR(&H) + (1-1) + mccM(&H) * 0;
      if (m_ != 0)
      {
         for (j_=0; j_<n_; ++j_, p_H += J_H)
         {
            for (i_=0; i_<m_; ++i_, p_RM0_+=I_RM0_, p_H+=I_H)
            {
               *p_RM0_ = *p_H;
            }
         }
      }
   }
   N = mccGetLength(&RM0_);
   /* trialchange=[1 find(diff(H(3,:)))+1];			% cols where trials start */
   {
      int i_, j_;
      int m_=1, n_=1, cx_ = 0;
      double *p_RM0_;
      int I_RM0_=1;
      double *p_H;
      int I_H=1, J_H;
      m_ = mcmCalcResultSize(m_, &n_, 1, mccN(&H));
      mccAllocateMatrix(&RM0_, m_, n_);
      mccCheckMatrixSize(&H, 3, mccN(&H));
      I_RM0_ = (mccM(&RM0_) != 1 || mccN(&RM0_) != 1);
      p_RM0_ = mccPR(&RM0_);
      if (mccN(&H) == 1) { I_H = J_H = 0;}
      else { I_H = 1; J_H=mccM(&H)-m_; }
      p_H = mccPR(&H) + (3-1) + mccM(&H) * 0;
      if (m_ != 0)
      {
         for (j_=0; j_<n_; ++j_, p_H += J_H)
         {
            for (i_=0; i_<m_; ++i_, p_RM0_+=I_RM0_, p_H+=I_H)
            {
               *p_RM0_ = *p_H;
            }
         }
      }
   }
   Mprhs_[0] = &RM0_;
   Mplhs_[0] = &RM1_;
   mccCallMATLAB(1, Mplhs_, 1, Mprhs_, "diff", 85);
   mccFind(&IM0_, &RM1_);
   {
      int i_, j_;
      int m_=1, n_=1, cx_ = 0;
      int *p_IM1_;
      int I_IM1_=1;
      int *p_IM0_;
      int I_IM0_=1;
      m_ = mcmCalcResultSize(m_, &n_, mccM(&IM0_), mccN(&IM0_));
      mccAllocateMatrix(&IM1_, m_, n_);
      I_IM1_ = (mccM(&IM1_) != 1 || mccN(&IM1_) != 1);
      p_IM1_ = mccIPR(&IM1_);
      I_IM0_ = (mccM(&IM0_) != 1 || mccN(&IM0_) != 1);
      p_IM0_ = mccIPR(&IM0_);
      if (m_ != 0)
      {
         for (j_=0; j_<n_; ++j_)
         {
            for (i_=0; i_<m_; ++i_, p_IM1_+=I_IM1_, p_IM0_+=I_IM0_)
            {
               *p_IM1_ = (((int)*p_IM0_) + 1);
            }
         }
      }
   }
   mccCatenateColumns(&trialchange, mccTempMatrix(1, 0., mccINT, 0 ), &IM1_);
   /* trialrecords=diff([trialchange N+1]);			% # records per trial */
   mccCatenateColumns(&IM1_, &trialchange, mccTempMatrix((N + 1), 0., mccINT, 0 ));
   Mprhs_[0] = &IM1_;
   Mplhs_[0] = &trialrecords;
   mccCallMATLAB(1, Mplhs_, 1, Mprhs_, "diff", 86);
   /* Nrecs=max(trialrecords);				% # records (assumed max) */
   mccMax(&Nrecs, &trialrecords);
   /* if ~noverbose 						% if no messages */
   if ((double)(!noverbose))
   {
      /* for trial=1:Ntrials  */
      for (I0_ = 1; I0_ <= mccGetRealVectorElement(&Ntrials, 1); I0_ = I0_ + 1)
      {
         trial = I0_;
         /* fprintf('\ntrial %d has %d records.',	...	% message */
         Mprhs_[0] = &S24_;
         Mprhs_[1] = mccTempMatrix(trial, 0., mccINT, 0 );
         Mprhs_[2] = mccTempVectorElement(&trialrecords, trial);
         Mplhs_[0] = 0;
         mccCallMATLAB(0, Mplhs_, 3, Mprhs_, "fprintf", 91);
         /* end 							% end for trial */
      }
      /* end 							% end if ~noverbose */
   }
   
   /* if ~noverbose, fprintf(' ~ END DIO2MAT.M ~ '); end	% message */
   if ((double)(!noverbose))
   {
      Mprhs_[0] = &S25_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 95);
   }
   /* if DEBUGIT, fprintf('\n'); end; 			% message */
   mccGetGlobal(&DEBUGIT, "DEBUGIT");
   if (mccIfCondition(&DEBUGIT))
   {
      Mprhs_[0] = &S26_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 96);
   }
   
   
   MretH:
   mccCopy(H_PP_, &H );
   mccCopy(D_PP_, &D );
   mccCopy(Ntrials_PP_, &Ntrials );
   mccCopy(Nrecs_PP_, &Nrecs );
   mccFreeMatrix(&H);
   mccFreeMatrix(&D);
   mccFreeMatrix(&Ntrials);
   mccFreeMatrix(&Nrecs);
   mccFreeMatrix(&endrec);
   mccFreeMatrix(&endrec2);
   mccFreeMatrix(&h);
   mccFreeMatrix(&d);
   mccFreeMatrix(&trialchange);
   mccFreeMatrix(&trialrecords);
   mccFreeMatrix(&DEBUGIT);
   mccFreeMatrix(&IM0_);
   mccFreeMatrix(&RM0_);
   mccFreeMatrix(&RM1_);
   mccFreeMatrix(&IM1_);
   return;
}
/*
[RR] = indiorec(i)
*/
/***************** Compiler Assumptions ****************
 *
 *       B0_         	boolean scalar temporary
 *       D           	real vector/matrix
 *       DEBUGIT     	global real vector/matrix
 *       H           	real vector/matrix
 *       S27_        	<constant>
 *       S28_        	<constant>
 *       count       	integer scalar
 *       endrec      	integer vector/matrix
 *       endrec2     	integer vector/matrix
 *       fid         	integer scalar
 *       fprintf     	<function>
 *       fread       	<function>
 *       indiorec    	<function being defined>
 *******************************************************/
static void indiorec_(mxArray *H_PP_, mxArray *D_PP_, int fid )
{
   mxArray *Mplhs_[2];
   mxArray *Mprhs_[4];
   mxArray H;
   mxArray D;
   mxArray DEBUGIT;
   mxArray endrec;
   mxArray endrec2;
   int count = 0;
   unsigned short B0_ = 0;
   
   mccRealInit(H);
   mccRealInit(D);
   mccRealInit(DEBUGIT);
   mccIntInit(endrec);
   mccIntInit(endrec2);
   
   
   /* % _____ SETUP VARS _____ */
   /* global DEBUGIT						% nonzero for verbose */
   /* GLOBAL */
   /* if DEBUGIT, fprintf('\n ~ indiorec.M ~ '); end;	% message */
   mccGetGlobal(&DEBUGIT, "DEBUGIT");
   if (mccIfCondition(&DEBUGIT))
   {
      Mprhs_[0] = &S29_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 15);
   }
   /* endrec=[1; 8564]; 					% EOF INDICATOR (DATAIO) */
   mccCopy(&endrec, &S27_);
   /* endrec2=[1 0 8564 0]; 					% opt. EOF INDICATOR(FMC) */
   mccCopy(&endrec2, &S28_);
   
   /* % _____ READ HEADER _____ */
   /* if DEBUGIT, fprintf('\nRead Header..'); end;	% message */
   mccGetGlobal(&DEBUGIT, "DEBUGIT");
   if (mccIfCondition(&DEBUGIT))
   {
      Mprhs_[0] = &S30_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 20);
   }
   /* % count=0;						% initialize */
   /* [H,count]=fread(fid,20,'short');			% read header */
   Mprhs_[0] = mccTempMatrix(fid, 0., mccINT, 0 );
   Mprhs_[1] = mccTempMatrix(20, 0., mccINT, 0 );
   Mprhs_[2] = &S31_;
   Mplhs_[0] = &H;
   Mplhs_[1] = 0;
   mccCallMATLAB(2, Mplhs_, 3, Mprhs_, "fread", 22);
   count = mccImportReal(0, 0, Mplhs_[ 1 ], 1, " (indiorec, line 22): count");
   /* if DEBUGIT, fprintf('=');fprintf(' %d',H);end	% message */
   mccGetGlobal(&DEBUGIT, "DEBUGIT");
   if (mccIfCondition(&DEBUGIT))
   {
      Mprhs_[0] = &S32_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 23);
      Mprhs_[0] = &S33_;
      Mprhs_[1] = &H;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 2, Mprhs_, "fprintf", 23);
   }
   /* if H(1)==endrec(1) & H(2)==endrec(2), D=[]; return; end;	% EOF detected, exit */
   B0_ = ( ((mccGetRealVectorElement(&H, mccRint(1))) == ((int)mccGetRealVectorElement(&endrec, mccRint(1)))) && !mccREL_NAN((mccGetRealVectorElement(&H, mccRint(1)))) );
   if ((double)B0_)
   {
      B0_ = ( ((mccGetRealVectorElement(&H, mccRint(2))) == ((int)mccGetRealVectorElement(&endrec, mccRint(2)))) && !mccREL_NAN((mccGetRealVectorElement(&H, mccRint(2)))) );
   }
   if ((double)B0_)
   {
      mccCreateEmpty(&D);
      goto MretH;
   }
   /* if H(1)==endrec2(1) & H(3)==endrec2(3), D=[]; return; end;	% optional EOF, exit */
   B0_ = ( ((mccGetRealVectorElement(&H, mccRint(1))) == ((int)mccGetRealVectorElement(&endrec2, mccRint(1)))) && !mccREL_NAN((mccGetRealVectorElement(&H, mccRint(1)))) );
   if ((double)B0_)
   {
      B0_ = ( ((mccGetRealVectorElement(&H, mccRint(3))) == ((int)mccGetRealVectorElement(&endrec2, mccRint(3)))) && !mccREL_NAN((mccGetRealVectorElement(&H, mccRint(3)))) );
   }
   if ((double)B0_)
   {
      mccCreateEmpty(&D);
      goto MretH;
   }
   /* if H(1)<19, fprintf('\nError reading '); D=[]; return; end% misc error */
   if (( ((mccGetRealVectorElement(&H, mccRint(1))) < 19) && !mccREL_NAN((mccGetRealVectorElement(&H, mccRint(1)))) ))
   {
      Mprhs_[0] = &S34_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 26);
      mccCreateEmpty(&D);
      goto MretH;
   }
   
   /* % _____ READ DATA RECORD _____ */
   /* if DEBUGIT,fprintf('\nReading %d values..',H(5));end	% message */
   mccGetGlobal(&DEBUGIT, "DEBUGIT");
   if (mccIfCondition(&DEBUGIT))
   {
      Mprhs_[0] = &S35_;
      Mprhs_[1] = mccTempVectorElement(&H, 5);
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 2, Mprhs_, "fprintf", 29);
   }
   /* count=0;						% initialize  */
   count = 0;
   /* [D,count]=fread(fid,H(5),'float');			% read data */
   Mprhs_[0] = mccTempMatrix(fid, 0., mccINT, 0 );
   Mprhs_[1] = mccTempVectorElement(&H, 5);
   Mprhs_[2] = &S36_;
   Mplhs_[0] = &D;
   Mplhs_[1] = 0;
   mccCallMATLAB(2, Mplhs_, 3, Mprhs_, "fread", 31);
   count = mccImportReal(0, 0, Mplhs_[ 1 ], 1, " (indiorec, line 31): count");
   /* % if DEBUGIT, fprintf(' %d',D); end			% message */
   /* if DEBUGIT,fprintf(' %d records read.',count); end	% message */
   mccGetGlobal(&DEBUGIT, "DEBUGIT");
   if (mccIfCondition(&DEBUGIT))
   {
      Mprhs_[0] = &S37_;
      Mprhs_[1] = mccTempMatrix(count, 0., mccINT, 0 );
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 2, Mprhs_, "fprintf", 33);
   }
   
   /* % if DEBUGIT, disp('pause'); pause; end; 		% message */
   
   /* if DEBUGIT, fprintf(' ~ END indiorec.M ~ '); end; 	% message */
   mccGetGlobal(&DEBUGIT, "DEBUGIT");
   if (mccIfCondition(&DEBUGIT))
   {
      Mprhs_[0] = &S38_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 37);
   }
   MretH:
   mccCopy(H_PP_, &H );
   mccCopy(D_PP_, &D );
   mccFreeMatrix(&H);
   mccFreeMatrix(&D);
   mccFreeMatrix(&DEBUGIT);
   mccFreeMatrix(&endrec);
   mccFreeMatrix(&endrec2);
   return;
}
/*
i = mat2dio(TRR)
*/
/***************** Compiler Assumptions ****************
 *
 *       D           	real vector/matrix
 *       DEBUGIT     	global real vector/matrix
 *       H           	real vector/matrix
 *       I0_         	integer scalar temporary
 *       I1_         	integer scalar temporary
 *       RM0_        	real vector/matrix temporary
 *       RM1_        	real vector/matrix temporary
 *       S39_        	<constant>
 *       count       	integer scalar
 *       endrec      	integer vector/matrix
 *       fclose      	<function>
 *       fid         	integer scalar
 *       filename    	string vector/matrix
 *       fopen       	<function>
 *       fprintf     	<function>
 *       fwrite      	<function>
 *       i           	integer scalar
 *       length      	<function>
 *       mat2dio     	<function being defined>
 *       status      	integer scalar
 *******************************************************/
static void mat2dio_(int *status_PP_, mxArray *filename_P_, mxArray *H_P_, mxArray *D_P_ )
{
   mxArray *Mplhs_[1];
   mxArray *Mprhs_[4];
   int status = 0;
   mxArray DEBUGIT;
   mxArray endrec;
   int fid = 0;
   int i = 0;
   int count = 0;
   int I0_ = 0;
   mxArray RM0_;
   int I1_ = 0;
   mxArray RM1_;
   
   mccRealInit(DEBUGIT);
   mccIntInit(endrec);
   mccRealInit(RM0_);
   mccRealInit(RM1_);
   
   
   /* global DEBUGIT						% nonzero for verbose */
   /* GLOBAL */
   /* if DEBUGIT, fprintf('\n ~ MAT2DIO.M ~ '); end;	% message */
   mccGetGlobal(&DEBUGIT, "DEBUGIT");
   if (mccIfCondition(&DEBUGIT))
   {
      Mprhs_[0] = &S40_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 16);
   }
   /* endrec=[1; 8564]; 					% EOF INDICATOR (DATAIO) */
   mccCopy(&endrec, &S39_);
   
   /* fid=fopen(filename,'w');				% open file for write */
   Mprhs_[0] = filename_P_;
   Mprhs_[1] = &S41_;
   Mplhs_[0] = 0;
   mccCallMATLAB(1, Mplhs_, 2, Mprhs_, "fopen", 19);
   fid = mccImportReal(0, 0, Mplhs_[ 0 ], 1, " (mat2dio, line 19): fid");
   /* if fid==-1, status=1;	else status=0; end %if		% status=1 if cant open */
   if ((fid ==  -1))
   {
      status = 1;
   }
   else
   {
      status = 0;
   }
   
   /* if DEBUGIT, fprintf(' writing to file..'); end	% message */
   mccGetGlobal(&DEBUGIT, "DEBUGIT");
   if (mccIfCondition(&DEBUGIT))
   {
      Mprhs_[0] = &S42_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 22);
   }
   /* for i=1:length(H(1,:)) */
   {
      int i_, j_;
      int m_=1, n_=1, cx_ = 0;
      double *p_RM0_;
      int I_RM0_=1;
      double *p_H;
      int I_H=1, J_H;
      m_ = mcmCalcResultSize(m_, &n_, 1, mccN(H_P_));
      mccAllocateMatrix(&RM0_, m_, n_);
      mccCheckMatrixSize(H_P_, 1, mccN(H_P_));
      I_RM0_ = (mccM(&RM0_) != 1 || mccN(&RM0_) != 1);
      p_RM0_ = mccPR(&RM0_);
      if (mccN(H_P_) == 1) { I_H = J_H = 0;}
      else { I_H = 1; J_H=mccM(H_P_)-m_; }
      p_H = mccPR(H_P_) + (1-1) + mccM(H_P_) * 0;
      if (m_ != 0)
      {
         for (j_=0; j_<n_; ++j_, p_H += J_H)
         {
            for (i_=0; i_<m_; ++i_, p_RM0_+=I_RM0_, p_H+=I_H)
            {
               *p_RM0_ = *p_H;
            }
         }
      }
   }
   I1_ = mccGetLength(&RM0_);
   for (I0_ = 1; I0_ <= I1_; I0_ = I0_ + 1)
   {
      i = I0_;
      /* count=fwrite(fid,H(:,i),'short');			% write header */
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_RM1_;
         int I_RM1_=1;
         double *p_H;
         int I_H=1, J_H;
         m_ = mcmCalcResultSize(m_, &n_, mccM(H_P_), 1);
         mccAllocateMatrix(&RM1_, m_, n_);
         mccCheckMatrixSize(H_P_, mccM(H_P_), i);
         I_RM1_ = (mccM(&RM1_) != 1 || mccN(&RM1_) != 1);
         p_RM1_ = mccPR(&RM1_);
         if (mccM(H_P_) == 1) { I_H = J_H = 0;}
         else { I_H = 1; J_H=mccM(H_P_)-m_; }
         p_H = mccPR(H_P_) + 0 + mccM(H_P_) * (i-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_H += J_H)
            {
               for (i_=0; i_<m_; ++i_, p_RM1_+=I_RM1_, p_H+=I_H)
               {
                  *p_RM1_ = *p_H;
               }
            }
         }
      }
      Mprhs_[0] = mccTempMatrix(fid, 0., mccINT, 0 );
      Mprhs_[1] = &RM1_;
      Mprhs_[2] = &S43_;
      Mplhs_[0] = 0;
      mccCallMATLAB(1, Mplhs_, 3, Mprhs_, "fwrite", 24);
      count = mccImportReal(0, 0, Mplhs_[ 0 ], 1, " (mat2dio, line 24): count");
      /* count=fwrite(fid,D(:,i),'float');			% write data */
      {
         int i_, j_;
         int m_=1, n_=1, cx_ = 0;
         double *p_RM1_;
         int I_RM1_=1;
         double *p_D;
         int I_D=1, J_D;
         m_ = mcmCalcResultSize(m_, &n_, mccM(D_P_), 1);
         mccAllocateMatrix(&RM1_, m_, n_);
         mccCheckMatrixSize(D_P_, mccM(D_P_), i);
         I_RM1_ = (mccM(&RM1_) != 1 || mccN(&RM1_) != 1);
         p_RM1_ = mccPR(&RM1_);
         if (mccM(D_P_) == 1) { I_D = J_D = 0;}
         else { I_D = 1; J_D=mccM(D_P_)-m_; }
         p_D = mccPR(D_P_) + 0 + mccM(D_P_) * (i-1);
         if (m_ != 0)
         {
            for (j_=0; j_<n_; ++j_, p_D += J_D)
            {
               for (i_=0; i_<m_; ++i_, p_RM1_+=I_RM1_, p_D+=I_D)
               {
                  *p_RM1_ = *p_D;
               }
            }
         }
      }
      Mprhs_[0] = mccTempMatrix(fid, 0., mccINT, 0 );
      Mprhs_[1] = &RM1_;
      Mprhs_[2] = &S44_;
      Mplhs_[0] = 0;
      mccCallMATLAB(1, Mplhs_, 3, Mprhs_, "fwrite", 25);
      count = mccImportReal(0, 0, Mplhs_[ 0 ], 1, " (mat2dio, line 25): count");
      /* end %for i 						% */
   }
   
   /* count=fwrite(fid,endrec,'short');			% write EOF indicatior */
   Mprhs_[0] = mccTempMatrix(fid, 0., mccINT, 0 );
   Mprhs_[1] = &endrec;
   Mprhs_[2] = &S45_;
   Mplhs_[0] = 0;
   mccCallMATLAB(1, Mplhs_, 3, Mprhs_, "fwrite", 28);
   count = mccImportReal(0, 0, Mplhs_[ 0 ], 1, " (mat2dio, line 28): count");
   /* fclose(fid); */
   Mprhs_[0] = mccTempMatrix(fid, 0., mccINT, 0 );
   Mplhs_[0] = 0;
   mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fclose", 29);
   
   /* if DEBUGIT, fprintf(' ~ END MAT2DIO.M ~ '); end; 	% message */
   mccGetGlobal(&DEBUGIT, "DEBUGIT");
   if (mccIfCondition(&DEBUGIT))
   {
      Mprhs_[0] = &S46_;
      Mplhs_[0] = 0;
      mccCallMATLAB(0, Mplhs_, 1, Mprhs_, "fprintf", 31);
   }
   
   *status_PP_ = status;
   mccFreeMatrix(&DEBUGIT);
   mccFreeMatrix(&endrec);
   mccFreeMatrix(&RM0_);
   mccFreeMatrix(&RM1_);
   return;
}
