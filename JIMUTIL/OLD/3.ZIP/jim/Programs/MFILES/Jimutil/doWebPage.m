% ************** MATLAB "M" function (jim Patton) *************
% SYNTAX:     doWebPage(doList,filename);
% INPUTS:     doList      (optional) nonzero to do it a list of links
%             filename    (optional) output file with exstension
% OUTPUTS:    
% VERSIONS:   5-11-0
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function doWebPage(doList,filename);

%_________ SETUP ________
if ~exist('doList'), doList=0; end                    % if not passed
if ~exist('filename'), filename='index.htm'; end      % if not passed
CD=parse(cd,'\'); dirName=CD(size(CD,1),:)
s=dir;
S=str2mat('<html>','<body bgcolor="#FDFFE6">',    ... %
  '<font face="Arial">' ,                       ... % 
  ['<h1>' dirName '</h1>'],                       ... % 
  ['<small> <i>(Last updated ' whenis(clock)      ...
    '</small> </i>)'], '<hr>')

% __ generate list ___
for i=3:length(s)
  if ~s(i).isdir
    if doList,
      S=str2mat(S,[' <li> <a href="' s(i).name '">' s(i).name '</a>']); 
    else
      S=str2mat(S,['<img SRC="' s(i).name '" TITLE="' s(i).name '">']); 
    end
  end
end

S
mat2txt('index.htm',S,[]);
pause(.5)
eval(['!' filename]);