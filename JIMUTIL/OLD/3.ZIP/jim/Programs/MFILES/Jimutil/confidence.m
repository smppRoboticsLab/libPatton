%************** MATLAB "M" function  *************
% returns width of wings for INTERVAL confidence interval for column(s) of data
% SYNTAX:       c=confidence(X,interval)
% REVISIONS:    2/18/2000  (patton) INITIATED
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function width=confidence(X,interval)

% ____ SETUP ____
prog_name='learnCurves.m';                    % name of this program
fprintf('\n~ %s ~ ', prog_name); 
if interval>.999999|interval<.00000001,
  error('interval must be between 0 and 1')
end

% ____ CALC ____
N=size(X,1);
r=1-(interval/2); 
tinvValue=tinv(r,N); 						           	% inverse t statistic
width=tinvValue.*sqrt(X)./sqrt(N);