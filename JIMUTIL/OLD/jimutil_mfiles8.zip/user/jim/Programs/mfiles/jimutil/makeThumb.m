% ************** MATLAB "M" function (jim Patton) *************
% Make a thumbnail image at a fraction (scalar) or pixel dimension (2d)
% SYNTAX:     makeThumb(filename,d,show);
% INPUTS:     doList      (optional) nonzero to do it a list of links
%             filename    (optional) output file with exstension
% OUTPUTS:    
% VERSIONS:   5-11-0
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~


function imgr=makeThumb(filename,d,show)

[img,map]=imread(filename);
imgr=imresize(img,d); 
if show, imshow(imgr,map); end 
imwrite(imgr,['thumb_' filename]);

return