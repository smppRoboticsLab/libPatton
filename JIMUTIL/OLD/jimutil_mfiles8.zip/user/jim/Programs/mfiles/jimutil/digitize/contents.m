%X:\programs\mfiles\jimutil\digitize as of 8/24/1998 at 12:42:52
%PLT_PICT.M   % plot a picture (a string of xy points)                             
%MAKE_PIC.M   % make a picture (a string of xy points) by digitizing graphics                        
%MAKE_xygraph.m   % digitize an xy plot from a bitmap, making a string of xy points               
%loadbmp.m   % LOADBMP  Load Microsoft Windows 3.x .BMP format image files.              
