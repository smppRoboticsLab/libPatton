%************** MATLAB "M" function  *************
% Regression of an exponential function using simulated annealing.
% finds the necessary p's to best-fit the function of the 
% form:    f(x)=p1+p2*exp(-x/p3)
% REVISIONS:   7/24/3 (patton) from code from the field design study.
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function [p,cost]=expRegression(p0,x,y)
    fprintf('=================Optimizing..'); pause(.01)                             % 
    p=lsqcurvefit('stepTypeCurve3',p0,x,y);                         % INITIAL eval HERE
    f=stepTypeCurve3(p,x);                                          % Eval base on solved params
    cost=sum((y-f).^2);
    bestP=p; bestCost=cost;                                               % init as best
    options=optimset('TolFun',1e-13);
    
    q=1:1:100; 
    TempSchedule=stepTypeCurve3([0 100 15],q); 
    %plot(q,TempSchedule,'.')
    
    for T=TempSchedule                                                 % simmulated annealing temperature
      fprintf('\n__New step__\n'); pause(.01) 
      p0New=p+T*rand(size(p));                                      % simmulated annealing perturbation
      p=lsqcurvefit('stepTypeCurve3',p0New,x,y,[],[],options);       % OPTIMIZATION HERE      
      f=stepTypeCurve3(p,x);                                         % Eval based on solved params
      cost=sum((y-f).^2);
      if cost<bestCost,                                                   % 
         bestP=p; bestCost=cost;                                          % init as best
      end
    end
    p=bestP; cost=bestCost;                                                % take the best
    fprintf('================= done Optimizing..'); pause(.01)                             % 

return

