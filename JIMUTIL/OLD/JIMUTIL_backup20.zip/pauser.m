function pauser()
fprintf(' Hit a key...')
pause
fprintf('thanks. ')
