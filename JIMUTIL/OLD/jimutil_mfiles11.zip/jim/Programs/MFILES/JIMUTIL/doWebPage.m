% ************** MATLAB "M" function (jim Patton) *************
% Create a webpage from the current directory. 
%   This program is desined to quickly make a webpage from a directory 
%   of pictures using a simple command: "dowebpage," but still be 
%   flexible enough to other things, such as creeate a list of links
% SYNTAX:     doWebPage(doList,filename);
% INPUTS:     doList      (optional) nonzero for list of links instead of pics
%                          if doList is a matrix of strings, then links will 
%                          only be made to those files with matching file 
%                          extensions, for example, '.html'
%             filename    (optional) output file with exstension
%             picWidth    (optional) width of each picture
%             sortBy       (optional) default='name'; you can also 
%                         enter 'date', 'bytes', or 'isdir'
% OUTPUTS:    
% VERSIONS:   5-11-0
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function doWebPage(doList,filename,picWidth,sortBy,recurseDirs,verbose);

% ============ SETUP ============
prog_name='doWebPage.m';                          % this program's name
fprintf('\n~ %s ~  ',prog_name)                         % orient user

if ~exist('doList'), doList=0; end                    % if not passed
if ~exist('filename')|isempty(filename), ...
    filename='index.htm'; 
end                                                   % if not passed
fprintf('search for %s (clear before starting)..' ... % 
  ,filename)
eval(['! erase ' filename]);                          % erase if exists
if ~exist('picWidth'), picWidth=[]; end               % if not passed
if ~exist('sortBy'), sortBy='name'; end               % if not passed
if ~exist('recurseDirs'), recurseDirs=1; end          % if not passed
if ~exist('verbose'), verbose=0; end          % if not passed
CD=parse(cd,'\'); dirName=CD(size(CD,1),:)
s=dir; s(1:2)=[];                                     % get lising; clip 1st 2
H=str2mat('<html>',                               ... % 
  '<! created using doWebPage.m by Jim Patton>',  ... %
  '<body bgcolor="#FDFFE6">',                     ... %
  '<font face="Arial">' ,                         ... % 
  ['<h1>' dirName '</h1>'],                       ... % 
  ['<small><i>Sorted by ' sortBy ':</i></small>'] );
D='<hr>';
S='<hr>';
if ~isempty(picWidth), 
      picWidthStr=['width=' num2str(picWidth)];
else, picWidthStr=[];
end
len=length(s);
fprintf('\n %d items in this directory. \n', len)

% construct matrixes/vectors for sorting 
date=NaN*zeros(len,1);                                % init with size & shape
bytes=NaN*zeros(len,1);
isdir=NaN*zeros(len,1);
name=s(1).name;  
date=datenum(s(1).date); 
bytes=s(1).bytes; 
isdir=s(1).isdir;
for i=2:length(s)                                     % loop ea element on the list
  name=str2mat(name,s(i).name);                       % stack this on
  date(i,1)=datenum(s(i).date);                       % stack this on
  bytes(i,1)=s(i).bytes; 
  isdir(i,1)=s(i).isdir;                              % stack
end
%date=flipud(date)                                    % so most recent is 1st

% re-order using matrixes/vectors for sorting 
eval(['[junk,I]=sortrows(' sortBy ');']);             % get the indexes for reorder
s=s(I);                                               % reorder

% __ generate list ___
fprintf('\nMaking list..'); pause(0.01);              % message
for i=1:length(s)                                     % loop ea element on the list
  fprintf('.')
  if verbose, fprintf('    "%s" \n   ',s(i).name); end% list the names as you go
  
  if ~(strncmp(s(i).name,'thumb_',6))                 % if not a thumbnail pic
  
    if s(i).isdir                                     % if element is subdirectory
      D=str2mat(D,[' <p> <a href="' s(i).name     ... % make subdirectory boldfaced
          '">Click here for <b>' s(i).name        ... %
          '</a> </b></p>']);                          %
      if recurseDirs,                                 % if recuresing subdirectories
        fprintf('\nrecursing subdirectory: ');        % message
        pause(0.01); cd(s(i).name); cd 
        doWebPage(doList,filename,picWidth,     ...   % make page for subdirectory
          sortBy,recurseDirs,verbose);     
        fprintf('\nDone recursing subdirectory. ');   % message
        cd ..
        cd
      end
      
    else                                              % if not a subdirectory:
 
      if doList,   %____ list ____                        % ===== if make a list =====
        if isstr(doList(1,:))                         % if there is list of filetypes
          for j=1:size(doList,1)                          % loop for ea element in doList
            listElement=deblank(doList(j,:));             %
            if strncmp(fliplr(s(i).name),             ... % if end of name matches list
                fliplr(listElement),           ... % 
                length(listElement))               %
              listName=s(i).name(1:(length(s(i).name)-... % clip off the extension
                length(listElement)))                
              S=str2mat(S,[' <li> <a href="' s(i).name... % add link
                  '">' listName '</a>']);                   %
              break                                       % quit the loop
            end                                           % END if strncomp..
          end                                             % END for j
        else                                              %
          S=str2mat(S,[' <li> <a href="' s(i).name    ... % link to file
              '">' s(i).name '</a>']);                    %
        end                                               % END if s(i)

      else  % else no doList:  ___images____          % ===== no list: images =====
        if isempty(picWidth)                            % if no picture width given
          S=str2mat(S,['<img SRC="' s(i).name       ... % show full image
              '" ' picWidthStr ' TITLE="'           ... % 
              s(i).name '">']);                         %
        else                                            % otherwise,
          [junk,junk,thumbName]=makeThumb(s(i).name ... % create a thumbnail
            ,picWidth);                
          S=str2mat(S,['<a href="' s(i).name        ... % show resized pic with link
              '"> <img SRC="' thumbName '" '        ... % put up the thumbnail
              picWidthStr ' TITLE="' s(i).name      ... %
            ' - CLICK to see larger image"></a><!br>']);%
        end                                             % END if isempty(...    
      end                                               % END if dolist
    end                                                 % END  if s(i)....
    
  end                                                   % END if ~(strncmp...(not thumb)

end                                                   % END for i 
fprintf('DONE.')


S=str2mat(H,D,S,['<hr><small> <i>(Last updated '... %
    whenis(clock) '</small> </i>)']);

disp(' saving... ')
mat2txt(filename,S,[]);
pause(.5)
eval(['!' filename]);