% ************** MATLAB "M" function  *************
% text on a plot according to fractions of plot window.
% SYNTAX:	      
% INPUTS:	       S          string of text or matrix of text
% OUTPUTS:      h          handle
% CALLS:	
% REVISONS:     Initiated 
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function h=textOnPlot(S,X,Y); 

ax=axis;
xr=ax(2)-ax(1);
yr=ax(4)-ax(3);

x=X*xr+ax(1);
y=Y*yr+ax(3);

h=text(x,y,S);

return;

