% ***************  MATLAB "M" function  (jim Patton) **************
% Takes (2) x-y (columns) by time (rows) matrices & calculates a 
% distance vs time vector,  and averages it.
% INPUTS:	dist,prox: each a 2-by-n matrix, each having x&y columns
% OUTPUTS:	l, an average length
% CALLS:	-
% CALLED BY:	?
% INITIATIED:	23 June 1994?
% SYNTAX:	l=distance(dist,prox)
% SEE:   	C:\jim\matlab\devel 
%~~~~~~~~~~~~~ begin: ~~~~~~~~~~~

function l=distance(dist,prox)

xd=[dist(:,1) prox(:,1)];
yd=[dist(:,2) prox(:,2)];
d=sqrt((xd(:,2)-xd(:,1)).^2+(yd(:,2)-yd(:,1)).^2);
%plot(d);
%title('marker distance vs time');
l = mean(d);

