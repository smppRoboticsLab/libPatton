%************** MATLAB "M" function (Patton) *************
% make a time record evenly spaced in space instead of time.
% SYNTAX:      OUT=uniformDistance(IN,,verbose);
% INPUTS:      IN       tracetory is a nx3 of [time xpos ypos]
%              spacing  distance between output points
%              verbose  
% OUTPUTS:     OUT      tracetory is a nx3 of [time xpos ypos]
% REVISIONS:	 2/7/2000  Initiated by patton
%~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~

function OUT=uniformDistance(IN,spacing,verbose);

if ~exist('spacing'), spacing=.005; end     % default is half a cm

% ___ generate a path (s) distance ___
D=diff(IN)+.000001;                         % .000001 is for ideal tra-
                                            % jectories that have no change
s(1)=0;
for i=1:size(IN,1)-1,
  s(i+1)=s(i)+sqrt(D(i,2)^2+D(i,3)^2);
end

% ____ interpolate ____ 
OUT=interp1(s,IN,0:spacing:max(s));

return