%X:\programs\mfiles\jimutil as of 8/24/1998 at 12:41:53
%ENGIN_V.M   % The following manages the batch processing of multiple subjects,              
%GETWAIST.M   % The following reads the __.eee (motion)  & finds the average                       
%DRAW_MAN.M   % make a picture of the pull based on segments geometriy files and angle data          
%MENU2.M               s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31,s32);                   
%VTOK.M   % tests whether a trial from the vision experiment has good data                                 
%PLOTPROJ.M   % Create a 3d scaatter plot with linear regresion lines.                              
%DRAWPLUS.M   % Plots an plus (cross hairs), and returns the handle.                         
%DISTANCE.M   % Takes (2) x-y (columns) by time (rows) matrices & calculates a   
%ELLIPSE.M   % Plots an ellipse as a line (plot command), and returns the handle.      
%ELLIPSEP.M   % Plots an ellipse as a patch (patch command), and returns the handle.         
%ISNEG.M   % returns a zero if no negative values exist in the matrix, a    
%DSIGMOID.M   %                                                                
%PLT3WAY.M   % The following plots mean and variances variables for 3 factors (X,Y, and Z)         
%SIGMOID.M   %                                                                
%RESUME.M   % The following sets up for starting the batch processing in the middle
%R_CALC.M   %                                                         
%WHENIS.M   % Plots an ellipse, and returns the handle.                          
%LOADDIO2.M   % The following reads a DIO file & returns it as a matrix x                 
%LRN2_SC.M   % subject correlations for learn_2 datafile results                           
%TEMPLATE.M   %  SYNTAX:	                                                                  
%HDRLOAD.M                                                                        
%CLEANNAN.M   % Delete all lines of data with NaN elements                           
%BUTTERX.M   %fiteredx=BUTTERX(x,sfreq,n,cutoff)                             
%GO.M   % ______ SETUP/STARTUP FOR JIM ______                  
%GETIDS.M   % The following determines the subject data avialable for processing             
%PEARSON.M   % This calculates the pearson product-moment correlation coff (r).              
%ENGIN.M   % The following manages the batch processing of multiple subjects,                        
%SETGRAPH.M   %                                                      
%BMP_SHOW.M   % reads and displays a bmp file on a figure window                
%SORTPULL.M   % sorts a matrix (M1) first into subject, then day, then force based 
%GETINFO2.M   %                                                                                      
%SRT3WY2.M   % The following reads a datafile containing results, sorts the data into subject          
%SORT3WAY.M   % The following reads a datafile containing results,                                      
%F_AND_M5.M   % The following reads the __.eee (motioin)  & __.fmc (forceplate)                        
%VIS_CM_H.M   % determine CM height while standing for a list of vision subjects.                    
%SORTSTAT.M   % Sorts the appropriate submatrix based on input ranges, and output the statistic  
%GETDVTXT.M   % The following reads the __dv.txt (dicreet variable trials) &      
%textract.m   % Extract a set of values from an acii file with headers               
%PLOT2PRJ.M   % this file creates a 3d scaatter plot for the input variable (xyz).                    
%FP_TEST3.M   % this file reads the data,   separates it, & does FFT                   
%FISHER_Z.M   % function z=fisher_z(r)                                           
%STATEP2C.M   % this converts a 2 by N matrix of states in theta (positive to right of 
%SS_CALC.M   %                                                           
%PLTANOV8.M   % The following plots results of doanova2.m                               
%LOADDATA.M   % The following loads variables into data based on k, i and j indicies 
%MIN_DIST.M   % The following calculates an array of minimum distances in 2d     
%textAppend.m   % appends text lines to a text file with a time step.                         
%lrn_wing.m   % Plot 1 or 2 wingsets and central marks as a learning curve of data.       
%SETPATH.M   %                                                                
%put_fig.m   % place a figure on the screen based on fractional dimensions of pixel space
%gaussian.m   % evaluate gaussian time record and its derivative                         
%COL_SORT.M   % Sorts a matrix (MAT) based on increasing order for column col.            
%METAFIG.M   % ~~~~~~~~~~~~~~~~~~~~~~~ M-FILE SCRIPT (PATTON): ~~~~~~~~~~~~~~~~~~~~~~~~                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
%old Inopen3.m   % open an input datio file and get some of the header info.                                           
%parse.m   % Separate out strings separated by tabs in a line of text        
%multibar.m   % a better bar graph                                                
%plt_bmdp.m   % plots data for repeated measures 2 way statistical designs.                  
%ida_top.m   % The following performs inverse dynamic analysis on a multilink system.      
%dbl_diff.m   % Velocity and acceleration calulations from a time record(s).           
%ENGIN2.m   % The following manages the batch processing of multiple subjects,              
%multbar2.m   % A better multiple bar graph.                                               
%multbar3.m   % A better multiple bar graph.                                               
%cop_calc.m   % this calciulates the center of pressure (COP) of a force plate.     
%MAT2TXT.m   % Write an ASCII text file with header and data matrices, readable by HDRLOAD.M       
%subjdata.m   % The following reads the __.fmc (forceplate) and ___dv.txt                              
%fft_plot.m   % Removes DC & calculates FFT & plots (if desired). Expects impulse-like signal.
%old Inopen.m   % open an input datio file and get some of the header info.                                           
