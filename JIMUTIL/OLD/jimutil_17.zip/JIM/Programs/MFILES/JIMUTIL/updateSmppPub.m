
% update \\Sulu\C\Inetpub\wwwroot\~smpp_pub webpage
cd \\Sulu\C\Inetpub\wwwroot\~smpp_pub
cd
doWebpage(['.htm ';'.html'])
