% ************** MATLAB "M" function (jim Patton) *************
% SYNTAX:     doWebPage(doList,filename);
% INPUTS:     doList      (optional) nonzero to do it a list of links
%             filename    (optional) output file with exstension
% OUTPUTS:    
% VERSIONS:   5-11-0
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function doWebPage(doList,filename,picWidth);

%_________ SETUP ________
if ~exist('doList'), doList=0; end                    % if not passed
if ~exist('filename')|isempty(filename), ...
    filename='index.htm'; 
end                                                   % if not passed
if ~exist('picWidth'), picWidth=[]; end               % if not passed
CD=parse(cd,'\'); dirName=CD(size(CD,1),:)
s=dir;
S=str2mat('<html>','<body bgcolor="#FDFFE6">',    ... %
  '<font face="Arial">' ,                         ... % 
  ['<h1>' dirName '</h1>'],                       ... % 
  ['<small> <i>(Last updated by Patton ' whenis(clock)      ...
    '</small> </i>)'], '<hr>')
if ~isempty(picWidth), 
      picWidthStr=['width=' num2str(picWidth)];
else, picWidthStr=[];
end

% __ generate list ___
for i=3:length(s)
  %if ~s(i).isdir
    if doList,
      S=str2mat(S,[' <li> <a href="' s(i).name '">' s(i).name '</a>']); 
    else
      S=str2mat(S,['<img SRC="' s(i).name '" ' picWidthStr ' TITLE="' s(i).name '">']); 
    end
  %end
end

S
mat2txt('index.htm',S,[]);
pause(.5)
eval(['!' filename]);