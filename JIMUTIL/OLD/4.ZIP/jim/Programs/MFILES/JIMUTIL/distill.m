%************** MATLAB "M" function  *************
% reduce a vector to only unique members
% SYNTAX:      
% REVISIONS:  9-9-0 Initated (patton)
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function X=distill(x)

% ____ SETUP ____

X=x(1);

for i=2:length(x)
  for j=1:length(X)
    if x(i)==X(j), keep=0; break; else; keep=1; end
  end
  if keep, X=[X x(i)]; end
end


return