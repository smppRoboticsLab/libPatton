% ************** MATLAB "M" function (jim Patton) *************
% SYNTAX:     doWebPage(doList,EXT,filename);
% INPUTS:     doList      (optional) nonzero to do it a list of links
%             EXT      (optional) restrict to a string of final 
%                          characters to match. Example:  '.jpg'
%             filename    (optional) output file with exstension
% OUTPUTS:    hypertext file 
% VERSIONS:   5-11-0  INITIATED
%             7/5/0   add EXT types
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function doWebPage(doList,EXT,filename);

%_________ SETUP ________
if ~exist('doList'), doList=0; end                    % if not passed
if ~exist('filename'), filename='index.htm'; end      % if not passed
if ~exist('EXT'), EXT='*.*'; end                      % if not passed
CD=parse(cd,'\'); dirName=CD(size(CD,1),:); s=dir;

S=str2mat('<html>','<body bgcolor="#FDFFE6">',    ... %
  '<font face="Arial">' ,                         ... % 
  ['<h1>' dirName '</h1>'],                       ... % 
  ['<small> <i>(Last updated ' whenis(clock)      ... %
    '</small> </i>)'], '<hr>');

% __ generate list ___
fprintf('\nMaking list.. ')
for j=1:size(EXT,1)
  E=deblank(EXT(j,:));
  for i=3:length(s)
    NL=length(s(i).name); EL=length(E);               % length of name & extension
    fprintf('\nConpare "%s" to "%s", success=%d. ', E,s(i).name(NL-EL+1:NL), strcmp(E,s(i).name(NL-EL+1:NL)) )
    if ~s(i).isdir                                ... % if not a direct
       &(strcmp(EXT(j,:),'*.*')                   ... % and either: all files chosen
        |strcmp(E,s(i).name(NL-EL+1:NL)) )            %   or extension matches, then
      if doList,
        S=str2mat(S,[' <li> <a href="' s(i).name '">' s(i).name '</a>']); 
      else
        S=str2mat(S,['<img SRC="' s(i).name '" TITLE="' s(i).name '">']); 
      end % END if doList
    end % END if ~s
  end % END for i
end % END for j   

S
mat2txt(filename,S,[]);
pause(.5)
eval(['!' filename]);