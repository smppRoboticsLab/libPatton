%X:\programs\mfiles as of 8/28/1998 at 11:2:2
%BUTTERX.M   % filters x with a nth order lowpass Butterworth filter         
%ONOFFCK.M   % Plots a time series, draws in a pre-selected point in that series         
%CROSS_CC.M   % Finds the cross correlation of two time series, a & b                               
%INAROW.M   % locates the first of n consecutively increasing numbers in matix x returns the number c and its index i                 
%INAROW2.M   % locates blocks of increasing numbers, returns the first number of each block and corresponding index                                       
%INTEG.M   % INTEG	Integrative function.                                                    
%LCVALUES.M   % Finds discrete values for pulling force Fp:                                           
%CMBLEND.M   % calculates cmx and cmy from .eee file for pulling or bilateral arm flexion compares results to cmx and cmy                       
%ONOFFCK2.M   % Plots a time series, draws in a pre-selected point in that series          
%PKOFFSET.M   % Given specific parameters, cycles through a given signal and finds the offset                    
%PKONSET.M   %FUNCTION onset = pkonset(buf,sp,ep,bmean,std,sf,cp,tp)              
%PKONSET2.M   % Given specific parameters, cycles through a given signal and finds the index of the onset                                                                                                                                                                                                            
%READDIO.M   %reads a given trial from a datio file defined by fileinfo
%SHOW_BUT.M   % Display fig mouse button props that cause probs with MOVEAXIS.M (for debugging).     
%SLOPES.M   %finds a vector of P point slopes of vector C from index iSE(1) to index iSE(2)
%VEL.M   % Derivative function: DX=VEL(T,X)                                        
%ZCROSS.M   % locates the indexes of the zero-crossings in matix x returns the lower number of the indexes
%INV_DYN5.M   % bottom up inverse dynamic analysis on a multilink system.                          
%ANGS.M   % Calculates joint angles from kinematic data. Currently calculates only head and trunk angle (with respect to space)
%CMVALUES.M   % CMVALUES: finds discrete values for CM displacement and displays a summary plot   
%DISTANCE.M   % takes (2) x-y (columns) by time (rows) matrices and calculates a dist vs time vector, and averages it.
%EMGONSET.M   % Finds the indices of specified EMG signal onsets                                                                                
%EMGTEST.M   % Finds onsets and offsets of EMG signals, allows you to edit these choices, plots results for PILOT121 data                                                                                                                                                                                         
%ENSMAT.M   %Adds data from a given trial onto a matrix of time series, from which ensemble averages will later be computed.                                                                                                               
%FILEID.M   %identifies files (LEARN2 nomenclature)             
%FILEID3.M   %identifies files (VISION nomenclature)                                       
%FMCBAT3.M   % Prompts user to input info for identifying discrete vaues, then calls FMCMARK3.m                                                                      
%OPENDDD.M   % open a datio file and give out file id, total trial number, total channel number, and channel id 
%GET_CHN.M   % get a specified channel of a given trial                    
%GET_TRI.M   % get a specified trial data from an opened datio file            
%GET_TRI1.M   % get a specified trial data from an opened dation file
%GIRSYNCH.M   % shifts the ACQUIRE data so that this point is aligned with the last ELITE data point             
%INOPEN.M   %A=inopen(fname) open an input datio file and get some info.                
%INOPEN1.M   % opens an input datio file which contains only one trial and gets some info.                        
%IRSYNCH2.M   % shifts the ACQUIRE data so that this point is aligned with the last ELITE data point 
%IRSYNCH3.M   % Syncronize kinematic(EEO) & "all other" (DDO) data in time.       
%JFILEID.M   % Finds the file name for a given subject, block number, and extension                        
%SEEDATIO.M   % cycles through a datio file allowing you to locate "BAD" data                                                                                       
%LOADF.M   % loads ASCII input file pathfname.ext                                                                                                                                                                            
%LRN2DISC.M   % Identifies which subjects' data is to be found on the indicated disc for data from LEARN2 study
%MARKERS.M   %defines x and y coordinate of markers  (in mms) and transform coordinate system so that the origin is at the ankle
%MENU2.M   % MENU	Generate a menu of choices for user input.                                                                                            
%MENUA.M   % MENU	Generate a menu of choices for user input.                                                                                            
%NEARTARG.M   % Determines if the actual force on a given trial is close to some target forces     
%NEARTARV.M   % Determines if the actual force on a given trial is close to some target forces     
%NECKLEN.M   % Returns the value of dneck for a given subject     
%OUTEB_P.M   % Outputs variables of interest to EXCEL and BMDP files, for further analysis                             
%OUTEB_V.M   % Outputs variables of interest to EXCEL and BMDP files, for further analysis                             
%OUTEB_VP.M   % Outputs variables of interest to EXCEL and BMDP files, for further analysis                             
%PHASEPTS.M   % Defines specific pts within the pulling task for a specific trial                                   
%PIRSYNCH.M   % shifts the ACQUIRE data so that this point is aligned with the last ELITE data point             
%PLOTBOX.M   % Plots a box of specified dimensions on the current plot                                  
%PRINTOPT.M   % PRINTOPT Configure local printer defaults.                        
%READDV.M   %returns dv.txt data for trial in matrix D (6 rows x 11 columns):                                                         
%RMS.M   %R=RMS(y,ysim) computes RMS:           
%RMSVALUE.M   % RMSVAL	root mean square value for vectors or matrices
%SCALEV.M   % scales plot windows of head ang vel?               
%SCALEWIN.M   % scales plot windows?                            
%SHIFT.M   %line up Fx-Fp (F1) and m*CMap accel (F2) at peaks by shifting F1 by nshift data points
%ACCEL.M   % ACCEL	Derivative function.                                                            
%STAND.M   % finds the vector that transforms the waist target to a position at the L5/S1 joint 
%TARGETID.M   % identifies the pulling force target in %,            
%TEMP_VIS.M   %7 December 1995	J.W.Steege                                                                       
%TESTME.M   % DEFINE FP, CMx, CMy, CMx vel., CMy vel.                        
%TIMEANGS.M   %Plots ankle, knee, and hip joint angle time histories for PCA paper            
%TIRSYNCH.M   % shifts the ACQUIRE data so that this point is aligned with the last ELITE data point              
%TMP_LRN2.M   %Finds changes in various head stabilization measures with practice                               
%VISION.M   % Identifies whether vision was available on the block or not                                 
%plot_DIO.m   % Makes Plots for checking the time records in a DIO file (block of data)         
%EDSHIFT2.M   % shifts force plate/load cell data for .fmc files, plots and writes, see help               
%FIX_LRN2.M   % Edits a datio file to delete a problem trial (puts 0's for data and indicates bad trial in the header)                                    
%FIX_PIL.M   % Edits a datio file to delete a problem trial for datio files from the VISION experiment                                                   
%FIX_VIS.M   % Edits a datio file to delete a problem trial (puts 0's for data and indicates bad trial in the header)                                    
%GTDVTXT.M   % The following reads the __dv.txt (dicreet variable trials) & returns dv.txt data for trial in matrix DV
%GTWAIST.M   % reads the .eee & finds the average angle between the hip-neck and hip-waist vectors.              
%IRSYNCH.M   % shifts the ACQUIRE data so that this point is aligned with the last ELITE data point             
%JEDSHIFT.M   % shifts force plate/load cell data for .fmc files loads .foo file (.foo file=old .fmc file), plots and writes a lot!  see help.
%JFMCBAT.M   % prompts user to input subject info and calls JFMCMARK to continue processing                                                                                    
%JFMCMARK.M   % defines discrete values for pulling force, ANTERIOR-POSTERIOR center of mass velocity and displacement
%JIRSYNCH.M   % shifts the ACQUIRE data so that this point is aligned with the last ELITE data point             
%JPERCMAX.M   % returns estimated maximum pulling force (N), heightm (m), weightkg (kg) or PERCMAXF
%LUMACC.M   % ESTIMATES THE ERRORS IN LUMBAR ANGLE FOR "OLD" 10 SUBJECTS                                                                                                                                       
%LUMBMRKR.M   % COMPUTES ESTIMATE OF L5/S1 JOINT CENTER LOCATION FROM WAIST AND HIP MARKER DATA FOR A SINGLE TRIAL
%LUMBPARA.M   % Get the paramters required to compute transformation of the waist marker for a particular day, block, id
%PERCMAXF.M   % returns estimated maximum pulling force (N), heightm (m), weightkg (kg) or PERCMAXF
%SEGACC_P.M   % Measures accuracy of ELITE data by finding SDs and ranges of segment lengths over time. For LEARN2 experiments                                                                                                                                                                                                                                                                                                       
%SEGACC_V.M   % Measures accuracy of ELITE data by finding SDs and ranges of segment lengths over time. For VISION experiments                                                                                                                                                                                                                                                                                                       
%SYNCHDIO.M   % synchronize datio files based on user provied synch point information.
%scd.m   % Syncronize & combine raw kinematic(EEE) & other(DDD) collection data.         
%acquire2d99.m   % Batch the processing of output from the ACQUIRE program (force, EMG, etc.)     
%Inopen3.m   % open an input datio file and get some of the header info.                                           
%dcheck.m   % Check and repair an ACQUIRE file (force, load cell, EMG, etc).        
%loadcell.m   % Convert load cell voltage signal in ___.ddd file to force (Newtons).          
%echeck.m   % Check and repair an ELITE file (created from EL-PROC).                        
%dio2mat.m   % read an entire DIO file into header and data matrices.                          
%g97batch.m   % modified version of JLP's batch1.m, batch the processing of a trial with motion and force (& possibly EMG)
%indiorec.m   % read a single record of a DIO file.                                          
%MAT2DIO.m   % Write an entire DIO file from header and data matrices.            
%CM.m   % calculates cmx and cmy from .eee file for pulling or bilateral arm flexion compares results to cmx and cmy 
%e2meters.m   % Convert a DIO-FORMAT ELITE output file from milimeters to meters        
%etrans.m   % translate marker traject. by subtracting a marker's position and/or a vector                                         
%el_proc2.m   % Convert elite data format to DATIO format, or write dummy data                
%dtrans.m   % Transform forceplate data in the DIO-formatted ACQUIRE file to LAB coords. 
%srabatch.m   % batch the processing of a trial with motion and force (& possibly EMG)                                                         
%scd400.m   % Syncronize & combine raw kinematic(EEE) & other(DDD) collection data.        
%dbqbatch.m   % batch the processing of a trial with motion and force (& possibly EMG) 
%angle_2d.m   % calculates the relative 2 D angle between 2 vectors constructed from points.
%scd2cop.m   % Calc center o pressure(COP[x,z]) from .SCD file in lab coords: x=west, z=north
%getrec.m   % returns a single record of a DIO datastructure                         
%scd2cm.m   % Calc center of mass(CM[x,y]) from .SCD file in lab coords: x=west, y=up       
%pull_model.m   % Establish a rigid body model (mass distrib and geom) from marker data.            
%dio_rec.m   % Returns subset of records (columns) from a DIO datastructure.               
%scd2ang.m   % Calc angles of "body segment vectors" with espect to horizontal           
%pullerr6.m   % Read .scd file to plot error between max pull and target pull per trial for 6 blocks to see a "learning curve".  
%pullerr5.m   % Read .scd file to plot error between max pull and target pull per trial for 5 blocks to see a "learning curve".  
%pullerr4.m   % Read .scd file to plot error between max pull and target pull per trial for 4 blocks to see a "learning curve".  
%hang2tor.m   % inverse dynamic analysis of head angle to get torques                      
%raw2scd.m   % processes filtered elite and raw acqire data into .scd files                                                   
%seg_cm.m   % calculate a rigid body segment's CM based on marker data and MODEL parameters.
%pc_proc2.m   % Convert data collected from Peter Pidcoe's "Acquire" Program to DATIO format. 
%diomesh.m   % M-file program to extract a specified datatype(s) from a dio file(s) and output it to a new designated dio file.
%dif_dio.m   % M-file program to take first derivative of a datatype from a block of data and output it to a designated dio file.
%elite2e99.m   % Batch the processing of output from the ELITE program (Motion), combines w/ ACQUIRE and makes .scd.           
%VVALUES.m   % Finds discrete values for Center of Mass velocity, etc:                       
%dv.m   % Interactive graphic program obtain misc. discreet values for the pull task.         
%scd2hcd.m   % batch the processing of a trial (head angle/torque phase)                                          
%defbase.m   % Defines baseline from time BE(1) s to time BE(2) s. plots, see help       
%onset.m   % Determines the onset of a signal (when it begins to change).                  
%vsplot.m   % Plots 2 datatypes vs. each other                                               
%do_junkplot.m   % runs patton's junkplot for BOS protocol
%mlist.m   % create table of contents of a directory's mfiles                                                            
