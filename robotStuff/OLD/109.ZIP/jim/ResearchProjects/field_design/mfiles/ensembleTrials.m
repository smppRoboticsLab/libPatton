% ************** MATLAB "M" function (jim Patton) *************
% load, average adn save an ensemble of robot trials
% SYNTAX:    
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  11/1/99 initiated
%            3/6/00 added outName as an input 
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function ensembleTrials(trialList,outName,plotit,verbose)

% __ SETUP __
fcnName='ensembleTrials.m';
if ~exist('verbose'), verbose=1; end                  % if not passed
if ~exist('plotit'), plotit=1; end                    % if not passed
if ~exist('outName'), outName='FD-0.dat'; end         % if not passed
Ntrials=length(trialList);
speed_thresh_for_move=.2;                             % min speed
cutoff=10;                                            % cutoff freq for filtering
len=9999;                                             % init really big
Ys2m=find1TXTvalue('parameters.txt',              ... % load this from a paramter file
  'Yshoulder2motor=',0);                              %
Xs2n=find1TXTvalue('parameters.txt',              ... % load this from a paramter file
  'Xshoulder2nose=',0);                               %

%__ MESSAGES __
if verbose, fprintf('\n ~ %s ~ ',fcnName); end      %
if verbose,  fprintf('  (%d trials)',Ntrials); end      %      

%____ ASSEMBLE CUBE OF DATA ____
if verbose,   fprintf('\n  Trial: '); end
CUBE=[];                                              % init
for trial=1:Ntrials
  fprintf(' %d',trialList(trial));                    % message 
  %fprintf('\n trial %d',trialList(trial));                    % message 
  filename=['FD-' num2str(trialList(trial)) '.dat'];  % assign trial filename
  [rho,F,Hz]=loadRobotData(filename,cutoff,0);        % load & transform to subj c.s.
  if isnan(rho), fprintf(' rho=NaN! '); break; end;   % if no more files, quit
  speed=sqrt(rho(:,3).^2+rho(:,4).^2);                % calc speed
  for St=1:length(speed)                              % loop: find start movemt
    if speed(St)>speed_thresh_for_move, break; end    % find mvmt initiation
  end                                                 %
  St=St-20; if St<1, St=1; end                        % go back in time 20 frames
  if verbose,  fprintf('(startFrame#%d)',St); end     %      
  %if verbose, fprintf('\nlen=%d, Cubesize:',len);end %      
  %size(CUBE)
  if len>length(St:length(speed)),                    % if ensemble length too long 
    len=length(St:length(speed));                     % shorten it to current length
    if ~isempty(CUBE), CUBE=CUBE(1:len,:,:); end      % if not empty, clip it down
  end
  CUBE(:,:,trial)=[rho(St:St+len-1,:) F(St:St+len-1,:)];
  if plotit
    subplot(2,1,1); 
    plot(CUBE(:,1,trial),CUBE(:,2,trial),':')
    hold on, axis equal    
    subplot(2,1,2); 
    plot(CUBE(:,3:4,trial),':')
    hold on
    %disp('  hit a key...');pause
  end
end

%____ ASSEMBLE CUBE OF DATA ____
if verbose, fprintf(' Average..');  end
MEAN=cubeStat(CUBE,'mean',0);

%____ SAVE DATA ____
if verbose,   
  fprintf('\nTransform to Robot Coords & save..');  
end
saveDataman(                                    ... % 6 columns (2pos,2vel,2force)
[outName],                                      ... % file name
[   -MEAN(:,1)-Xs2n                             ... % Transform to Robot Coords
    -MEAN(:,2)+Ys2m                             ... % Transform to Robot Coords
    -MEAN(:,3:4)                                ... % Transform to Robot Coords
    -MEAN(:,5:6);                               ... % Transform to Robot Coords
 -7777 trial Hz 1 0 0;                          ... % 2nd to last line is params
 -7777 0 0 0 0 0]  );                               % last line is params too


%____ PLOT ____
if plotit
  subplot(2,1,1); 
  plot(MEAN(:,1),MEAN(:,2),'linewidth',3)
  title('positions'); xlabel('x(m)');ylabel('y(m)')

  subplot(2,1,2); 
  legend(plot(MEAN(:,3:4),'linewidth',3),'x','y',-1)
  title('velocities');ylabel('m/s');xlabel('seconds')
  
  suptitle('ensemble averages');
  
  if verbose, 
    fprintf('\nprinting figure to baselineEnsemble.eps..');
  end
  print -dpsc2 -append baselineEnsembles

end


