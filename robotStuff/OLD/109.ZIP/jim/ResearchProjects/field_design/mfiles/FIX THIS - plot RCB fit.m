  %_______ plot ______
  if plotit==1, 
    LW=3;
    clf;
    time=(0:length(rhoI(:,1))-1)/Hz; time=time';
  
    sumFrc=0*rhoI(:,1:2);                               % init
    for i=1:length(RCB)                                 % LOOP FOR EACH rcBASIS
      Frc=rcEval3(rhoI,RCB(i),0);                       % rc force evaluations 
      subplot(3,1,1), 
      plot(time,rc(i).*Frc(:,x),'b:'); hold on
      subplot(3,1,2), 
      plot(time,rc(i).*Frc(:,y),'b:'); hold on
      sumFrc=sumFrc+rc(i).*Frc;
    end                                                 % END for i
  
    subplot(3,1,1), 
    h=plot(time(StI:StI+len),FccI(:,x),'r',         ...
      time,sumFrc(:,x),'b:','linewidth',LW);
    legend(h,'CC','RC',0);
    hold on
    title('X forces (N)'); 

    subplot(3,1,2), 
    h=plot( time(StI:StI+len),FccI(:,y),'r',          ...
          time,sumFrc(:,y),'b:','linewidth',LW); 
        title('Y forces (N)'); 
    legend(h,'CC','RC',0);
    hold on
    xlabel('seconds')
  
    subplot(3,1,3)
    plot(time,rhoI(:,3:4)); title('velocity');
  
  end % END if plotit

  if plotit==2, % for adding a curve on top to already run
    time=(0:length(rhoI(:,1))-1)/Hz; time=time';
    subplot(3,1,1)
    plot(time(StI:StI+len),FccI(:,x),'k');
    subplot(3,1,2)
    plot(time(StI:StI+len),FccI(:,y),'k');
  end % END if plotit

  if plotit,
    suptitle('RC Model fit along unperturbed trajectory');
    if verbose, 
     fprintf('\nprinting figure to model_fit.ps..');
    end
    print -depsc2 model_fit
  end % END if plotit