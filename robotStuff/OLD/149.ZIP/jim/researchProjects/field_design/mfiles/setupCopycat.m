%___________________*** MATLAB "M" script (jim Patton) ***____________________
% Sets up parameters for the copycat basis functions for 2-joint link & controller:
% VERSIONS:   INITIATED 11/17/99 by patton, split off from set_params.m
%             5/16/0 made it a function
%__________________________________ BEGIN: ____________________________________

function [CCB,CCwings]=setupCopycat2(M,L,R,Kact,Bact,CCwings,spreadScale)

% ___ SETUP ___
fprintf('\n ~ setupCopycat.m  ~ ')
if ~exist('spreadScale'), spreadScale=1; end
CCwings.impedanceSpread=.3;                         % fractional plus or minus amount 
CCwings.massSpread=.1;                              % fractional plus or minus amount 
CCwings.geometrySpread=.025;                        % absolute plus or minus amount 
CCwings.shoulderSpread=.02;                         % absolute plus or minus amount 

% ___ INIT COPYCAT BASIS (CCB) with Best guess ___
for i=1:37                                          % init. best guess into all CCB's  
    CCB(i).M=M;    CCB(i).L=L;   CCB(i).R=R;   
    CCB(i).K=Kact; CCB(i).B=Bact; 
    CCB(i).X=0;    CCB(i).Y=0;
    CCB(i).cc=0;
end

%__ Now vary each param in 1 direction __
CCB(1).M(1,1)=CCB(1).M(1,1)*(1+CCwings.massSpread*spreadScale);            
CCB(2).M(1,1)=CCB(2).M(1,1)*(1-CCwings.massSpread*spreadScale);     
CCB(3).M(1,2)=CCB(3).M(1,2)*(1+CCwings.massSpread*spreadScale);
CCB(4).M(1,2)=CCB(4).M(1,2)*(1-CCwings.massSpread*spreadScale);
CCB(5).M(2,1)=CCB(5).M(2,1)*(1+CCwings.massSpread*spreadScale);
CCB(6).M(2,1)=CCB(6).M(2,1)*(1-CCwings.massSpread*spreadScale);
CCB(7).M(2,2)=CCB(7).M(2,2)*(1+CCwings.massSpread*spreadScale);
CCB(8).M(2,2)=CCB(8).M(2,2)*(1-CCwings.massSpread*spreadScale);
CCB(9).R(1)=CCB(9).R(1)*(1+CCwings.geometrySpread/2*spreadScale);
CCB(10).R(1)=CCB(10).R(1)*(1-CCwings.geometrySpread/2*spreadScale);
CCB(11).R(2)=CCB(11).R(2)*(1+geometrySpread/2*spreadScale);
CCB(12).R(2)=CCB(12).R(2)*(1-CCwings.geometrySpread/2*spreadScale);
CCB(13).L(1)=CCB(13).L(1)*(1+CCwings.geometrySpread*spreadScale);
CCB(14).L(1)=CCB(14).L(1)*(1-CCwings.geometrySpread*spreadScale);
CCB(15).L(2)=CCB(15).L(2)*(1+CCwings.geometrySpread*spreadScale);
CCB(16).L(2)=CCB(16).L(2)*(1-CCwings.geometrySpread*spreadScale);
CCB(17).B(1,1)=CCB(17).B(1,1)*(1+CCwings.impedanceSpread*spreadScale);
CCB(18).B(1,1)=CCB(18).B(1,1)*(1-CCwings.impedanceSpread*spreadScale);
CCB(19).B(2,2)=CCB(19).B(2,2)*(1+CCwings.impedanceSpread*spreadScale);
CCB(20).B(2,2)=CCB(20).B(2,2)*(1-CCwings.impedanceSpread*spreadScale);
CCB(21).B(2,1)=CCB(21).B(2,1)*(1+CCwings.impedanceSpread*spreadScale);
CCB(21).B(1,2)=CCB(21).B(1,2)*(1+CCwings.impedanceSpread*spreadScale); % SYMMETRIC; KEEP SAME
CCB(22).B(2,1)=CCB(22).B(2,1)*(1-CCwings.impedanceSpread*spreadScale);        
CCB(22).B(1,2)=CCB(22).B(1,2)*(1-CCwings.impedanceSpread*spreadScale); % SYMMETRIC; KEEP SAME
CCB(23).K(1,1)=CCB(23).K(1,1)*(1+CCwings.impedanceSpread*spreadScale);
CCB(24).K(1,1)=CCB(24).K(1,1)*(1-CCwings.impedanceSpread*spreadScale);
CCB(25).K(2,2)=CCB(25).K(2,2)*(1+CCwings.impedanceSpread*spreadScale);
CCB(26).K(2,2)=CCB(26).K(2,2)*(1-CCwings.impedanceSpread*spreadScale);
CCB(27).K(2,1)=CCB(27).K(2,1)*(1+CCwings.impedanceSpread*spreadScale);
CCB(27).K(1,2)=CCB(27).K(1,2)*(1+CCwings.impedanceSpread*spreadScale); % SYMMETRIC; KEEP SAME
CCB(28).K(2,1)=CCB(28).K(2,1)*(1-CCwings.impedanceSpread*spreadScale);
CCB(28).K(1,2)=CCB(28).K(1,2)*(1-CCwings.impedanceSpread*spreadScale); % SYMMETRIC; KEEP SAME
CCB(29).X=CCB(29).X-CCwings.shoulderSpread*spreadScale;            
CCB(30).X=CCB(30).X+CCwings.shoulderSpread*spreadScale;            
CCB(31).Y=CCB(31).Y-CCwings.shoulderSpread*spreadScale;            
CCB(32).Y=CCB(32).Y+CCwings.shoulderSpread*spreadScale;    

CCB(33).X=CCB(33).X-CCwings.shoulderSpread;            
CCB(33).Y=CCB(33).Y-CCwings.shoulderSpread;            

CCB(34).X=CCB(34).X+CCwings.shoulderSpread;           
CCB(34).Y=CCB(34).Y-CCwings.shoulderSpread;            

CCB(35).X=CCB(35).X+CCwings.shoulderSpread;            
CCB(35).Y=CCB(35).Y+CCwings.shoulderSpread;        

CCB(36).X=CCB(36).X-CCwings.shoulderSpread;         
CCB(36).Y=CCB(36).Y+CCwings.shoulderSpread;                             

CCB                                           % Note: final CCB is "best guess"

fprintf(' ~ END setupCopycat.m ~ \n')
return