  %__ Construct ROBOT CONTROL BASIS (RCB) along rhoI __
  gsf=4.2919;                                           % makes gaussian have a width 1
                                                      % at 1% of the total magnitude
  %RCBwidth=.1;                                         % spacing between centers
  RCBwidth=( rhoD(length(rhoD),2)-rhoD(1,2) )*1;        % for testing single rcb 
  k=(gsf/RCBwidth)^2;                                   % for region of effectiveness
  %anchor=[rhoI(StI,1) rhoI(StI,2)];                    % init for small distance
  anchor=[9999 9999];                                   % init for big distance 
  j=0;
  for i=StI:StI+len                                     % drop down basis fields only for start
    dist=sqrt((rhoI(i,1)-anchor(1))^2 +            ...  %
              (rhoI(i,2)-anchor(2))^2);                 %
    if dist>RCBwidth/2,                                 % if gone far enough, make RCB
      %for k=1:4
        j=j+1;
        RCB(j).C=rhoI(i,1:2);                           % center of the basis
        RCB(j).B=[0 1; -1 0];                           % init CURL ONLY
        %RCB(j).B=[0 0; 0 0]; RCB(j).B(k)=1;            % init: set each one to 1
        RCB(j).K=k.*eye(2);                             % uniform gaussian width    
        anchor=rhoI(i,1:2);                             % init distance and start index
      %end
    end                                                 % END if dist          
  end                                                   % END for i
  %for k=1:4                                             % extra one at end
  if 0
    j=j+1;                                              % 
    RCB(j).C=rhoI(i,1:2);                               % center of the basis
    %RCB(j).B=[0 0; 0 0];                                % init
    %RCB(j).B(k)=1;                                      % set one to 1
    RCB(j).B=[0 1; -1 0];                                % init
    RCB(j).K=k.*eye(2);                                 % uniform gaussian width   
  end
  %end
