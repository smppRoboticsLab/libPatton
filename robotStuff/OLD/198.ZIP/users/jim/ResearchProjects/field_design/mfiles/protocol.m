%______*** MATLAB "M" script (jim Patton) ***_______
% SETUP protocol specific stuff: __
% VERSIONS:	  INITIATED 11/29/00 jim patton, spawned from set_params
%__________________________ BEGIN: ____________________________

fprintf(' ~ protocol.m script ~ ')

Xshoulder2motor=find1TXTvalue(          ... %
 'parameters.txt','Xshoulder2motor=',0);    %
if isempty(Xshoulder2motor)                 %
  fprintf(' param not found! Use default: ')%
  Xshoulder2motor=0                         %
end                                         %
Yshoulder2motor=find1TXTvalue(          ... %
 'parameters.txt','Yshoulder2motor=',0);    %
if isempty(Yshoulder2motor)                 %
  fprintf(' param not found! Use default: ')%
  Yshoulder2motor=.85                       %
end                                         %

startRobot=[0 .45];                           % in robot coords
startPt=[-Xshoulder2motor Yshoulder2motor]... % convert
       -startRobot;
%startTrial=29;                               % never look at less
%Dirs=[45 135 225 315];                       %
Dirs=30:60:360;                               % setup mvmt diretions
Dirs=270;
Dirs=[0 180];                                 % 2 dirs
Dirs=0:360/3:360-.000001;                     % 3 directions
Dirs=0:90:360-.000001;                        % 4 ordinal dirs
Dirs=45:90:360;                               % 4 dirs                       
Dirs=0:360/8:360-.000001;                     % 8 dirs
Dirs=180+[45 135];
Dirs=270;

nDirs=length(Dirs);                           % number of Dirs

Mag=.10;                                      % distance of each mvmt
deflection=.3*Mag;                            % desired deviation from straight line
maxTime=.2;                                   % final time for all fiting analyses
fitIt=1;                                      % init flag for fit
wd=parse(cd,'\'); wd=wd(size(wd,1),:);        % working directory
CCB=[];                                       % initialize to nothing
CCwings.impedanceSpread=.3;                   % fractional +/- amount 
CCwings.massSpread=.1;                        % fractional +/- amount 
CCwings.geometrySpread=.025;                  % absolute +/- amount 
CCwings.shoulderSpread=.02;                   % absolute +/- amount 
spreadScale=1;                                % for scaling the above

fprintf(' ~ END protocol.m~ \n')