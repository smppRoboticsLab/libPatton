%************** MATLAB "M" function  *************
% analyze data, part 4: ensemble average plots
% SYNTAX:      
% REVISIONS:  2/8/2000  (patton) INITIATED
%             9-1-0 RENAMED analysis1.m from fastLearnCurves.m (patton)
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function analysis4()

% ____ SETUP ____
prog_name='analysis4.m';                                % name of this program
fprintf('\n~ %s ~ ', prog_name);                        % MSG
set_params;                                             %
verbose=1; plotIt=1; printIt=1;                         % switches for display
fsz=8;                                                  % font size
mkrSz=2;                                                % marker size
baseDir=cd;
Dname=['sin-morphed.txd'];                              %

%__setup figure__
for i=1:2
  figure(i);clf; put_fig(i,(i-1)*.4,.5,.37,.45);       % window
end

% __ LOAD PRELIM___
fprintf('\nLoading data..')
[EMh,EM]=hdrload('performMeas.txd');                      % LOAD MEASURES
colLabels=EMh(size(EMh,1),:);                             % GET MEAURE NAMES
colNames=parse(colLabels);                                % GET MEAURE NAMES
[Ntrials,Nmeas]=size(EM);                                 % dimensions
measureNames=colNames(3:Nmeas,:)  
Nmeas=Nmeas-2;                                            % DONT COUNT 1st 2COLs
measIndexes=3:Nmeas+2;                                      % index to "measure" cols
fprintf('.DONE. %d measures, %d trials. ',Nmeas,Ntrials); % display
nParts=findInTxt('performMeas.txd','Number of Parts=')
if isempty(nParts); nParts=1; end

% ____ LOOP for EACH part ____
for part=1:nParts,
  fprintf('\n\npart %d:\n~~~~~~',part); 
  
    %__ load TARGETS __ 
  filename=['targ_p' num2str(part) '.txd']; 
  if(~exist(filename)) fprintf('\nNo more parts\n');break;end % stop if no more parts
  fprintf('\n\nPart %d Trials:\n~~~~~~\n',part);              % 
  [trialHeader,trialData]=hdrload(filename);                  % targets & trial info
  nPhases=find1TXTvalue(filename,'Number of Phases=','s');
  Dirs=sort(distill(trialData(:,7))'); nDirs=length(Dirs);    % 
  Mag=mean(trialData(:,8));                                   % magnitude o ea.movement
  deflection=.3*Mag;                                          % desired traj deviation
  filename=['trialsStruct_p' num2str(part) '.mat'];
  if(~exist(filename)) fprintf('\nNo more parts\n');break;end % stop if no more parts
  load(filename);                     %
  for phase=1:length(trialsStruct)
    h=str2mat(h,['Part ' num2str(part) ', phase '         ...
     num2str(phase) ': ' deblank(trialsStruct(phase).name)]);
  end
  load(['trialsStruct_p' num2str(part)]); 
  
  % ____ LOOP for EACH part & TRIAL  ____
  for phase=1:length(trialsStruct)
    fprintf('\n\n\n___\n Phase %d ("%s"): ',phase,        ...
      trialsStruct(phase).name); 
    clf; drawnow
    
    % ___ loop for each dir ___
    for Dir=1:nDirs,                                            % determine direction
      fprintf('\n  Direction %d: ',Dirs(Dir)); 
      
      % determine sub-list of trials that match Dir and phase
      trials=[]; starts=[];                                     % init
      for i=1:length(trialsStruct(phase).trials)
        trial=trialsStruct(phase).trials(i);
        if trialData(trial,7)==Dirs(Dir),                       % if match direction
          trials=[trials trial];                                % stack onto list
          startTarg=[-Xshoulder2motor Yshoulder2motor]      ... % convert to subject coords
                    -trialData(trial,2:3);
          starts=[starts; startTarg];
        end
      end % END for i        
      fprintf('\n    Trials:'); fprintf(' %d',trials);
      Ename=[trialsStruct(phase).name  '.'                  ... % ouput filename
             num2str(Dirs(Dir)) '.ensemble.dat'];               %
      ensembleTrials3(trials,part,starts,Ename              ... % perform ensemble
                      ,0,plotit,verbose,~printIt);              % replace 0 with .95
      
      % __load desired __
      fprintf('\n    %s for %d deg.. ',Dname,Dirs(Dir));        %
      D=getIdealTrajectory(Dname,L                          ... % load & transform
       ,[0,0],Dirs(Dir)*pi/180-pi,Mag,deflection          ... % 
       ,speedThresh,0);                                         %
      plot(D(:,2),D(:,3),'r.')                                  % 
      fprintf('Done. \n');                                      %

    end % END for Dir

    % ___ finalize and print ___
    suptitle(str2mat('Ensemble trials for',                 ...
      trialsStruct(phase).name ,cd));
    if part==1 & phase==1,
      cmd=['print -dpsc2 ' baseDir '\ensembles.ps']; 
    else
      cmd=['print -dpsc2 -append ' baseDir '\ensembles.ps']; 
    end
    disp(cmd); eval(cmd)
    
  end % END for phase

  fprintf('\nDONE with trials for part %d. ',part); 
  if part==1 & exist('part2')                       % for backwards compatibility
      cd part2; cd;
      [trialHeader,trialData]=hdrload('targ.txd');  % load targets & trial info
      load trialsStruct                             % load trial categoriesw
      wd=parse(cd,'\'); wd=wd(size(wd,1),:);        % working directory
  end                              
  if part==2 & strcmp(wd,'part2'); 
    cd ..
  end                                               % change to new directory
end % END for part

fprintf('\n~ END %s ~ ', prog_name); 
return
