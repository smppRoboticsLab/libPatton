%************** MATLAB "M" function  *************
% Analyze data: ensemble average plots
% SYNTAX:     doEnsembles(CI)
% REVISIONS:  2/8/2000  (patton) INITIATED
%             9-1-0 RENAMED analysis4.m from fastLearnCurves.m (patton)
%             10/25/00 RENAMED doEnsembles.m
%             4-2-01 UPGRADED doEnsembles2.m
%             6-17-01 allowed what2do input that specifies which phases to plot
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function doEnsembles2(CI,deflection,what2do,plotDims,plotAxes)

% ____ SETUP ____
prog_name='doEnsembles.m';                                    % name of this program
fprintf('\n~ %s ~ ', prog_name);                              % MSG
if ~exist('CI'), CI=0, end                                    % if not passed
if ~exist('deflection'),                                      % if not passed
  deflection=findInTxt('parameters.txt',                  ... % desired bend in trajectory
            'trajectory deflection=')                         % 
  if isempty(deflection), deflection=0; end                   %
end                    
set_params;                            %
if ~exist('what2do'), what2do=[]; totalNplots=8; end          % if not passed
verbose=1; plotIt=1; printIt=1;                               % switches for display
fsz=8;                                                        % font size
mkrSz=2;                                                      % marker size
baseDir=cd;
Dname=['desired.txd'];                                        %
part=0;                                                       % init
PC=0;                                                         % init plotCount
gray=.7*ones(1,3);                                            % rgb triple for plots
firstTimeThru=1;                                              %
wd=parse(pwd,'\'); wd=deTabBlank(wd(size(wd,1),:));              % get name of directory

%__setup figure__
for i=1:-1:1
  figure(i);clf; 
  put_fig(i,(i-1)*.4+.1,.1,.75,.65);           
  orient landscape
end

% ____ find number of plots - LOOP for EACH part ____ 
if ~exist('plotDims')|isempty(plotDims),
  totalNplots=0;                                              % 
  fprintf('\n Finding # of plots.'); 
  part=0;
  while(1)
    fprintf('.'); 
    part=part+1;  
    filename=['targ_p' num2str(part) '.txd']; 
    if(~exist(filename))break; end                            % stop if no more parts
    phasesOinterest=findInTxt(filename,'phases of interest=');% load phases to do work on
    if isempty(phasesOinterest),                              % if nothing there
      totalNplots=8;                                         % 
      plotDims=[2,ceil(totalNplots/2)];                       % rows cols of plot window
      break
    else
      totalNplots=totalNplots+length(phasesOinterest);
      plotDims=[2,ceil(totalNplots/2)];                       % rows cols of plot window
    end 
  end % END while
end % END if isempty

% ____ LOOP for EACH part ____ 
fprintf('\nDoing ensembles:'); 
part=0;
while(1)
  part=part+1;
  fprintf('\n\npart %d:\n~~~~~~',part); 
  
  %__ load TARGETS __ 
  filename=['targ_p' num2str(part) '.txd']; 
  if(~exist(filename))                                        % stop if no more parts
    fprintf('\nCannot find %s. -No more parts\n',filename);
    break;
  end 
  fprintf('\n\nPart %d Trials:\n~~~~~~\n',part);              % 
  [trialHeader,trialData]=hdrload(filename);                  % targets & trial info
  nPhases=find1TXTvalue(filename,'Number of Phases=','s');
  Dirs=sort(distill(trialData(:,7))'); nDirs=length(Dirs);    % 
  Mag=mean(trialData(:,8));                                   % magnitude o ea.movement
  if isempty(what2do)
    phasesOinterest=findInTxt(filename,'phases of interest=') % load phases to do work on
    if isempty(phasesOinterest),                              % if nothing there
      phasesOinterest=('enter phasesOinterest: ');            % user input
    end 
  end
  goodTrials=textract(filename,'Good trial');                 % load column of data
  if goodTrials(1,1)==-8888,                                  % if not there
    goodTrials=ones(size(trialData,1),1);                     % make a column of all good
  end
    
  %__ load trialsStruct __ 
  filename=['trialsStruct_p' num2str(part) '.mat'];
  if(~exist(filename))                                        % stop if no more parts
    fprintf('\nCannot find %s. -No more parts\n',filename);
    break;                                                    % break out of while loop
  end 
  load(filename);                                             % load it

  % ____ LOOP for EACH part & TRIAL  ____
  for phase=1:length(trialsStruct)
    fprintf('\n\n\n___\n Phase %d ("%s" for %s): ',phase,        ...
      deTabBlank(trialsStruct(phase).name), cd); 
    drawnow
    
    if ~isempty(what2do)                                      % if there what2do was passed
      phasesOinterest=what2do(part).phases;                   % unpack
    end
        
    if(sum(phase==phasesOinterest))                           % if phase is on list
      PC=PC+1;                                                % increase plotCount
      subplot(plotDims(1),plotDims(2),PC)          
      
      % ___ loop for each dir ___
      for Dir=1:nDirs,                                        % determine direction
        fprintf('\n  Direction %d: ',Dirs(Dir)); 
      
        % determine sub-list of trials that match Dir and phase
        trials=[]; starts=[];                                 % init
        for i=1:length(trialsStruct(phase).trials)
          trial=trialsStruct(phase).trials(i);
          if trialData(trial,7)==Dirs(Dir),                   % if match direction
            trials=[trials trial];                            % stack onto list
            startTarg=[-Xshoulder2motor Yshoulder2motor]  ... % convert to subject coords
                      -trialData(trial,2:3);
            starts=[starts; startTarg];
          end
        end % END for i        
        
        if ~isempty(trials)                                   % skip if no trials 
          fprintf('\n                            Trials:'); 
          fprintf(' %d',trials);
          i=1;
          while(i<length(trials))
            if ~goodTrials(trials(i)), trials(i)=[]; end      % if not good, CLIP IT
            i=i+1;
          end
          fprintf('\n    Trials after clipping bad ones:'); 
          fprintf(' %d',trials);
          Ename=[trialsStruct(phase).name  '.'            ... % ouput filename
               num2str(Dirs(Dir)) '.ensemble.dat'];           %
          Ename=strrep(Ename,' ','_');
          title([char(64+PC) '. '                         ... % number the plot windows 
            str2mat(trialsStruct(phase).name)],           ...
            'fontsize',fsz-2)
          ensembleTrials3(trials,part,starts,Ename        ... % perform ensemble******
            ,CI,plotit,verbose,~printIt);                     % 
          axis off;
          
          % __load refernce (desired) __
          if exist(Dname)
            %fprintf('\n LOAD REFERENCE: %s for %d deg..',... %
            %  filename,Dirs(Dir));                           %      
            D=getIdealTrajectory(Dname,L                  ... % load & transform
            ,[0,0],Dirs(Dir)*pi/180-pi,Mag,deflection     ... % 
            ,speedThresh,0);                                  %
            D(:,1)=[];
            %fprintf('Done. \n');                             %
          else 
            filename=['Unperturbed baseline.'             ... % 
                num2str(Dirs(Dir)) '.ensemble.dat']; 
              filename=strrep(filename,' ','_');
            %fprintf('\n LOAD REFERENCE: %s for %d deg..', ...
            %  filename,Dirs(Dir));                           %      
            if exist(filename)
              D=loadRobotData(filename,cutoff,0);             % load & transform to subj c.s.
            else 
              fprintf(' \7 Cannot find %s! ',filename)          
              D=[];
            end  
          end % end if exist Dname
          if ~isempty(D),                                     % if no reference
            %plot(D(:,1),D(:,2),'r:','linewidth',3);          % plot reference
            plot(D(:,1),D(:,2),'r.','markersize',4);          % plot reference
          end                                                 % end if ~isempty(D)
          drawnow; pause(.00001)                              % 
        else
          fprintf(' - no trials for this direction. \n')
        end % END if ~isempty(trials)
      end % END for Dir (directions)
  
      % ___ finalize and print ___
      %suptitle(('Ensemble trials for',                 ...
      %  trialsStruct(phase).name ,cd));
      %title(str2mat(trialsStruct(phase).name))
      %if firstTimeThru,
      %  cmd=['print -dpsc2 ' baseDir '\ensembles.ps']; 
      %  firstTimeThru=0;
      %else
      %  cmd=['print -dpsc2 -append ' baseDir '\ensembles.ps'];  
      %end
      
      if exist('plotAxes'), axis(plotAxes); end
   else
     fprintf(' (skipping) ')    
   end % END if doEnsemble
    
  end % END for phase

  fprintf('\nDONE with trials for part %d. ',part); 
  if part==1 & exist('part2')                                 % for backwards compatibility
      cd part2; cd;
      [trialHeader,trialData]=hdrload('targ.txd');            % load targets & trial info
      load trialsStruct                                       % load trial categoriesw
  end                              
end % END for part

cd(baseDir); cd
hdl=textonplot(['(Subject ' wd ')'],.93,.07); 
set(hdl,'fontsize',fsz-2);
cmd=['print -depsc2 ensembles']; 
disp(cmd); eval(cmd)

hgsave(gcf,'ensembles');                                      % save figure in matlab fig file

fprintf('\n~ END %s ~ ', prog_name); 
return
