% ************** MATLAB "M" script (jim Patton) *************
% create robot control babis from data using copycat, & save.
% SYNTAX:    makeField(baseList,trialList,plotit,verbose)
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  11/2/99  pulled from pilot12 to main mfiles Dirsect.
%                     Changed from make_filed to makeField.m
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~


% __ SETUP __
global DEBUGIT M L R g EPpas Kpas Bpas 
global RCB rc
if ~exist('plotit'), plotit=1; end                    % if not passed
diary makeField.log                                   % keep record of this
fprintf('\n ~ makeField.m script: ~ \n')              % message
set_params                                            % setup most values 
[trialHeader,trialData]=hdrload('targ.txd');          % load targets & trial info
load trialsStruct                                     % load trial categories
startTrial=min(trialsStruct(1).trials);               % first for analysis

% __ PLOT part 1 trials__                             
if ~exist('trajectories.ps'),
  figure(1); plot_trials4([],0)
end

% __ Ensemble Average some baseline trials __
fprintf('\nBaseline Ensembles:');
clf
baseList=[]; % init
for D=1:nDirs
  fprintf(['\nFor the %d degree Dirsection '      ...
    'in robot coordinates:'],Dirs(D));
  outName=['baseline' num2str(Dirs(D)) '.dat']; 
  if ~exist('baseList.txd'),
    dirCount=0;
    for i=startTrial:max(trialsStruct(1).trials),   
      if trialData(i,7)==Dirs(D); 
        dirCount=dirCount+1;
        baseList(D,dirCount)=trialData(i,1); 
      end     % add trial to list
    end % for i
    baseList(D,:)
    ensembleTrials(baseList(D,:),outName); 
  else
    fprintf('\n (Ensemble "%s" already done)',outName)
    load 'baseList.txd'
  end % END if ~exist
  %disp(' pausing ..');   pause
end % END for D  
hdr=str2mat('% list of baseline trials.',         ... %
            '% Each column is a direction');      ... %
mat2txt('baseList.txd',hdr,baseList);
fprintf(' Ensebles DONE (see "baseList.txd"). ') 
baseList
load trialsStruct

NperturbTrials=length(trialsStruct(2).trials);
halfPt=ceil(NperturbTrials/2);                        % find half of the trials
perturbTrials=trialsStruct(2).trials(1:halfPt);
fprintf('\n Perturbation trials: '); 
fprintf(' %d',trialsStruct(2).trials);fprintf('\n')
fprintf('\n Perturbation trials actually used: '); 
fprintf(' %d',perturbTrials);fprintf('\n')

% ___ FIT COPYCAT ___
fprintf('\n ___ COPYCAT: ___: '); 
setupCopycat;                                         % assigns copycat bases
[cc,ccr]=ccFit5(CCB,maxTime,perturbTrials);           % fit copycat model 

% __ RC FIELD DESIGN __
fprintf('\n ___ REGIONAL CONTROL BASES: ___: '); 
widths=[]; centers=[];                                % init
if 1,
  for i=1:nDirs
    widths(i)=1.3*Mag;
    centers(i,:)=startPt+0.3*Mag*[cos(Dirs(i)/180*pi)...
                                sin(Dirs(i)/180*pi)];
  end
  widths(i+1)=1.8*Mag; centers(i+1,:)=startPt;
  setupRCB(widths,centers);                           %
else
  setupRCB(1.9*Mag,startPt)
end
[rc,rcr]=rcFit6(cc,CCB,maxTime,startPt,Dirs,Mag,deflection);
saveRCB
save RCB RCB

fprintf('\n ~ END makeField.m ~ \n');                 %  
diary off                                             % 
playwav('done.wav');                        % play sound      
return

