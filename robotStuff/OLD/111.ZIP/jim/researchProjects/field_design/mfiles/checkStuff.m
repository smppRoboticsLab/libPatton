  %_____________CHECK STUFF_____________
  %FC_m=FCfb_m+FCff_m;
  for i=1:length(t1)
    J=jacobian(posvelacc(i,1:2),L);           % find jacobian
    field_torque(i,1:2)=(J'*(force(i,1:2))')';
  end
 
  figure(2); clf
  %subplot(2,1,1);
  legend(plot(t1,D(:,1)-C(:,1),'r',       ...
              t1,field_torque(:,1),'r.',  ...
              t1,D(:,2)-C(:,2),'g',       ...
              t1,field_torque(:,2),'g.'), ...
    'D1','Dm1','D2','Dm2','C','Cm',0);
  title ('D');
