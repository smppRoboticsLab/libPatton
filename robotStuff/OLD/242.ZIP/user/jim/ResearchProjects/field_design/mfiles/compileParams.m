%****************** MATLAB "M" function  ****************
% compile a list of stuff in a big table from paramter files.
% rules:      *  All lines have a variablename, then an equals sign then stuff
%             *  remark lines have an "_" or "%" as first char
% SYNTAX:     compileParams(?)
% REVISIONS:  17-May-2001 (patton) INITIATED
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~~~

function compileParams(prefix,subjNums)

% ____ SETUP ____
prog_name='compileParams.m';                              % name of this program
fprintf('\n~ %s ~ ', prog_name);                          % MSG
if ~exist('prefix'),                                      %
  prefix=input(                                       ... % 
   'File prefix (e.g., "IFD"): ');                        % 
end                                                       % if not passed
if ~exist('subjNums'),                                    %
  subjNums=input(                                     ... % 
   'subject Numbers (e.g., 1:20): ');                     % 
end                                                       % if not passed

%__ Get list of things: __
fprintf('\nLOAD LIST OF VARS ... \n');                      % MSG
cmd=(['cd ' prefix num2str(max(subjNums))]);
disp(cmd);eval(cmd)                                       % change to directory
h=hdrload('parameters.txt');[rows,cols]=size(h);          % load file 2 string array
varList=[]; % init
for i=1:rows;                                             %
  if(h(i,1)~='_' & h(i,1)~='%' & h(i,1)~='_');            % 
    for j=1:cols,
      if (h(i,j)=='='), 
        varList=str2mat(varList,deblank(h(i,1:j-1)));   
        break
      end 
    end  
  end
end
varList(1,:)=[] % clip 1st row
Nvars=size(varList,1);
cd ..

%__  __
fprintf('\n\nFINDING DATA FOR LIST ... ');                % MSG
for subj=subjNums,                                        % subj loop
  subjCount=subjCount+1;                                  %
  cmd=(['cd ' prefix num2str(subj)]);disp(cmd);eval(cmd)  % change to directory
  fprintf('\nSubj %d Loading data..',subj)                % 
  for i=1:Nvars
    D=findInTxt('paramters.txt',                      ... %
      [deblank(varList(i,:)) '='],'s')
  end
  
end % END for subj

fprintf('\n~ END %s ~ ', prog_name); 

