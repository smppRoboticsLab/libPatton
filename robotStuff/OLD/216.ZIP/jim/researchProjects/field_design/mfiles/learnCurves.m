%************** MATLAB "M" function  *************
% analyze data: learning curves
% SYNTAX:       learnCurves.m(plotIt)
% REVISIONS:    9-1-00 INITIATED from fastLearnCurves (patton) 
%               10-25-00 renamed learnCurves.m from analysis2.m
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function learnCurves(plotIt)

% __SETUP__
prog_name='learnCurves.m';                                  % name of this program
fprintf('\n~ %s ~ ', prog_name); 
if ~exist('plotIt'), plotIt=1; end                        % if not passed
set_params;                                               % set plethora o params
oldPart=-9999;                                            % init
fsz=8;                                                  % font size
mkrSz=2;                                                % marker size
colors='mcrgbymcrgbymcrgbymcrgbymcrgbymcrgbymcrgby';
for i=1:2%Nmeas+1
  figure(i);clf; put_fig(i,(i-1)*.25,.25,.27,.67);         % setup figure windows
end

% __LOAD__
fprintf('\nLoading data..')
[EMh,EM]=hdrload('performMeas.txd');                      % LOAD MEASURES
colLabels=EMh(size(EMh,1),:);                             % GET MEAURE NAMES
colNames=parse(colLabels);                                % GET MEAURE NAMES
[Ntrials,Nmeas]=size(EM);                                 % dimensions
measureNames=colNames(3:Nmeas,:)  
Nmeas=Nmeas-2;                                            % DONT COUNT 1st 2COLs
fprintf('.DONE. %d measures, %d trials. ',Nmeas,Ntrials); % display
nParts=findInTxt('performMeas.txd','Number of Parts=');
if isempty(nParts); nParts=1; end


%___LOOP FOR TRIALS___
for cumTrial=1:Ntrials,
  trial=EM(cumTrial,1);
  part=EM(cumTrial,2);
  
  % load a trailsruct if part is new
  if part~=oldPart, 
    load(['trialsStruct_p' num2str(part)]); 
    for i=1:length(trialsStruct)                          % loop for exp part
      fprintf('\nPart %d phase %d= %s, trials:', ...
        part,i,trialsStruct(i).name);
      fprintf(' %d',trialsStruct(i).trials);
    end
    oldPart=part;
  end
      
  % ___ PLOT MEASURES ON LEARN CURVES___
  for meas=1:Nmeas,
    mkr='ko';                                             % init
    FC=[.8 .8 .8];                                        % for MarkerFaceColor
    EC=[1 1 1];                                           % for MarkerEdgeColor
    EC='none';                                            % for MarkerEdgeColor
    mkrSz=2;                                              % marker size
    if 1,
    for i=1:length(trialsStruct)                          % loop for exp part
      for j=1:length(trialsStruct(i).trials)              % loop for trials in part list 
        if trial==trialsStruct(i).trials(j),  
          %fprintf('found phase %d trial %d.\n ',i,trial);
          mkr=[colors(i) 'o']; %mkrSz=1;                   % marker size
          FC=colors(i);        % for MarkerFaceColor
          mkrSz=2;                                                % marker size
          break
        end
      end % END for j
    end % END for i
    end
    %figure(meas+1); 
    figure(2); 
    %subplot(3,ceil(Nmeas/3),meas)
    subplot(Nmeas,1,meas)
    plot(cumTrial,EM(cumTrial,meas+2),'o',...
        'markersize',mkrSz,...
        'MarkerFaceColor',FC,...
        'MarkerEdgeColor',EC);
    if trial==1, 
      hold on; set(gca,'fontsize',fsz); 
      title(deblank(measureNames(meas,:)));
    end
  end % END for meas
  if trial/25==round(trial/25),drawnow;pause(.001);end    % update display every 10
    
end % END for trial
xlabel('Trial','fontsize',fsz);


% ____ finalize plot ____
fprintf('\nFinalizing plot & printing to a file..'); 
subplot(3,ceil(Nmeas/3),1);
ax=axis; 
for part=1:nParts
  lgndX=((part-1)/nParts+.1)*(ax(2)-ax(1));
  load(['trialsStruct_p' num2str(part)]); 
  for i=1:length(trialsStruct)                              % loop for exp part
    mkr=[colors(i) 'o']; 
    FC=colors(i);        % for MarkerFaceColor
    EC='none';           % for MarkerEdgeColor
    lgndY=ax(3)+.98*(ax(4)-ax(3))-.05*i*(ax(4)-ax(3));
    plot(lgndX,lgndY,'o','markersize',mkrSz,...
        'MarkerFaceColor',FC,'MarkerEdgeColor',EC);
      text(lgndX,lgndY,['  ' trialsStruct(i).name],'fontsize',fsz);
    end
end % END for i
drawnow; pause(.001);
suptitle(['Learning curves for ' cd]);

fprintf('\nFinalizing plot & printing to a file..'); 
print -depsc2 learnCurves



fprintf('DONE.'); 
fprintf('\n~ END %s ~ \n\n', prog_name); 

