% ******************* MATLAB "M" file  (jim Patton) ******************
% evaluate multi-variate gaussian gradient
%  SYNTAX:	
%  INPUTS:      x         vector of current position 
%               width99   width of gaussian at 1% of magnitude
%  OUTPUTS:     z 	      gradient vector
%  REVISIONS:   INITIATED 9/12/99 patton. 		
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~

function z=mv_gaussian_grad(x,xo,width99);

%______ SETUP ______
global DEBUGIT                                  % nonzero for debuggging
if DEBUGIT,                                     % message if DEBUGIT~=0
  fprintf('\n ~ mv_gaussian_grad.m ~ '); 
end;	
gsf=4.2919;                                     % factor that makes a 
                                                % gaussian have a width 
                                                % of 1 at 1% of the 
                                                % total magnitude.
[rows,cols]=size(x);if rows==1;x=x';xo=xo';end; % transpose if row vect

k=2*(gsf/width99)^2;                            % constant on diagonal
K=k.*eye(length(x));
epsilon=x-xo;
z=-K*epsilon*exp(-.5*epsilon'*K*epsilon);

return

% test with this: 
% width99=1.3; xo=[0 0]; k=0; for i=-1:.075:1; for j=-1:.075:1; k=k+1; X(k)=i; Y(k)=j; z=mv_gaussian_grad([i j],xo,width99); U(k)=z(1); V(k)=z(2); end; end; figure(1); clf; quiver(X,Y,U,V); axis equal

