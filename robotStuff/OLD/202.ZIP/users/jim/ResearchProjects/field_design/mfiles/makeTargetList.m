%******************** MATLAB "M" fcn (Patton) *******************
% make trajectories for the robot
% VERSIONS:	  INITIATED 1-feb-2000 jim patton
%________________ BEGIN: ____________________

function makeTargetList(protocolNum,patternNum,outNum,N);

% ============ SETUP ============
figure(1);clf
prog_name='makeTargetList.m';                         % this program's name
fprintf('\n~ %s ~  ',prog_name)                       % orient user
protocols={...
    'Baseline then Intermittent pertubations'     ... %
   ,'RCB training and after effects'              ... %
   ,'Iterative Field design (IFD)'                ... % 
   ,'IFD design, training and after effects'      ... %
   ,'Baseline'                                    ... %
   ,'IFD design'                                  ... %
   };
patterns={...
    'Random Walk'         ...
   ,'Center-out'          ...
   ,'Grid'                ...
   };
 
% ____get protocol____
if ~exist('protocolNum')                              % 
  playwav('menu.wav');fprintf(' see menu..')          % 
  protocolNum=menu('Choose a protocol: ',         ... %
    protocols)                                        % 
else
  if(protocolNum>4|protocolNum<1), 
    error(' Input "protocolNum" is out of range ')
  end
end

% ____get pattern____
if ~exist('patternNum')
  playwav('menu.wav');fprintf(' see the menu..')
  patternNum=menu('Choose pattern:',patterns);        % choose experiment
else
  if(patternNum>2|patternNum<1), 
    error(' Input "patternNum" is out of range ')
  end
end

% ____get outNum ____ 
if ~exist('outNum')                                
  playwav('menu.wav');fprintf(' see the menu..')
  outNum=menu('Choose a output number: ',         ... % 
    '1','2','3','4','5','6','7','8','9')              %  
end

% ____get N ____ 
if ~exist('outNum')                                
  playwav('menu.wav');fprintf(' see the menu..')
  N=menu('Choose N (number of trials for stats): '... % 
    ,'1','2','3','4','5','6','7','8','9','10')        %  
end

protocol                                              % script to define params
C=startRobot;

% __ DISPLAY TASK __
fprintf('\nProtocol: %s',protocols{protocolNum}) 
fprintf('\nPattern: %s',patterns{patternNum}) 
fprintf('\nDirections: ');fprintf(' %d',Dirs) 

% ============ protocolNum: ============
switch protocolNum
 case 1
  phaseNum      =[1  1  1  1   2   2   2  ];
  fieldType     =[0  0  0  0  10  20  14  ];
  trialsPerDir  =[1  1  3  3   8   8   8  ]; 
  nFieldOnPerDir=[0  0  0  0   1   1   1  ]; 
 case 2
  phaseNum      =[1  1  1    2    2    2    3    3    3   4  5  6];
  fieldType     =[0  0  0  1000 1000 1000 1000  1000 1000 0  0  0];
  trialsPerDir  =[1  1  3    5   50    5    8    8    8   1  1  3]; 
  nFieldOnPerDir=[0  0  0    5   50    5    7    7    7   0  0  0]; 
case 3 % Iterative Field design (IFD)
  q=2000;  p=2001;
  phaseNum      =[1 1 1 1 2 2 2 2 2 2 2 2 2 2 3 4 4  4  4 5 5 5 5 5 6 7 8 9];
  fieldType     =[0 0 0 0 q q q q q q q q q q 0 p p  p  p p p p p p 0 0 0 0];
  trialsPerDir  =[1 1 1 N 8 8 8 8 8 8 8 8 8 8 N N 25 25 N 5 5 5 5 5 N N N N]; 
  nFieldOnPerDir=[0 0 0 0 2 2 2 2 2 2 2 2 2 2 0 N 25 25 N 4 4 4 4 4 0 0 0 0]; 
case 4 % baseline alone
  phaseNum      =[1 1 1 1 ];
  fieldType     =[0 0 0 0 ];
  trialsPerDir  =[1 5 1 N ]; 
  nFieldOnPerDir=[0 0 0 0 ]; 
case 5 % 
  q=2000;  p=2001;
  phaseNum      =[1 1 1 2 2 2 2 2 2 2 2 2 2 3 4 4  4  4 5 5 5 5 5 6 7 8 9];
  fieldType     =[0 0 0 q q q q q q q q q q 0 p p  p  p p p p p p 0 0 0 0];
  trialsPerDir  =[1 1 1 8 8 8 8 8 8 8 8 8 8 N N 25 25 N 5 5 5 5 5 N N N N]; 
  nFieldOnPerDir=[0 0 0 2 2 2 2 2 2 2 2 2 2 0 N 25 25 N 4 4 4 4 4 0 0 0 0]; 
 
end % END switch

% __ Generate trial orders __
fprintf('\n__Generate trial orders:__') 
OUT=[];
for exptSect=1:length(phaseNum),
  fprintf('\nSection %d...',exptSect) 
  nTrials=trialsPerDir(exptSect)*nDirs;
  switch patternNum,
   case 1 % ratandom walk 
    subplot(ceil(length(phaseNum)/2),2,exptSect)        %
    TARGS=randomWalk(trialsPerDir(exptSect)         ... %
       ,nFieldOnPerDir(exptSect),Dirs,              ... %
       Mag,C,fieldType(exptSect));                      %
     title(['Section ' num2str(exptSect) ' (Phase ' ...
            num2str(phaseNum(exptSect)) ')'])
   case 2 % center out 
    TARGS=centerOut(trialsPerDir(exptSect)          ... %
       ,nFieldOnPerDir(exptSect),Dirs,              ... %
       Mag,C,fieldType(exptSect));                      %
   otherwise
    error('Unknown patternNum.')
  end % END switch
  phaseNum(exptSect)*ones(nTrials,1);
  OUT=[OUT;                                         ... %
   TARGS phaseNum(exptSect)*ones(nTrials,1)];           % add targets&phase# to list 
end
OUT=[(1:size(OUT,1))' OUT];                             % insert trial # as column 1

% _find startTrial of each experimental phase_
counter=0; 
phase=min(OUT(:,9)); 
i=0; 
phaseStart(phase)=1;                                    % 
fprintf('\n Phase %d begins @ trial %d'             ... % estimate time 4 sec/trial  
      ,phase,phaseStart(phase));                
while i<size(OUT,1),                            
  i=i+1;                                       
  if OUT(i,9)==(phase+1),                               % find the start of phase
    phase=phase+1;                             
    phaseStart(phase)=i;                       
    fprintf('\n Phase %d begins @ trial %d'         ... % estimate time 4 sec/trial 
      ,phase,phaseStart(phase));                        %
  end                                                   %
end                                                     %

%_ assign trial information to trialsStruct _
switch protocolNum
 case 1 % protocolNum 1 *******************************
  trialsStruct(1).name='Unperturbed trials';  
  trialsStruct(1).trials=                           ... % List of baseline trials
    (phaseStart(2)-nDirs*3):(phaseStart(2)-1);
 
  trialsStruct(2).name='Perturbed trials';  
  trialsStruct(2).trials=[];
  for i=phaseStart(2):size(OUT,1),                      % list of perturbation trials
    if((OUT(i,6)>-50|OUT(i,6)<50)                   ... %
       &OUT(i,6)~=0) 
      trialsStruct(2).trials=                       ... % add trial to list 
        [trialsStruct(2).trials OUT(i,1)];              %        
    end    
  end % for i
 case 2 % protocolNum 2 *******************************
  trialsStruct(1).name='Unperturbed Trials';  
  trialsStruct(1).trials=                ... %
    (phaseStart(2)-nDirs*3):(phaseStart(2)-1);
  
  trialsStruct(2).name='Early Training Trials';  
  trialsStruct(2).trials=                 ... %
   phaseStart(2):(phaseStart(2)+nDirs*5-1);

  trialsStruct(3).name='Late Training Trials';  
  trialsStruct(3).trials=                 ... %
  (phaseStart(3)-nDirs*5):(phaseStart(3)-1);

  trialsStruct(4).name='After-Effect Catch Trials';  
  trialsStruct(4).trials=[];
  for i=phaseStart(3):(phaseStart(4)-1),                % list of perturbation trials
    if(OUT(i,6)==0)                                     % if catch trial
      trialsStruct(4).trials=                       ... % add trial to list 
        [trialsStruct(4).trials OUT(i,1)];            
    end    
  end % for i

  trialsStruct(5).name='Final washout trials';  
  trialsStruct(5).trials=                           ... %
   phaseStart(6):size(OUT,1);
 
 case 3 % iterative field design IFD *******************
  trialsStruct(1).name='First Unperturbed trials';  
  trialsStruct(1).trials=                           ... % List of baseline trials
    (phaseStart(2)-nDirs*N):(phaseStart(2)-1);
 
  trialsStruct(2).name='Perturbed trials';  
  trialsStruct(2).trials=[];
  for i=phaseStart(2):size(OUT,1),                      % list of perturbation trials
    if((OUT(i,6)>-50|OUT(i,6)<50)                   ... %
       &OUT(i,6)~=0) 
      trialsStruct(2).trials=                       ... % add trial to list 
        [trialsStruct(2).trials OUT(i,1)];            
    end    
  end % for i
  
  trialsStruct(3).name='Second Unperturbed trials';  
  trialsStruct(3).trials=                           ... % List of baseline trials
    phaseStart(3):(phaseStart(4)-1);
  
  trialsStruct(4).name='Early Training Trials';  
  trialsStruct(4).trials=                 ... %
   phaseStart(4):(phaseStart(4)+nDirs*N-1);

  trialsStruct(5).name='Late Training Trials';  
  trialsStruct(5).trials=                 ... %
  (phaseStart(5)-nDirs*N):(phaseStart(5)-1);

  trialsStruct(6).name='After-Effect Catch Trials';  
  trialsStruct(6).trials=[];
  for i=phaseStart(5):(phaseStart(6)-1),                % list of perturbation trials
    if(OUT(i,6)==0)                                     % if catch trial
      trialsStruct(6).trials=                       ... % add trial to list 
        [trialsStruct(6).trials OUT(i,1)];            
    end    
  end % for i

  trialsStruct(7).name='Washout trials set 1';  
  trialsStruct(7).trials=                           ... %
    phaseStart(6):phaseStart(7)-1;
  
  trialsStruct(8).name='Washout trials set 2';  
  trialsStruct(8).trials=                           ... %
    phaseStart(7):phaseStart(8)-1;
  
  trialsStruct(9).name='Washout trials set 3';  
  trialsStruct(9).trials=                           ... %
    phaseStart(8):phaseStart(9)-1;
  
  trialsStruct(10).name='Washout trials set 4';  
  trialsStruct(10).trials=                           ... %
    phaseStart(9):size(OUT,1);
  
 
end % END switch protocolNum
fprintf('\nDone.')

% __ display __
for i=1:length(trialsStruct),                           % loop to display
  fprintf('\n%d) %s:   ',                           ... %
          i,trialsStruct(i).name);
  fprintf(' %d',  trialsStruct(i).trials');
end
te=length(OUT(:,1))*4/60;                               % estimated time
if patternNum==2, eTime=eTime*2; end                    % allow for return to center
fprintf('\n\n%d trials. ',  size(OUT,1) )               %  
fprintf(' Est.time: %.1f min (%f hours).',te,te/60);    % estimate time 4 sec/trial 

% __ header___
h=str2mat('Trial Definitions (Patton)',             ... %
  sprintf('targets generated by %s on %s.'          ... % 
  ,prog_name,whenis(clock))                         ... %
  ,['Protocol: ' protocols{protocolNum} ]           ... %
  ,['Pattern: ' patterns{patternNum} ' ('           ... %
    num2str(nDirs) ' directions)']                  ... %
  ,['Directions=' sprintf(' %d',Dirs)]              ... % 
  ,'(this is viewed best in EXCEL)'                 ... %
  ,'__ BEGIN:__');                                      %
h=str2mat(h,sprintf(                                ... %
  '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t',           ... %
  'trialNumber','startX','startY','endX',           ... %
  'endY','fieldType','Dir(deg)',                    ... %
  'Magnitude','experimental_phase'));                   %

%__ STORE IN FILES ___
cmd=['save trialsStruct_p'   ...
    num2str(outNum) ' trialsStruct' ];
disp(cmd); eval(cmd); 
outName=['targ_p' num2str(outNum) '.txd'];
mat2txt(outName,h,OUT);
fprintf('\n TARGETS in: %s ',outName)                   % 

%__ print graphic if any ___
if patternNum==1, % random walk
  suptitle(str2mat(protocols{protocolNum},          ... %
    [patterns{patternNum} ', filename=' outName],   ... %
    ['Directions=' sprintf(' %d',Dirs)] ) );
  cmd=['print -depsc2 ' outName '.eps'];
  disp(cmd);
  eval(cmd);
end

fprintf('\n~ END %s ~ \n',prog_name)                    % 
return


%**************** MATLAB "M" fcn (Patton) ***************
% centerOut(): make list of trajectories, all origniating from center
%_________________ BEGIN: ___________________

function d=centerOut(trialsPerDir,nFieldOnPerDir,Dirs,Mag,C,fieldType)

% ============ SETUP ============
nDirs=length(Dirs);                           % number of Dirs
totalTrials=(trialsPerDir)*nDirs;             % calc total trials for this
junk=zeros(totalTrials,1);                    % initialize
ok=0;

% ============ RENDER ============ 
% __make a list of mvmts __
count=0;
for D=1:nDirs,
  for i=1:nFieldOnPerDir,                     % loop for field on
    count=count+1;      
    d(count,:)=[fieldType Dirs(D) Mag];
  end
  for i=1:(trialsPerDir-nFieldOnPerDir),      % loop for field off
    count=count+1;
    d(count,:)=[0 Dirs(D) Mag];
  end  
end                                           % END for D

% __randomly mix the list__
[junk,I]=sort(rand(count,1));                 % obtain a random order
d=d(I,:);                                     %

% __assure no 2 consecutive catch trials __
if nFieldOnPerDir~=0&trialsPerDir~=0,         % if catch trials
  d=notConsec(d,trialsPerDir,nFieldOnPerDir...% perform a re-ordering
    ,fieldType,count);
end

for i=1:count
  vect=[Mag*cos(d(i,2)*pi/180),        ...%
        Mag*sin(d(i,2)*pi/180)];
  startEnd(i,:)=[C C+vect];              %
end
d=[startEnd d];
return

%***************** MATLAB "M" fcn (Patton) ****************
% randomWalk(): make list of trajectories as a random walk 
%_________________ BEGIN: ___________________

function d=randomWalk(trialsPerDir,nFieldOnPerDir,Dirs,Mag,C,fieldType)

% ============ SETUP ============
nDirs=length(Dirs);                           % number of Dirs
totalTrials=(trialsPerDir)*nDirs;             % calc total trials for this
junk=zeros(totalTrials,1);                    % initialize
ok=0;
xL=.44;
yL=.4;
W.xLo=C(1)-.19; % do not go higher than .222
W.xHi=C(1)+.19; 
W.yLo=C(2)-.14;  % do not go higher than .165
W.yHi=C(2)+.14;
j=1;

% __make a list of mvmts __
count=0;
for D=1:nDirs,
  for i=1:nFieldOnPerDir,                               % loop for field on
    count=count+1;      
    d(count,:)=[fieldType Dirs(D) Mag];
  end
  for i=1:(trialsPerDir-nFieldOnPerDir),                % loop for field off
    count=count+1;
    d(count,:)=[0 Dirs(D) Mag];
  end  
end                                                     % END for D

% __randomly mix the list__
fprintf('\n Randomizing..')
[junk,I]=sort(rand(count,1));                           % obtain a random order
d=d(I,:);                                               %

if nFieldOnPerDir~=0&trialsPerDir~=0,                   % if catch trials, 
  d=notConsec(d,trialsPerDir,nFieldOnPerDir,fieldType,count); % disallow 2 consecutive
end                                                     % END if

% __initial plot __
plot([W.xLo W.xHi W.xHi W.xLo W.xLo],               ... % 
     [W.yLo W.yLo W.yHi W.yHi W.yLo],'g'); 
hold on;   
plot(C(1),C(2),'o','markersize',2)                      % 
[startEnd,cPt,notOK]=walk(C,d,Mag,W);                   % reevaluate it
h=plot([startEnd(1,1); startEnd(:,3)],              ... %
       [startEnd(1,2); startEnd(:,4)],'r');             %
hNi=text(W.xLo,W.yHi,'No adjustments necessary');
axis equal; drawnow; 
  
% ___ === ADJUST Random walk ==== ___
if notOK,
  fprintf('Adjusting random walk to fit window..')
end
iterationCount=0;
while(notOK)                                            % 
  iterationCount=iterationCount+1;                      %
  switch round(rand*3)
   case 1 % PUT bad guy AT THE END                      %
    q=d(cPt,:); d(cPt,:)=[]; d=[d;q];                   
   case 2, % put early bad mvmt at end
    for j=1:cPt-1,                                      % SEARCH FOR EARLY BAD MVMT
      switch notOK                                      % 
       case 1 % W.xLo                                   %
        if startEnd(j,3)<startEnd(j,1); k=j; break,end  % choose a bad guy
       case 2 % W.xHi   
        if startEnd(j,3)>startEnd(j,1); k=j; break,end  % choose a bad guy
       case 3 % W.yLo
        if startEnd(j,4)<startEnd(j,2); k=j; break,end  % choose a bad guy
       case 4 % W.yHi
        if startEnd(j,4)>startEnd(j,2); k=j; break,end  % choose a bad guy
      end % switch notOK
    end % for j
    q=d(k,:); d(k,:)=[]; d=[d;q];                       % PUT bad guy AT END
   case 3,  % PUT best LATE GOOD MVMT BEFORE BAD
    if cPt<count-4,
      bestPt=cPt+1;                                     % initi with current bad point
      bestDist2ctr=sqrt( (startEnd(cPt+1,3)-C(1))^2 +...% init with current dist
        (startEnd(cPt+1,4)-C(2))^2  );
      for j=cPt+2:count,                                % SEARCH: BEST LATE GOOD MVMT
        possible=startEnd(cPt-1,3:4)+               ... %
          Mag*[cos(d(j,2)/180*pi) sin(d(j,2)/180*pi)];  %
        PosDist2ctr=sqrt( (possible(1)-C(1))^2 +    ... % possible dist
                        (possible(2)-C(2))^2  );        %
        if PosDist2ctr<bestDist2ctr,                    %
          bestDist2ctr=PosDist2ctr; bestPt=j;           %
        end
      end % for j
      %bestPt,cPt
    else
      bestPt=cPt-1;                                     % initi with current bad point
      bestDist2ctr=sqrt((startEnd(cPt+1,3)-C(1))^2 +... % init with current dist
                       (startEnd(cPt+1,4)-C(2))^2  );   %
      for j=cPt-2:1,                                    % SEARCH: BEST LATE GOOD MVMT
        possible=startEnd(cPt-1,3:4)+               ... %
          Mag*[cos(d(j,2)/180*pi) sin(d(j,2)/180*pi)];  %
        PosDist2ctr=sqrt( (possible(1)-C(1))^2 +    ... % possible dist
                        (possible(2)-C(2))^2  );        %
        if PosDist2ctr<bestDist2ctr,                    %              
          bestDist2ctr=PosDist2ctr; bestPt=j; 
        end
      end % for j
      %bestPt,cPt
    end  
    d=swapRows(d,bestPt,cPt);
  end % ENS switch ..
  
  if nFieldOnPerDir~=0&trialsPerDir~=0,                 % if catch trials, 
    d=notConsec(d,trialsPerDir,nFieldOnPerDir,      ... % disallow 2 consecutive
      fieldType,count);                                 %
  end                                                   % END if
 
  % reevaluate & plot
  [startEnd,cPt,notOK]=walk(C,d,Mag,W);                 % evaluate start& endpoints
  set(h,'XData',[startEnd(1,1); startEnd(:,3)],     ... %
        'YData',[startEnd(1,2); startEnd(:,4)])         %
  set(hNi,'string',[num2str(iterationCount) 'iterations']);
  title([num2str(iterationCount) ' Iterations'])
  %zoom(.5); 
  axis equal; drawnow; 
  pause(.02)
  
end % while
%iterationCount
%disp('pause..');pause
d=[startEnd d];

return                                                  % END function makeSubList


%***************** MATLAB "M" fcn (Patton) ****************
% Walk(): calc & eval random walk 
%_________________ BEGIN: ___________________

function [startEnd,cPt,notOK]=walk(C,d,Mag,W)
notOK=0;
count=size(d,1);
startEnd(1,:)=[C                 ... % do row 1
 C+Mag*[cos(d(1,2)/180*pi) sin(d(1,2)/180*pi)] ];  %

% calc walk points
for i=2:count,                                % 
    startEnd(i,:)=[startEnd(i-1,3:4),       ... %
     startEnd(i-1,3:4)+                     ... %
     Mag*[cos(d(i,2)/180*pi) sin(d(i,2)/180*pi)]];%
end % for i 

% calc points and do 1 corrections
for i=2:count,                                %
  if(startEnd(i,3)<W.xLo) notOK=1; break, end   % 1st boundary cross
  if(startEnd(i,3)>W.xHi) notOK=2; break, end   % 
  if(startEnd(i,4)<W.yLo) notOK=3; break, end   %
  if(startEnd(i,4)>W.yHi) notOK=4; break, end   % 
end % for i 

cPt=i;

return

%***************** MATLAB "M" fcn (Patton) ****************
% notConsec(): adjust d so there are no 2 consecutive catch trials 
%_________________ BEGIN: ___________________ 

function d=notConsec(d,trialsPerDir,nFieldOnPerDir,fieldType,count) 

% __determine most common field type__
if nFieldOnPerDir>ceil(trialsPerDir/2),                   % if Aftereffect catch trials
      common=fieldType; notCommon=0; 
else  common=0;         notCommon=fieldType;
end

% always have 1st 2 be a non-catch 
for i=1:count
  if d(i,1)==common,q=d(i,:);d(i,:)=[];d=[q;d];break;end  % put it first and stop
end
for i=2:count
  if d(i,1)==common,q=d(i,:);d(i,:)=[];d=[q;d];break;end  % put it first and stop
end

% swap 1st of 2 consecutive catch trials with one above
ok=0; 
while(~ok)
  %fprintf('\n'), pause(.01);d
  ok=1;
  for i=3:count-1
    if (d(i,1)==notCommon&d(i+1,1)==notCommon),      % IF 2 IN A ROW
      q=d(i-1,:); d(i-1,:)=d(i,:); d(i,:)=q;         % swap with one above it
      ok=0;                                          % flag the problem
    end  % if
  end % for i 
  %d,  disp('...hit a key...'); pause
end % while
%disp('DONE! hit a key'); pause

return



