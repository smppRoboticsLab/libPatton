
% plots the forces in iterative field design
clf; 
i=0; 
filename='f0.txd'
while(exist(filename)) 
  [h,d]=hdrload(filename); 
  subplot(3,1,i+1); 
  plot(d,'.'); hold on;  plot(d);  grid on; 
  
  i=i+1;
  filename=['f' num2str(i) '.txd']
end

  orient tall; 
  print -depsc2 ifdforces
  
  