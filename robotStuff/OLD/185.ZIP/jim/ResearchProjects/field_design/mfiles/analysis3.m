%************** MATLAB "M" function  *************
% analyze data, part 3
% SYNTAX:      
% REVISIONS:    9-1-00 INITIATED from fastLearnCurves (patton) 
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function analysis3(plotIt)

% __SETUP__
prog_name='analysis3.m';                                  % name of this program
fprintf('\n\n\n~ %s ~ \n', prog_name);                    % message
if ~exist('plotIt'), plotIt=1; end                        % if not passed
set_params;                                               % set plethora o params
fsz=8; mkrSz=2;                                           % font & marker size
colors='mcrgby';
for i=1:2%Nmeas+1
  figure(i);clf; put_fig(i,(i-1)*.25,.25,.27,.67);        % setup figure windows
end
lastPart=0;                                               % last trial of prev. "part"

% __LOAD__
fprintf('\nLoading data..')
[EMh,EM]=hdrload('performMeas.txd');                      % LOAD MEASURES
colLabels=EMh(size(EMh,1),:);                             % GET MEAURE NAMES
colNames=parse(colLabels);                                % GET MEAURE NAMES
[Ntrials,Nmeas]=size(EM);                                 % dimensions
measureNames=colNames(3:Nmeas,:)  
Nmeas=Nmeas-2;                                            % DONT COUNT 1st 2COLs
measIndex=3:Nmeas+2;                                      % index to "measure" cols
fprintf('.DONE. %d measures, %d trials. ',Nmeas,Ntrials); % display
load trialsStruct

% ____ GROUP the DATA for Barcharts ____
fprintf('\nGrouping the data...'); 
barMeans=[]; barStd=[]; bar95Width=[]; phaseNames=[];     % init
for part=1:2
  load trialsStruct; %trialsStruct
  for phase=1:length(trialsStruct)
    fprintf('\n  Part %d Phase %d ..',part,phase);        % display
    measures=[]; 
    for i=1:length(trialsStruct(phase).trials)
      EMindex=trialsStruct(phase).trials(i)+lastPart;     % index to proper row#
      measures=[measures; EM(EMindex,measIndex)];
    end
    barMeans=[barMeans; mean(measures)];
    barStd=[barStd; std(measures)];
    bar95Width=[bar95Width; confidence(measures,.95)];
    phaseNames=str2mat(phaseNames,trialsStruct(phase).name);
  end % END for phase
  if part==1,
    cd part2;[junk,lastPart]=max(diff(EM(:,2))); % find when part1 ends
  end
end % END for part
phaseNames(1,:)=[];                                       % clip off blank line 
%barMeans,barStd,bar95Width,phaseNames 
fprintf('Done Grouping the data. \n'); 

% ____ make the Barcharts ____
fprintf('\nBarcharts..'); 
figure(1); clf;
C=colorcube(8); C=C(3:8,:); 
for meas=1:Nmeas,
  fprintf('\n Measure#%d: %s ',meas,measureNames(meas,:));  % 
  subplot(3,1,meas);
  multbar3(barMeans(:,meas)',[],C,phaseNames,...
           [],[],bar95Width(:,meas)',0,'barInside');
  title(measureNames(meas,:));
end % END for meas
orient tall
suptitle(str2mat('Experimental phase comparisons for:', cd)); 
drawnow; pause(.001);
print -dpsc2 barchart                     % print to a file

fprintf('DONE.'); 
fprintf('\n~ END %s ~ \n\n', prog_name); 

