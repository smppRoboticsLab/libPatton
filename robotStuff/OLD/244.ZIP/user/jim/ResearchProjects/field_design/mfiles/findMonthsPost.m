%************** MATLAB "M" fcn ************
% read paramters.txt and find months post stroke
% SYNTAX:      
% REVISIONS:  21-May-2001 (patton) INITIATED
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~

function MonthsPost=findMonthsPost()
fprintf('\n~ findMonthsPost.m function ~')

% __SETUP__
DV=datevec(now-datenum(findInTxt('parameters.txt','Pathology date=','s'))); 
MonthsPost=DV(1)*12+DV(2);