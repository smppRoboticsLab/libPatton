%___________________*** MATLAB "M" script (jim Patton) ***____________________
% Sets up parameters for the copycat basis functions for 2-joint link & controller:
%
%                                                     phi2  `
%            o==>F                                 o==>F   `
%             \                                     \     `                
%             (m2)                                  (m2) `                      
%               \  q2                                 \ `               
%                o ` ` ` ` `                          o     
%               /                                    /           
%             (m1)                                 (m1)    phi1        
%             / q1                                 / 
%          __o___` ` ` ` ` `                    __o___` ` ` ` ` `  
%          \\\\\\\                              \\\\\\\                 
%
% VERSIONS:	  
%__________________________________ BEGIN: ____________________________________

fprintf('\n ~ setupLocalField.m script ~ ')

% ___ SEUP RCB FIELDS ___
gsf=4.2919;                                 % makes gaussian have a width 1
                                            % at 1% of the total magnitude
RCBwidth=movmtDistance;                     % for single rcb 
k=(gsf/RCBwidth)^2;                         % for region of effectiveness
RCB(1).C=rhoD(1,2:3);                       % center of the basis
RCB(1).B=[0 1; -1 0];                       % init
RCB(1).K=k.*eye(2);                         % uniform gaussian width    

if 0
 k=(gsf/(1.33*RCBwidth))^2;                 % for region of effectiveness
 RCB(2).C=rhoD(1,2:3);                      % center of the basis
 RCB(2).B=[0 1; -1 0];                      % init
 RCB(2).K=k.*eye(2);                         % uniform gaussian width       

 k=(gsf/(.66*RCBwidth))^2;                         % for region of effectiveness
 RCB(3).C=rhoD(1,2:3);                       % center of the basis
 RCB(3).B=[0 1; -1 0];                       % init
 RCB(3).K=k.*eye(2);                         % uniform gaussian width    

 k=(gsf/(1.5*RCBwidth))^2;                         % for region of effectiveness
 RCB(4).C=rhoD(1,2:3);                       % center of the basis
 RCB(4).B=[0 1; -1 0];                       % init
 RCB(4).K=k.*eye(2);                         % uniform gaussian width    
end

fprintf(' ~ END setupLocalField.m script ~ \n')
