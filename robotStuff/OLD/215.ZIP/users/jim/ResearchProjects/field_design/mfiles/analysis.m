%************** MATLAB "M" script ************
% batch file to Analyze data
% SYNTAX:     analysis 
% REVISIONS:  10/25/00 (patton) INITIATED
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~

fprintf('\n~ Analysis.m (analysis batch file) ~')

% __SETUP__
confidenceInterval=.95;
doPlot=2; 
doPrint=1;
analysisFrames=20;

% __ANALYSIS__
plotIFDForces
doEnsembles(confidenceInterval);                  % ensemble avg's and plot
performMeas(doPlot,doPrint,analysisFrames);       % performance measures
learnCurves(doPlot);                              % learning curves 
stats(doPlot)                                     % statistical summary & plot

playwav('done.wav')
fprintf('\n~ END Analysis.m (analysis batch file) ~ \n')
