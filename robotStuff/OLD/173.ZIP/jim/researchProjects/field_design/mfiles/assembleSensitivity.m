% ************** MATLAB "M" script (jim Patton) *************
% put CC fit results together and plot.
% SYNTAX:   
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~

%___SETUP___
scriptName='assembleSensitivity.m';
analysisName='Sensitivity.m';
fprintf('\n*~ %s ~* \n', scriptName)
figure(1); clf; orient tall;
fsz=7; 
Colors=['brgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcy'];
numTimes=16;
counter=0;
D=[]; 
names=[ 'M11'             % see setupCopycat3.m
        'M12'
        'M21'
        'M22'
        'L1 '
        'L2 '
        'R1 '
        'R2 '
        'Bss'
        'Bee'
        'Bse'
        'Kss'
        'Kee'
        'Kse'
        'X  '
        'Y  '
      ]

% ____ SUBJ LOOP - LOAD AND ASSEMBLE DATA ____
for i=30:34, % subj loop
  eval(['cd pilot' num2str(i)]); 
  filename=['pilot' num2str(i) analysisName '.m.txd']
  [h,d]=hdrload(filename); len=size(d,1);
  varName=parse(h(size(h,1),:));
  D(:,:,i-29)=d;
  cd ..  
end % END for i

% ____ STATS ____
MeanD=mean(D,3);  MaxD=max(D,3);  MinD=min(D,3);
baseScores=D(1,:);
for i=1:38
  pctChange(i,:)=abs(MeanD(i,:)-baseScores)./baseScores;
end

% ____ CONDENSE____
condensed=[ mean([D(3:4,:)]) % M11
            mean([D(5:6,:)]) % M12
            mean([D(7:8,:)]) % M21
            mean([D(9:10,:)]) % M22
            mean([D(11:12,:)]) % L1
            mean([D(13:14,:)]) % L2
            mean([D(15:16,:)]) % R1
            mean([D(17:18,:)]) % Bss
            mean([D(19:20,:)]) % Bee
            mean([D(21:22,:)]) % Bse
            mean([D(23:24,:)]) % Kss
            mean([D(25:26,:)]) % Kee
            mean([D(27:28,:)]) % Kse
            mean([D(29:30,:)]) % X
            mean([D(31:32,:)]) % Y
          ]

% ____ SAVE DATA ____
H=str2mat('Compiled measures for',                  ... 
          analysisName,                             ... 
          ['Patton, ' whenis(clock)],               ... 
          sprintf('subj#\t%s',h(size(h,1),:)) ) ;   
mat2txt([analysisName '.txd'],H,condensed); 

% === PLOT ===
for J=5:6, % index to columns in datafile
  counter=counter+1;
  subplot(2,1,counter);
      [N,X]=hist(d(:,cols(j)));
end

suptitle([analysisName ' Fit vs. Amount of analysis time']) 
eval(['print -depsc2 ' analysisName '.ps']);


fprintf('\n ~ END %s ~ \n', scriptName)
