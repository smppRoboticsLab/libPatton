% ************** MATLAB "M" script (jim Patton) *************
% create robot control babis from data using copycat, & save.
% SYNTAX:    makeField(baseList,trialList,plotit,verbose)
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  11/2/99  pulled from pilot12 to main mfiles Dirsect.
%                     Changed from make_filed to makeField.m
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~


% __ SETUP __
if 0
  fprintf('\n\n\n   NOTE: Clearing memory!  \n\n\n')  % message
  pause(2); pause(1); clear ;
end
diary makeField.log                                   %  
global DEBUGIT M L R g EPpas Kpas Bpas 
global graphicsParams Gcounter
global field_gain field_type 
global RCB rc
if ~exist('plotit'), plotit=1; end                    % if not passed
fprintf('\n ~ makeField.m script: ~ \n')              % message
set_params                                            % setup most values 
setupCopycat                                          % setup copycat structure
maxTime=.13;                                          % 
figure(1);

% __ SETUP protocol specific: __
startRobot=[0 .45];                                   % in robot coords
startPt=[-Xshoulder2nose Yshoulder2motor]-startRobot  %
startTrial=29;                                        % never look at less
Dirs=[45 135 225 315];                                %
nDirs=length(Dirs);                                   % number of Dirss
Mag=.1;                                               % distance of each mvmt
deflection=.03;                                       % distance of each mvmt
setupRCB([Mag,.8*Mag,1.2*Mag ],[startPt;startPt;startPt]);

% __ find experimental phases __
[trialHeader,trialData]=hdrload('targ.txd'); 
for start1=startTrial:size(trialData,1),  
  if trialData(start1,9)==1, break; end               % find the start of phase 1
end
for start2=start1:size(trialData,1),  
  if trialData(start1,9)==2, break; end               % find the start of phase 2
end

% __ Ensemble Average some baseline trials __
fprintf('\nBaseline Ensembles:');
clf
for D=1:nDirs
  fprintf(['\nFor the %d degree Dirsection '      ...
    'in robot coordinates:'],Dirs(D));
  outName=['baseline' num2str(Dirs(D)) '.dat']; 
  if ~exist(outName),
    baseList=[]; % init
    for i=startTrial:start1,   
      if trialData(i,7)==Dirs(D); 
        baseList=[baseList trialData(i,1)]; 
      end     % add trial to list
    end % for i
    ensembleTrials(baseList,outName); 
  else
    fprintf('\n (Ensemble "%s" already done)',outName) 
  end % END if ~exist
  %disp(' pausing ..');   pause
end % END for D  
fprintf(' Ensebles DONE. ') 

% ___ Assemble List of perturbation trials ___
trialList=[];
for i=start1:start2,
  if trialData(i,6)==1; 
    trialList=[trialList trialData(i,1)];             % add trial to list
  end    
end % for i
fprintf('\n Perturbation trials: '); 
fprintf(' %d',trialList);

% ___ FIT COPYCAT ___
[cc,ccr]=ccFit5(CCB,maxTime,trialList);               % fit copycat model 
[max_cc,winner]=max(cc); 
cc=0*cc; cc(winner)=1;                                % winner-takes-all

% **** FIELD DESIGN **** 
[rc,rcr]=rcFit6(cc,CCB,maxTime,startPt,Dirs,Mag,deflection)
saveRCB;                                              % store in special text file

fprintf('\n ~ END makeField.m ~ \n');                 %  
diary off                                             % 
