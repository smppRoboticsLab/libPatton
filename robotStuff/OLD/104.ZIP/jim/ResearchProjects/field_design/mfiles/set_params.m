%______*** MATLAB "M" script (jim Patton) ***_______
% Sets up parameters for the simulation of a 2-joint link:
%
%                                                     phi2  `
%            o==>F                                 o==>F   `
%             \                                     \     `                
%             (m2)                                  (m2) `                      
%               \  q2                                 \ `               
%                o ` ` ` ` `                          o     
%               /                                    /           
%             (m1)                                 (m1)    phi1        
%             / q1                                 / 
%          __o___` ` ` ` ` `                    __o___` ` ` ` ` `  
%          \\\\\\\                              \\\\\\\                 
%
% VERSIONS:	  INITIATED 4/20/99 jim patton, spaned frm do_df2
%__________________________ BEGIN: ____________________________

fprintf(' ~ set_params.m script ~ ')

%__ MISC___
x=1;y=2;                                    % index to 1st & 2nd dimentions
torad=pi/180;                               % convert to radians
Gcounter=0;                                 % counts sim iterations sim_anim.m
verbose=1;                                  % true for questions
sep='-------------------------';
field_gain=zeros(2,2);                      % set basic field  to zero
speedThresh=.06;                            % for detecting onsets
maxTime=.25;                                % final time for all fiting analyses
forceNoise=0; %.1;
posNoise=0; %.001;
velNoise=0; %
movmtDistance=.1;                           % nominal mvmt dist

%___________________________________________
%-- GEOMETTRY & MASS DISTRIBUTION PARAMS: --
%___________________________________________

%__  parameters from the parameters file: __
% load values; if not there, use defaults.
fprintf ('Loading from "parameters.txt"..') %
body_mass=find1TXTvalue(                ... %
 'parameters.txt','body_mass=',0);          %
if isempty(body_mass)                       %
  fprintf(' param not found! Use default: ')%
  body_mass     = 77.2727 %=170/2.2;        % kg typical
end                                         %
body_height=find1TXTvalue(              ... %
 'parameters.txt','body_height=',0);        %
if isempty(body_height)                     %
  fprintf(' param not found! Use default: ')%
  body_height   = 1.78                      % m typical
end                                         %
uprArm_length=find1TXTvalue(            ... %
 'parameters.txt','uprArm_length=',0);      %
if isempty(uprArm_length)                   %
  fprintf(' param not found! Use default: ')%
  uprArm_length = 0.186*body_height         % Winter, 1990 page 52
end                                         %
forArm_len=find1TXTvalue(               ... %
 'parameters.txt','forArm_len=',0);         %
if isempty(forArm_len)                      %
  fprintf(' param not found! Use default: ')%
  forArm_len    = 0.146*body_height         % Winter, 1990 page 52
end                                         %
half_hand_len=find1TXTvalue(            ... %
 'parameters.txt','half_hand_len=',0);      %
if isempty(half_hand_len)                   %
  fprintf(' param not found! Use default: ')%
  half_hand_len =.108/2*body_height         % Winter, 1990 page 52
end                                         %
Xshoulder2nose=find1TXTvalue(           ... %
 'parameters.txt','Xshoulder2nose=',0);     %
if isempty(Xshoulder2nose)                  %
  fprintf(' param not found! Use default: ')%
  Xshoulder2nose=.129*body_height;          %
end                                         %
Yshoulder2motor=find1TXTvalue(          ... %
 'parameters.txt','Yshoulder2motor=',0);    %
if isempty(Yshoulder2motor)                 %
  fprintf(' param not found! Use default: ')%
  Yshoulder2motor=.85;                      %
end                                         %

%__  other parameters: __
forArm_length = forArm_len+half_hand_len;   % add half of hand length
uprArm_mass   =.028*body_mass ;             % Winter, 1990 page 57
forArm_mass   =.022*body_mass ;             % Winter, 1990 page 57
uprArm_I=uprArm_mass*(uprArm_length*.322)^2;% Winter, 1990 page 57
forArm_I=forArm_mass*(forArm_length*.303)^2;% Winter, 1990 page 57
M = [uprArm_mass  uprArm_I;                 % mass matrix row=segment, 
     forArm_mass  forArm_I];                % col1=masses col2=inertias
L = [uprArm_length;                     ... % segment lengths (interjoint)
    forArm_length];                         % index to 1st dimention
R = [0.436*uprArm_length; ...               % distal joint to segment CM
     0.682*forArm_len];                     % (Winter, 1990 page 57)
g = 0;                                      % gravity m/s/s. =0 for horiz. movement
graphicsParams=[NaN NaN .01];               % initialize params used for graphics

%____ PASSIVE JOINT PROPERTIES ____
EPpas= [15 85]*pi/180;                      % passive stationary eq point (rad)
Kpas = 0*[1 1];                             % passive spring const (N*m/rad)
Bpas = 0*[1 1];                             % passive damping const (N*m/rad)

%___ ACTIVE FEEDBACK CONTROL PROPERTIES ___
%playwav('KB.wav'); pause(.5)               % play sound      
%fprintf(' \n NOTE: altered K abnd B..\n')
Kact =  [   15    6                         % control spring const. (N*m/rad)
            6   16  ];                      %
Bact =  [  2.3     0.9                      % control damp const. (N*m*sec/rad)
           0.9   2.4 ];                     %

%____ INTEGRATOR ____
tol       = 1e-6;                           % integrator tol for convergence
minstep   = 1e-5;                           % min integration step (sec)
maxstep   = 1e-2;                           % max integration step (sec) 

setupCopycat;                               % script to assign copycat bases
CCBinitial=CCB;                              % store initial structure array

% __ Simulation type lists __
sim_list={                              ... % list of simulation classes
     'Unperturbed baseline'             ... % 
    ,'Perturbation with simple fields'  ... % 
    ,'Assistive field '           ... %
    ,'Resistive field initial expoosure'... %
    ,'Resistive field after learning'   ... %
    ,'Resistive field after effects'    ... %
  };                                %
sim_list
%    ,'Assistive field search'           ... %

% ___ PERTURBING FIELDS  ___
fields(:,:,1)= -18*[0 1;  -1  0];            % curl field
fields(:,:,2)=  -8*[0 1;  -1  0];            % curl field 
%fields(:,:,0)=1*[0 1;  -1  0];             % curl field
%fields(:,:,0)=-1*[0 1; -1  0];             % curl field
%fields(:,:,0)=-10*[1 0; 0 1];              % isotropic stable
%fields(:,:,0)=-10*[1 0; 0 1];              % isotropic stable
%fields(:,:,1)=[0 0; 0 0];                   % zero/NUL field
Nfields=length(fields(1,1,:));
field_types=str2mat('null',             ... % 
                    'viscous',          ... % 
                    'viscous',          ... % 
                    'viscous',          ... % 
                    'inertial',         ... % 
                    'inertial',         ... % 
                    'inertial'          ... % 
                    );
direction=[90,10,170,60,120,80,100];
direction=[90 70 70 70 70 70 70 70 70 70];
direction=[110 110 110 110 110 110 110];
direction=[90 90 90 90 90 90 90 90 90];

% setup of desired trajectory used to be here...    
% setup of intended trajectory used to be here...   

% ___ PLOTTING STUFF  ___
figure(1); clf; orient tall;                 % clear 
put_fig(1,.55,.05,.44,.9);                   % size window
figure(2); clf; orient tall;                 %  
put_fig(2,.28,.41,.25,.53); drawnow;         % 
%figure(3); clf; orient tall;                %  
%put_fig(3,.05,.41,.25,.53); drawnow;        % 
plotit=1;                                    % turn on plotting

% ___ SET TRIAL PLOTTING STRUCTURE ___

fprintf(' ~ Parameters defined. END set_params.m~ \n\n')
