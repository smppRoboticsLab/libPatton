% ************** MATLAB "M" script (jim Patton) *************
% perform the big analysis on generalization 
%~~~~~~~~~~~~~~~~~~~~~~ Begin: ~~~~~~~~~~~~~~~~~~~~~~~~

fprintf('\n*~ "batchAnal.m" script ~* \n')
for i=30:35,                                % subj loop
  eval(['cd pilot' num2str(i)]); 
  cd; 
  makefield
  cd ..
end

assembleCCfitResults

fprintf('\n~ END batchAnal.m ~')
return
