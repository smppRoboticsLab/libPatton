% objective function that takes the approriate params for opto
% USES NLIN LEAST SQUARES, SO THE OUTPUT IS A VECTOR OF ERRORS
function forceErrorVect=CCobjective(CCparams,I,P,len,g,verbose)

[Mforce,St,StI,len]=ccEval4(rho,rhoI,CCB,len,g,verbose);

