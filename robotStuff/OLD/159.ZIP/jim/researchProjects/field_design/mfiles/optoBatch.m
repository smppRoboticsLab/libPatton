% manage the batch processing of multiple nonlinear fits of single copycat

% ___setup___
set_params;
fitOrNot=1;
CCB=setupCopycat3([],M,L,R,K,B,0,0,CCwings,spreadScale);
for i=2:length(CCB), CCB(i)=[]; end % erase all but center point



% __ SETUP __
global DEBUGIT M L R g EPpas Kpas Bpas field_gain field_type
global RCB rc
scriptName='CCanalInterp.m';
fprintf('\n\n\n~ %s SCRIPT ~\n',scriptName)             % title message
if ~exist('plotit'), plotit=1; end                      % if not passed
playwav('menu.wav');                                    % reminder sound
startSubj=menu('Choose start trial:','30','31','32' ... %
  ,'33','34','35','36')+29                                   %
endSubj=menu('Choose end   trial:','30','31','32'   ... %
  ,'33','34','35','36')+29

% ====== BIG LOOP FOR SUBJECTS =======
for subject=startSubj:endSubj,                          % subj loop
  eval(['cd pilot' num2str(subject)]); 
  cd; 

  eval(['diary ' scriptName '.log']);                   % keep record of this
  fprintf('\n\n\n~ BEGIN analysis for %s at %s ~\n' ... %
    ,cd,whenis(clock))                                  %   
  
  [CCB,r,aveErr,fracErr]=OptCC(CCB,maxTime,trialList,fitOrNot,verbose,plotIt);
