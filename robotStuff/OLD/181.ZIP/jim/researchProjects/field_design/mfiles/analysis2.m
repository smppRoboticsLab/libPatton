%************** MATLAB "M" function  *************
% analyze data, part 2
% SYNTAX:      
% REVISIONS:    9-1-00 INITIATED from fastLearnCurves (patton) 
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function analysis2(plotIt)

% __SETUP__
prog_name='analysis2.m';                                  % name of this program
fprintf('\n~ %s ~ ', prog_name); 
if ~exist('plotIt'), plotIt=1; end                        % if not passed
set_params;                                               % set plethora o params
for i=1:2%Nmeas+1
  figure(i);clf; put_fig(i,(i-1)*.25,.25,.27,.67);         % setup figure windows
end

% __LOAD__
fprintf('\nLoading data..')
[EMh,EM]=hdrload('performMeas.txd');                      % LOAD MEASURES
colLabels=EMh(size(EMh,1),:);                             % GET MEAURE NAMES
measureNames=parse(colLabels);                            % GET MEAURE NAMES
[Ntrials,Nmeas]=size(EMh);                                % dimensions
Nmeas=Nmeas-1size(EMh,1)-2;                               % DONT COUNT 1st 2COLs
fprintf('.DONE. %d measures, %d trials. ',Nmeas,Ntrials); % display
cd ..
load trailsStruct
phaseSwitch=1;

%___LOOP FOR TRIALS___
for cumTrial=1:Ntrials,
  trial=EM(cumTrial,1);
  phase=EM(cumTrial,2);
  if phaseSwitch&phase=2;                                 
    cd part2                                              % goto Part2directory
    pwd
    load trailsStruct; 
    phaseSwitch=0;
  end

    % ___ PLOT MEASURES ON LARNING CURVES___
    for meas=1:Nmeas,
      mkr='ks';                                             % init
      for i=1:length(trialsStruct)                          % loop for exp phase
        for j=1:length(trialsStruct(i).trials)              % loop for trials in phase list 
          if trial==trialsStruct(i).trials(j),  
            mkr=[colors(i) 'o']; 
            break
          end
        end % END for j
      end % END for i
      %figure(meas+1); 
      figure(2); 
      %subplot(3,ceil(Nmeas/3),meas)
      subplot(Nmeas,1,meas)
      plot(cumTrial,EM(cumTrial,meas+2),mkr,'markersize',mkrSz);
      if trial==1, 
        hold on; set(gca,'fontsize',fsz); 
        title(deblank(measureNames(meas+2,:)));
        xlabel('Trial','fontsize',fsz);
      end
    end % END for meas
    drawnow; pause(.001);
    
end % END for trial
  
% ____ finalize plot ____
fprintf('\nFinalizing plot & printing to a file..'); 
subplot(3,ceil(Nmeas/3),1);
ax=axis; lgndX=.1*(ax(2)-ax(1));
for i=1:length(trialsStruct)                          % loop for exp phase
  mkr=[colors(i) 'o']; 
  lgndY=ax(3)+.98*(ax(4)-ax(3))-.03*i*(ax(4)-ax(3));
  plot(lgndX,lgndY,mkr,'markersize',mkrSz); hold on
  text(lgndX,lgndY,['  ' trialsStruct(i).name],'fontsize',fsz);
end % END for i
drawnow; pause(.001);
suptitle(['Learning curves for ' cd]);
print -depsc2 FastLearnCurves

% ____ GROUP the DATA for Barcharts ____
temp=[]; barMeans=[]; barStd=[];
for i=1:length(trialsStruct(3).trials)
  temp=[temp; EM(trialsStruct(3).trials(i),:)];
end
barMeans=[barMeans; mean(temp)];
barStd=[barStd; std(temp)];
bar95Width=[bar95Width; confidence(temp,.95)];

temp=[]; 
for i=1:length(trialsStruct(7).trials)
  temp=[temp; EM(trialsStruct(7).trials(i),:)];
end
barMeans=[barMeans; mean(temp)];
barStd=[barStd; std(temp)];
bar95Width=[bar95Width; confidence(temp,.95)];

temp=[]; 
for i=1:length(trialsStruct(8).trials) 
  temp=[temp; EM(trialsStruct(8).trials(i),:)];
end
barMeans=[barMeans; mean(temp)];
barStd=[barStd; std(temp)];
bar95Width=[bar95Width; confidence(temp,.95)];

% ____ make the Barcharts ____
figure(2); clf;
C=colorcube(8); C=C(4:8,:); 
for meas=1:Nmeas,
  meas
  subplot(3,ceil(Nmeas/3),meas)
  multbar3(barMeans(:,meas),1,C,str2mat(' '),...
           0.2,0.2,bar95Width(:,meas));
  title(measureNames(meas,:));
end % END for meas

suptitle(['Error measures for ' cd]);
orient landscape
print -dpsc2 barchart                     % print to a file
