% ************** MATLAB "M" script (jim Patton) *************
% create robot control babis from data using copycat, & save.
% SYNTAX:    makeField(baseList,trialList,plotit,verbose)
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  11/2/99  pulled from pilot12 to main mfiles direct.
%                     Changed from make_filed to makeField.m
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~


% __ SETUP __
global DEBUGIT M L R g EPpas Kpas Bpas 
global graphicsParams Gcounter
global field_gain field_type 
global RCB rc
diary makeField.log                                   %  
if ~exist('plotit'), plotit=1; end                    % if not passed
fprintf('\n ~ makeField.m script: ~ \n')              % message
trialList=[0 1 2];            
maxTime=.15;                                          % 
%if ~exist('FD-0.dat'),
%  baseList=21:25,ensembleTrials(baseList); 
%end 
% set_params                                          % 
% trialList=[0 26 29 34 37 39 43 46 48];

% ___ FIELD DESIGN ___
makeFieldctr=0; VAF=0; dVAF=10000; winner=0; spreadScale=1;
while abs(dVAF)>.01,
  makeFieldctr=makeFieldctr+1;
  fprintf('\n\n__makeField iteration#%d:__\n',makeFieldctr);                  % message
  lastVAF=VAF; 
  setupCopycat
  [cc,ccr]=ccFit4(CCB,maxTime,trialList);             % fit copycat model 
  [max_cc,winner]=max(cc); 
  VAF=ccr^2;  dVAF=VAF-lastVAF;
  fprintf(' VAF=%f,  dVAF=%f',VAF,dVAF);              % message
  spreadScale=.8*spreadScale;                         % narrow spread of search
  figure(3); plot(makeFieldctr,VAF)
end
cc=0*cc; cc(winner)=1;                                % winner-takes-all
rc=rcFit5(cc,CCB,rhoD(:,2:7)                      ... % fit RobotControl to CopyCat
   ,maxTime,trialList,verbose,plotit);                %
saveRCB;                                              % store in special text file

% __ COMPARE WITH IDEAL (PLOT) __
ccFake=0*cc; ccFake(length(cc))=1; cc=ccFake;         % change to "Ideal"
rcFit5(ccFake,CCBinitial,rhoD(:,2:7)              ... % adds an extra "ideal" plot on top
  ,maxTime,trialList,verbose,2)                       %
fprintf('\nField design complete.\n');                % message 

fprintf('\n ~ END makeField.m ~ \n');                 %  
diary off                                             % 

