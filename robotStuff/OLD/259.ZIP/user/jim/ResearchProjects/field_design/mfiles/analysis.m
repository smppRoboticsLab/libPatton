%************** MATLAB "M" fcn ************
% batch file to Analyze data
% SYNTAX:     analysis 
% REVISIONS:  10/25/00 (patton) INITIATED
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~

function analysis(verbose)
fprintf('\n~ Analysis.m (analysis function) ~')

% __SETUP__
%CI=.95;                                            % confidence interval for ensembles
CI=0;                                               % zero for do not compute
doPlot='individual'; 
doPrint=1;

% __Paramters__
Hz=findInTxt('Desired.txd',                     ... % 
  'Sampling freq in Hz:');                       % 
if isempty(Hz), error(' No Hz. '); end
analFrames=findInTxt('parameters.txt',          ... % duration of the force field
  'force field duration=')*Hz;                      % 
if isempty(analFrames), 
  analFrames=.2*Hz 
end
deflection=findInTxt('parameters.txt',          ... % desired bend in trajectory
        'trajectory deflection=')                   % 
if isempty(deflection), 
  fprintf('\n\7Deflection is empty - set to zero. ')%
  deflection=0;
end
if ~exist('trialsStruct_p1.mat'), 
  error(' No "trialsStruct_p1.mat" file. Aborting.')
end
%refFileroot=input('refFileroot: ','s');

% __ANALYSIS__
addGoodTrialColumn2targ
if ~exist('IFDforces.eps'), plotIFDForces; end      % plot the force field
disp('  menu...  ')                                 %
if (menu('do ensembles? ','no','yes')-1)
  doEnsembles2(CI,deflection);                      % ensemble avg's and plot
end
performMeas2([],doPlot,doPrint,analFrames,deflection);  % performance measures
%performMeas2(refFileroot,doPlot,doPrint,analFrames,deflection);  % performance measures
learnCurves(doPlot);                                % learning curves 
stats(doPlot)                                       % statistical summary & plot

playwav('done.wav')
fprintf('\n~ END Analysis.m  ~ \n')


