% ************** MATLAB "M" script (jim Patton) *************
% put CC fit results together and plot.
% SYNTAX:   
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~

%___SETUP___
prog_name='assebleCCfitResults.m';
fprintf('\n~ %s ~ \n', prog_name)
figure(1); clf
cd 
filename='CCfit.txd';
varName=['VAF '; 'Ave ';'Frac'];
fsz=9;

%if ~exist('CCfitData.txd');
  D=[]; 
  for i=31:33, % subj loop
    eval(['cd pilot' num2str(i)]); 
    cd; [h,d]=hdrload(filename); 
    D=[D; i*ones(size(d,1),1) d]; 
    
    for j=1:3 % measure loop
      [N,X]=hist(d(:,4+j));
      subplot(5,3,(i-30)*3+j); 
      bar(X,N); 
      set(gca,'fontsize',fsz);
      drawnow; pause(.01)
      if j==1, 
        ylabel(['pilot' num2str(i) ],'fontsize',fsz,'fontweight','bold')
        axis([0 1 0 10]), 
      end
      if i==30, 
        title(varName(j,:),'fontsize',fsz,'fontweight','bold')
      end      
    end
    eval('cd ..');  
  end% for i
  suptitle('Histograms')
  H=str2mat('Compiled CC fit measures',...
            ['Patton, ' whenis(clock)], ...
            sprintf('subj#\t%s',h(size(h,1),:)) ) ;
  mat2txt('CCfitData.txd',H,D);
%end % END if ~exist..

%[H,D]=hdrload('CCfitData.txd');

%figure(2); clf
for j=1:3 % measure loop
  subplot(5,3,12+j); 
  [N,X]=hist(D(:,5+j));
  bar(X,N); 
  if j==1, 
    axis([0 1 0 40]), 
    ylabel('overall','fontsize',fsz,'fontweight','bold'); 
  end
  %title(varName(j,:),'fontsize',fsz,'fontweight','bold')
end

suptitle('Histograms Over All Subjects')


fprintf('\n~ END %s ~', prog_name)
return
