% ************** MATLAB "M" function (jim Patton) *************
% Fit a model of dynamics & control of reaching given a set of CCB fcns.
%
% Uses the "numerical recipes in C" nomenclature and approach: construct an 
% A matrix and b vector, and a alpha matrix and beta vector from these.
%           
% The structurte of the model is based on the following :
%
%     o==>"end kinetics:" force and torque at endpoint
%      \
%      (m2)
%        \  q2
%         o   -   -   -   -   -   -	
%        /                 M is mass vect, R is  segment lengths, 
%      (m1)                L is distal-to-segment mass ctr., 
%      /   q1              q is positive for countrclockwise rot from horizontal
%   __o___  -   -   -   -   -   -   
%   \\\\\\\
% This assumes the following form: 
%                     D+delta-C=0
% where D is the passive dyanmic response as a function of pos vel and acc,
%       delta is the the torques due to field forces
%       C is the sliing mode controller torques, the form of the controller is: 
%                     C=Cff=Cfb
%       where  Cff are torques supplied by the internal model of the plant (D)
%                  along the expected trajectory "qe(t)."
%              Cfb are the torques supplied by the feedback components K and B:
%                     Cfb=K(q-qe)
% SYNTAX:    [d,r,aveErr]=model_fit2(CCB,History2,verbose,plot_or_not);
% INPUTS:    CCB        Global struct of CCB function params. see set_params.m
% OUTPUTS:   CCB         coeficients
% VERSIONS:  5/6/99     INITIATED by Patton from inverse_dynamics.m
%            9/14/99    changed name to copycatFit from ?
%            9/17/99    changed name to ccFit from copycatFit 
%            9/20/99    Changed name to ccFit3 and interphased 
%                       with trials via files, not History2 cell array
%            9/24/99     changed name to ccFit4 from ccFit3, added var trialList
%            10/18/99   plotIt input arguement added            
%            3/6/00     multiple directions; baseline no longer 1st on trialList
%            5/10/00    merge coef "cc" into CCB struct, rename ccfit6
%            5/11/00    loop and lay own more, add fitOrNot, rename ccfit7
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function [CCB,r,aveErr,fracErr]=ccFit7(CCB,maxTime,trialList,fitOrNot,verbose,plotIt);

%_________ SETUP ________
global DEBUGIT L g                                      % g=accel due to gravity
fcnName='ccFit7.m';
if ~exist('verbose'), verbose=1; end                  % if not passed
if ~exist('plotIt'), plotIt=1; end                    % if not passed
x=1;y=2;                                              % for indexing
cutoff=10;                                            % cutoff freq for filtering
Ntrials=length(trialList);
speed_thresh_for_move=.1;                             % min speed
if plotIt, figure(1); clf; drawnow; pause(.01); end   % set plot window

%__ MESSAGES __
if verbose, fprintf('\n ~ %s ~ \n',fcnName); end      %
if verbose,  fprintf('  %d Trials',Ntrials); end      %      
if verbose,  fprintf('  %d Bases',length(CCB)); end   %      
if verbose,  fprintf(', %.2f sec. ',maxTime); end     %
if verbose,  fprintf(', Trial List: \n'); end         %
if verbose,  fprintf(' %d',trialList); end            %

[trialHeader,trialData]=hdrload('targ.txd');          % load list of movements

lastVAF=0;delta=88888;

while (delta>.01),
if verbose, fprintf('\n\n __New Iteration:__'); end

%_________ CONSRUCT "A" MATRIX & "b" vect ________
A=[]; b=[];  rho=-1;
for pertTrial=1:Ntrials
  
  %___ LOAD pertTrial data ___
  fname=['FD-' num2str(trialList(pertTrial)) '.dat'];
  [rho,force,Hz]=loadRobotData(fname,cutoff,~verbose);% load & transform to subj  c.s.
  if isnan(rho), break; end;                          % if no more files, quit
  
  %__ GET "INTENDED" MVMT __
  Dir=trialData(trialList(pertTrial),7); 
  Mag=trialData(trialList(pertTrial),8);     % 
  fname=['baseline' num2str(Dir) '.dat'];
  if verbose, 
    fprintf('\nLoad "Intended (%s):" ',fname); 
  end
  [rhoI,forceI,Hz]=loadRobotData(fname,cutoff,0);      % load & transform to subj c.s. 
  if 0%plotIt  
    figure(1); clf;
    legend(plot(rhoI(:,1), rhoI(:,2), '.' ...
               ,rho(:,1),  rho(:,2),  '.' ...
               ),'I','perturbed');
             figure(2)
  end           
  
  %___ LOOP FOR EACH CCB FUNCTION ("A" MATRIX ) ___
  stackedFcc=[];                                      % Init
  if verbose,
    fprintf('\nTrial %d CCbasis#: ',trialList(pertTrial)); 
  end  
  for base=1:length(CCB)                              % loop each CCB function
    if verbose, fprintf('%d ',base); end              %
    len=maxTime*Hz;                                   % amount of time to analyze
    [Fcc,St,StI,len]=ccEval4(rho,rhoI,CCB(base),len,g,0); %
    stackedFcc(:,base)=[Fcc(:,x); Fcc(:,y)];          % stack x&y on top of ea other
  end                                                 % END for CCB
  
  %__ measured perturbing force ("b" vect) __
  stackedF=[force(St:St+len,1); force(St:St+len,2)];  % stack x&y on top of ea other
  
  %__ check for nonreal elements (means bad inv kin) __
  if isreal(stackedFcc)
    A=[A; stackedFcc]; b=[b; stackedF];               % stack trials on topa ea other
  else
    fprintf('\n\7 ! nonreal elements! --skipping.\n');
  end  
    
  %___ PLOT ___ 
  if plotIt,
    time=(0:length(rho(:,1))-1)/Hz; time=time';
    clf
    subplot(3,1,1) % position xy 
    %plot(sum(L)*cos(60/180*pi:.1:120/180*pi),     ... % plot workspace
    %  sum(L)*sin(60/180*pi:.1:120/180*pi),'g');       % ...
    %hold on
    legend(plot( rho(:,1),rho(:,2),'b.',          ... %
      rho(St:St+len,1),rho(St:St+len,2),'bo',     ... % 
      rhoI(:,1),rhoI(:,2),'g.',                   ... %
      rhoI(StI:StI+len,1),rhoI(StI:StI+len,2),'go'... %
      ,'markersize',2                             ... %
      ),'rho','','rhoI','');                          %
    hold on
    quiver([rho(:,1); -.08],[rho(:,2);.48],                     ...
           [force(:,1); 10],[force(:,2); 0],'r')%
    text(-.08,.48,'10 N','VerticalAlignment','bottom')%
    title('positon');  ylabel('m'); xlabel('m');
    axis equal;  axis tight
    
    subplot(3,1,2) % velocity  
    legend(plot(time, rho(:,3),'r.',              ...
                time, rho(:,4),'b.',              ...
          time(St:St+len), rho(St:St+len,3),'ro', ...
          time(St:St+len), rho(St:St+len,4),'bo'  ...
          ,'markersize',2 ...
          ),'x','','y',''); 
    title('velocity'); ylabel('m/s');

    subplot(3,1,3) % force
    plot( time, force(:,1),'r.',                    ...
          time, force(:,2),'b.',                    ...
          time(St:St+len), force(St:St+len,1),'ro',  ...
          time(St:St+len), force(St:St+len,2),'bo'   ...
          ,'markersize',2 ...
          ); 
    title('force');  ylabel('N'); xlabel('sec');

    suptitle(['CC fit trial ' num2str(trialList(pertTrial))])
    drawnow;  pause(.01)
    if pertTrial==1,
      print -dpsc2 ccFit
    else
      print -dpsc2 -append ccFit
    end
    
  end 
    
end                                                   % END for pertTrial

%_________ LEAST SQUARES SOLUTION ________
if fitOrNot,
  if verbose,   
    fprintf('\n Least Squares solution:')%
    fprintf('\nA:<%d,%d>, b:<%d,%d>. ',size(A),size(b));%
  end   
  alpha=A'*A; beta=A'*b;                                % construct alpha and beta 
  %fprintf('Pseudoinv...'); cc=pinv(alpha)*beta;        % pseudoinverse (SVD)
  fprintf('NonNegative...'); cc=nnls(alpha,beta);       % find nonnegative linear sln
  for i=1:length(CCB), CCB(i).cc=cc(i); end             % need vect form
else
  for i=1:length(CCB), cc(i,1)=CCB(i).cc; end           % load back into vect
end

%_________ model fit measures ________
corMTX=corrcoef(A*cc,b);  r=corMTX(1,2);
aveErr=sqrt(sum((A*cc-b).^2))/size(A,1);
fracErr=sum(  (abs(A*cc-b))./b  )/size(A,1);
delta=r^2-lastVAF;
lastVAF=r^2;

%_________ DISPLAY ________
if verbose, 
  for i=1:length(CCB),
    fprintf('\ncc(%d)=%.29g',i,CCB(i).cc); 
  end;
  fprintf('\n model fit: (cc to data)');
  fprintf('\n rsquared=%.4f',r^2);  
  fprintf('\n aveErr=%.4fN',aveErr);  
  fprintf('\n fracErr=%.4f',fracErr);  
  fprintf('\n deltaVAF=%.4f',delta);  
end       

if fitOrNot,
  %__ remove unneeded (zero coef) bases __ 
  if verbose, fprintf('\n Pruning unneeded Bases:'); end
  i=1;
  while i<=length(CCB)                                   % LOOP plot EACH rcBASIS 
    if CCB(i).cc<eps*10, 
      if verbose, fprintf(' %d',i); end
      CCB(i)=[]; 
    else 
      i=i+1; 
    end 
  end 
  if verbose, fprintf(' DONE. \n',i); end
  CCB

  %__ add bases __ 
  if delta>.005 & length(CCB)>1,                       % if half pct improvement
    if verbose, fprintf('\n Adding Bases:'); end
    CCB=CCBmean(CCB,1:length(CCB))                         % average all together
    for i=1:length(CCB)-1,  
      for j=i+1:length(CCB); 
        CCB=CCBmean(CCB,[i j])                        % average individual pairs
      end; 
    end
  end % END if delta
else 
  delta=0;
end % if fitOrNot

end %END  while delta  <=============================

%_________ DISPLAY ________
if verbose, 
  fprintf('\n\n CC RESULTS:');
  for i=1:length(CCB),
    fprintf('\ncc(%d)=%.29g',i,CCB(i).cc); 
  end;
  fprintf('\n model fit: (cc to data)');
  fprintf('\n rsquared=%.4f',r^2);  
  fprintf('\n aveErr=%.4fN',aveErr);  
  fprintf('\n fracErr=%.4f',fracErr);  
  fprintf('\n ~ END %s ~ \n',fcnName); 
end

return



% ************** MATLAB "M" function (jim Patton) *************
% create a CCB from an average of others (specified by "list")
% SYNTAX:    
% INPUTS:    
% OUTPUTS:   
% VERSIONS:  5/15/00    init
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function CCB=CCBmean(CCB,list)

    Msum=zeros(2,2); Lsum=zeros(2,1); Rsum=zeros(2,1);     % init
    Ksum=zeros(2,2); Bsum=zeros(2,2); Xsum=0; Ysum=0;      % init
    len=length(list);
    for i=1:length(list)                                   % LOOP 
      Msum=Msum+CCB(list(i)).M;
      Lsum=Lsum+CCB(list(i)).L;
      Rsum=Rsum+CCB(list(i)).R;
      Ksum=Ksum+CCB(list(i)).K;
      Bsum=Bsum+CCB(list(i)).B;
      Xsum=Xsum+CCB(list(i)).X;
      Ysum=Ysum+CCB(list(i)).Y;
    end
    CCB(CClen+1).M=Msum/CClen;
    CCB(CClen+1).L=Lsum/CClen;
    CCB(CClen+1).R=Rsum/CClen;
    CCB(CClen+1).K=Ksum/CClen;
    CCB(CClen+1).B=Bsum/CClen;
    CCB(CClen+1).X=Xsum/CClen;
    CCB(CClen+1).Y=Ysum/CClen;
    CCB(CClen+1).cc=0;
    
return