%************** MATLAB "M" function  *************
% analyze data, part 4: ensemble average plots
% SYNTAX:      
% REVISIONS:  2/8/2000  (patton) INITIATED
%             9-1-0 RENAMED analysis1.m from fastLearnCurves.m (patton)
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function analysis4()

% ____ SETUP ____
prog_name='analysis4.m';                                % name of this program
fprintf('\n~ %s ~ ', prog_name);                        % MSG
set_params;                                             %
verbose=1; plotIt=1; printIt=1;                         % switches for display
fsz=8;                                                  % font size
mkrSz=2;                                                % marker size
baseDir=cd;
Dname=['sin-morphed.txd'];                              %

%__setup figure__
for i=1:2
  figure(i);clf; put_fig(i,(i-1)*.15,.5,.37,.45);       % window
end

% ____ LOOP for EACH part ____
for part=1:2,
  fprintf('\n\npart %d:\n~~~~~~',part); 
  load trialsStruct
  [trialHeader,trialData]=hdrload('targ.txd');                % targets & trial info
  Dirs=sort(distill(trialData(:,7))'); nDirs=length(Dirs);
    
  % ____ LOOP for EACH part & TRIAL  ____
  for phase=1:length(trialsStruct)
    fprintf('\n\n\n___\n Phase %d ("%s"): ',phase,        ...
      trialsStruct(phase).name); 
    clf; drawnow
    
    % ___ loop for each dir ___
    for Dir=1:nDirs,                                            % determine direction
      fprintf('\n  Direction %d: ',Dirs(Dir)); 
      
      % determine sub-list of trials that match Dir and phase
      trials=[];
      for i=trialsStruct(phase).trials 
        if trialData(i,7)==Dirs(Dir),trials=[trials i];end
      end % END for i        
      fprintf('\n    Trials:'); fprintf(' %d',trials);
      Ename=[trialsStruct(phase).name  '.'                  ... % ouput filename
             num2str(Dirs(Dir)) '.ensemble.dat'];               %
      ensembleTrials(trials,Ename,plotit,verbose,~printIt)      % perform ensemble
      
      % load desired  
      fprintf('\n    %s for %d deg.. ',Dname,Dirs(Dir));        %
      D=getIdealTrajectory(Dname,L                          ... % load & transform
       ,startPt,Dirs(Dir)*pi/180-pi,Mag,deflection          ... % 
       ,speedThresh,0);                                         %
      plot(D(:,2),D(:,3),'r.')                                   % 
      fprintf('Done. \n');                                      %

    end % END for Dir

    % ___ finalize and print ___
    suptitle(str2mat('Ensemble trials for',                 ...
      trialsStruct(phase).name ,cd));
    if part==1 & phase==1,
      cmd=['print -dpsc2 ' baseDir '\ensembles.ps']; 
    else
      cmd=['print -dpsc2 -append ' baseDir '\ensembles.ps']; 
    end
    disp(cmd); eval(cmd)
    
  end % END for phase

  fprintf('\nDONE with trials for part %d. ',part); 
  if part==1; 
    cd part2; cd                                  % change to new directory
    wd=parse(cd,'\'); wd=wd(size(wd,1),:);        % working directory
  else      cd ..                                 
  end   
end % END for part

fprintf('\n~ END %s ~ ', prog_name); 
return
