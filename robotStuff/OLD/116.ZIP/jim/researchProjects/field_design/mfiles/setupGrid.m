% ******************* MATLAB "M" file  (jim Patton) ******************
% setup astate-dependent grid of bases functions
%  SYNTAX:	
%  INPUTS:      
%  OUTPUTS:     
%  REVISIONS:   INITIATED 9/12/99 patton. 		
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~

function grid=setupGrid(verbose);

%______ SETUP ______
global DEBUGIT 
fcnName='setupGrid.m';
if ~exist('verbose'), verbose=1; end                 % if not passed
if verbose,fprintf('\n ~ %s ~ \n',fcnName); end      %

%___  ___
sparsity=.1;
grid={[-.3]}


return


