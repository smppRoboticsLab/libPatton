% ************** MATLAB "M" script (jim Patton) *************
% create robot control babis from data using copycat, & save.
% SYNTAX:    makeField(baseList,trialList,plotit,verbose)
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  11/2/99  pulled from pilot12 to main mfiles Dirsect.
%                     Changed from make_filed to makeField.m
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~


% __ SETUP __
global DEBUGIT M L R g EPpas Kpas Bpas 
global RCB rc
if ~exist('plotit'), plotit=1; end                    % if not passed
diary makeField.log                                   % keep record of this
fprintf('\n ~ makeField.m script: ~ \n')              % message
set_params                                            % setup most values 

% __ PLOT part 1 trials__
if ~exist('trajectories.ps'),
  figure(1); plot_trials4([],0)
end

% __ find experimental phases __
[trialHeader,trialData]=hdrload('targ.txd'); 
for start1=startTrial:size(trialData,1),  
  if trialData(start1,9)==1, break; end               % find the start of phase 1
end
for start2=start1:size(trialData,1),  
  if trialData(start1,9)==2, break; end               % find the start of phase 2
end

% __ Ensemble Average some baseline trials __
fprintf('\nBaseline Ensembles:');
clf
baseList=[]; % init
for D=1:nDirs
  fprintf(['\nFor the %d degree Dirsection '      ...
    'in robot coordinates:'],Dirs(D));
  outName=['baseline' num2str(Dirs(D)) '.dat']; 
  if ~exist('baseList.txd'),
    dirCount=0;
    for i=startTrial:start1-1,   
      if trialData(i,7)==Dirs(D); 
        dirCount=dirCount+1;
        baseList(D,dirCount)=trialData(i,1); 
      end     % add trial to list
    end % for i
    baseList(D,:)
    ensembleTrials(baseList(D,:),outName); 
  else
    fprintf('\n (Ensemble "%s" already done)',outName)
    load 'baseList.txd'
  end % END if ~exist
  %disp(' pausing ..');   pause
end % END for D  
hdr=str2mat('% list of baseline trials.',         ... %
            '% Each column is a direction');       ... %
mat2txt('baseList.txd',hdr,baseList);
fprintf(' Ensebles DONE (see "baseList.txd"). ') 
baseList

% ___ Assemble List of perturbation trials ___
trialList=[];
for i=start1:start2,
  if (trialData(i,6)>-50 | trialData(i,6)<50)...
      &trialData(i,6)~=0; 
    trialList=[trialList trialData(i,1)];             % add trial to list
  end    
end % for i
fprintf('\n List of Perturbation trials: '); 
fprintf(' %d',trialList); fprintf('\n\n');

% ___ FIT COPYCAT ___
[cc,ccr]=ccFit5(CCB,maxTime,trialList);               % fit copycat model 
[max_cc,winner]=max(cc); 
cc=0*cc; cc(winner)=1;                                % winner-takes-all

% **** RC FIELD DESIGN **** 
%[rc,rcr]=rcFit7(cc,CCB,baseList,maxTime,startPt,Dirs,Mag,deflection)
if 1,
  setupRCB([1.2*Mag,1*Mag,1*Mag,1*Mag,1*Mag,],    ...
         [startPt+[0 0];    ...
         startPt+[ .02  .02];    ...
         startPt+[-.02  .02];    ...
         startPt+[ .02 -.02];    ...
         startPt+[-.02 -.02]])
elseif 0
  setupRCB(.7*Mag,startPt)
else
end
[rc,rcr]=rcFit6(cc,CCB,maxTime,startPt,Dirs,Mag,deflection)

fprintf('\n ~ END makeField.m ~ \n');                 %  
diary off                                             % 
