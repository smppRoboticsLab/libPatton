% ************** MATLAB "M" script (jim Patton) *************
% put CC fit results together and plot.
% SYNTAX:   
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~

%___SETUP___
scriptName='assembleTimeResults.m';
analysisName='CCanalTime';
fprintf('\n*~ %s ~* \n', scriptName)
figure(1); clf; fsz=9;
Colors=[zeros(1,29) 'brgkmcybrgkmcybrgkmcy'];

% _____ subject data _____
D=[]; 
for i=30:34, % subj loop
  eval(['cd pilot' num2str(i)]); 
  filename=['pilot' num2str(i) analysisName '.m.txd']
  cd; 
  [h,d]=hdrload(filename);

  plot(d(:,8),d(:,5),Colors(i));
  hold on
  axis([0 1 0 1])
  
  D=[D; i*ones(size(d,1),1) d]; 
  cd ..
  
  
end % END for i

H=str2mat('Compiled CC fit measures',...
            ['Patton, ' whenis(clock)], ...
            sprintf('subj#\t%s',h(size(h,1),:)) ) ;
mat2txt([analysisName '.txd'],H,D);
  
suptitle([analysisName ' Fit vs. Amount of analysis time']) 
eval(['print -depsc2 ' analysisName '.ps']);


