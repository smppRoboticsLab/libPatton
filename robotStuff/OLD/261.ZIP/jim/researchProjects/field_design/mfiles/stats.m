%************** MATLAB "M" function  *************
% analyze data, subject's stat results & plot
% SYNTAX:      
% REVISIONS:    9-1-00 INITIATED from fastLearnCurves (patton)
%               10-25-00 renamed stats.m from analysis3.m
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function stats(plotIt)

% __SETUP__
prog_name='stats.m';                                      % name of this program
fprintf('\n\n\n~ %s ~ \n', prog_name);                    % message
if ~exist('plotIt'), plotIt=1; end                        % if not passed
set_params;                                               % set plethora o params
fsz=8; mkrSz=2;                                           % font & marker size
colors='mcrgby';
for i=1:1%Nmeas+1
  figure(i);clf; put_fig(i,(i)*.25,.25,.27,.67);        % setup figure windows
end
lastPart=0;                                               % last trial of prev. "part"
baseDir=cd;
if ~exist('performMeas.txd'), analysis1(0); end            % process if not already

% __LOAD__
fprintf('\nLoading data..')
[EMh,EM]=hdrload('performMeas.txd');                      % LOAD MEASURES
colLabels=EMh(size(EMh,1),:);                             % GET MEAURE NAMES
colNames=parse(colLabels);                                % GET MEAURE NAMES
[Ntrials,Nmeas]=size(EM);                                 % dimensions
measureNames=colNames(4:Nmeas,:)  
Nmeas=Nmeas-3;                                            % DONT COUNT 1st 2COLs
measIndexes=4:Nmeas+3;                                    % index to "measure" cols
fprintf('.DONE. %d measures, %d trials. ',Nmeas,Ntrials); % display
nParts=findInTxt('performMeas.txd','Number of Parts=')
if isempty(nParts); nParts=2; end

% LOAD INFORMATION ABOUT GOOD OR BAD TRIALS
goodTrials=textract('performMeas.txd','Good trial');        % load column of data
if goodTrials(1,1)==-8888,                                  % if not there
  goodTrials=ones(size(EM,1),1);                            % make a column of all good
end


% ____ GROUP the DATA for Barcharts ____
fprintf('\nGrouping the data...'); 
barMeans=[]; barStd=[]; bar95Width=[]; phaseNames=[];     % init
for part=1:nParts,
  filename=['trialsStruct_p' num2str(part) '.mat'];
  fprintf(' exist?=%d ',exist(filename));
  if exist(filename)
    load(filename); 
  else 
    load('trialsStruct')
  end
  
  for i=1:0 %REMARK OUT length(trialsStruct)              % loop for exp part
    fprintf('\nPart %d phase %d= %s, trials:', ...
      part,i,trialsStruct(i).name);
    fprintf(' %d',trialsStruct(i).trials);
  end
  
  for phase=1:length(trialsStruct)
    fprintf('\n  Part %d Phase %d ',part,phase);          % display
    fprintf('(%s):',trialsStruct(phase).name);            % display
    fprintf('Trials: ');                                  % display
    fprintf(' %d',trialsStruct(phase).trials)             % display
    measures=[];                                          % init
    for i=1:length(trialsStruct(phase).trials)            % loop for trials on list
      %fprintf('\n   Looking for match for trial %d..',...% display
      %  trialsStruct(phase).trials(i));                  %
      for j=1:size(EM,1)                                  % loop to search EM
        if (EM(j,1)==trialsStruct(phase).trials(i) ...    % if it matches trial and 
           &EM(j,2)==part & EM(j,3)),                     %  part and "good"...
          %fprintf(' match at row %d:  ',j);EM(j,:)       % display
          measures=[measures;                         ... %
                    EM(j,measIndexes)];                   % stack on summary
          break                                           % 
        end                                               % END if EM
      end                                                 % END for j
    end                                                   % END for i
    barMeans=[barMeans; part phase mean(measures)];       %
    barStd=[barStd; part phase std(measures)];            %
    bar95Width=[bar95Width;                           ... % 
        part phase confidence(measures,.95)];             %  
    phaseNames=str2mat(phaseNames,                    ... % 
        trialsStruct(phase).name);                        %
  end                                                     % END for phase
  if part==1&exist('part2')==7,                           % if part 2 is in a subdir
    cd part2; cd                                          % 
  end                                                     %
end % END for part                                        %
phaseNames(1,:)=[];                                       % clip off blank line 
cd(baseDir)                                               %

%barMeans,barStd,bar95Width,phaseNames 
fprintf('Done Grouping the data. \n'); 

% ____ make the Barcharts ____
fprintf('\nBarcharts..'); 
figure(1); clf;
C=colorcube(8); 
for meas=1:Nmeas,
  fprintf('\n Measure#%d: %s ',meas,measureNames(meas,:));  % 
  switch plotIt
    case 1,               
      subplot(Nmeas,1,meas);
    case 'individual',    
      figure(meas); 
      clf; put_fig(meas,(meas)*.05,.25-meas*.02,.5,.7);     % setup figure windows
      orient tall
  end 
  multbar3(barMeans(:,meas+3)',[],C,phaseNames,...
           [],[],bar95Width(:,meas+3)',0,'barInside');
  title(measureNames(meas,:));
end % END for meas

if strcmp(plotIt,'individual'), FN=Nmeas, else FN=1; end
  
for i=1:FN,
  figure(i);   orient tall
  suptitle(str2mat('Experimental Phases for', cd)); 
  drawnow; pause(.001);
  if i==1, print -dpsc2 barcharts                     % print to a file
  else     print -dpsc2 -append barcharts; end
end

% ____ output 2 file ____ 
fprintf('\nSaving..'); 
h=['Summary data for ' cd]; 
h=str2mat(h,                                              ... 
  ['Generated by ' prog_name ', ' whenis(clock)],         ... 
  'Each row is a experimental phase. See phaseNames.txd.',                      ... 
  phaseNames,...
  '____data:____');
col_labels=['Part' setstr(9) 'Phase' ];       % init w/tabSeparator
for meas=1:Nmeas,
  col_labels=[col_labels ... 
      setstr(9) deblank(measureNames(meas,:)) ]; 
end % END for meas 
h=str2mat(h,col_labels); 
mat2txt('barMeans.txd',h,barMeans);
mat2txt('bar95Width.txd',h,bar95Width);
mat2txt('phaseNames.txd',phaseNames,-9999);
fprintf('DONE.\n'); 

fprintf('DONE.'); 
fprintf('\n~ END %s ~ \n\n', prog_name); 

