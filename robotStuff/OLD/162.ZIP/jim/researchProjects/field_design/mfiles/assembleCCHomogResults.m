% ************** MATLAB "M" script (jim Patton) *************
% put CC fit results together and plot.
% SYNTAX:   
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~

%___SETUP___
scriptName='assembleCCHomogResults.m';
fprintf('\n*~ %s ~* \n', scriptName)
figure(1); clf
cd 
fsz=9;
varName=str2mat('VAF (r^2)','Ave Force Err (fraction of max)','Processing time (s)');
cols=[5 6 8];

  D=[]; 
  for i=30:30, % subj loop
    eval(['cd pilot' num2str(i)]); 
    filename=['pilot' num2str(i) 'CCanalHomogenous.m.txd'];
    cd; [h,d]=hdrload(filename); 
    varName=parse(h(size(h,1),:));
    D=[D; i*ones(size(d,1),1) d]; 
    for j=1:3 % measure loop
      [N,X]=hist(d(:,cols(j)));
      subplot(8,3,(i-30)*3+j); bar(X,N); 

      switch j
      case 1,          
        ylabel(['subject ' num2str(i) ],'fontsize',fsz,'fontweight','bold')
        axis([0 1 0 15])
      case 2,         
        axis([0 .02 0 15])
      case 3,         
        axis([0 500 0 15])
      end % END switch
      set(gca,'fontsize',fsz); drawnow; 
      if i==30, 
        title(deblank(varName(cols(j),:)),'fontsize',fsz,'fontweight','bold')
      end      
    end
    eval('cd ..');  
  end% for i
  
  suptitle('Histograms of All Subjects') 
  eval(['print -dpsc2 ' scriptName]); 

% _____ summary data _____
figure(2); clf
for j=1:3 % measure loop
  subplot(3,3,j); 
  [N,X]=hist(D(:,cols(j)+1));
  bar(X,N); 
  switch j
  case 1,     axis([0 1 0 50]), 
    ylabel('overall','fontsize',fsz,'fontweight','bold'); 
  case 2,     axis([0 .02 0 50]), 
  case 3,     axis([0 2 0 50]), 
  end % END switch j
  %title(varName(j,:),'fontsize',fsz,'fontweight','bold')
end

  D=[]; 
  for i=35:36, % subj loop
    eval(['cd pilot' num2str(i)]); 
    filename=['pilot' num2str(i) 'CCanalHomogenous.m.txd'];
    cd; [h,d]=hdrload(filename); 
    varName=parse(h(size(h,1),:));
    D=[D; i*ones(size(d,1),1) d]; 
    for j=1:3 % measure loop
      [N,X]=hist(d(:,cols(j)));
      subplot(3,3,(i-34)*3+j); bar(X,N); 

      switch j
      case 1,          
        ylabel(['subject ' num2str(i) ],'fontsize',fsz,'fontweight','bold')
        axis([0 1 0 15])
      case 2,         
        axis([0 .02 0 15])
      case 3,         
        axis([0 500 0 15])
      end % END switch
      set(gca,'fontsize',fsz); drawnow; 
      if i==30, 
        title(deblank(varName(cols(j),:)),'fontsize',fsz,'fontweight','bold')
      end      
    end
    eval('cd ..');  
  end% for i
  suptitle('Histograms')
  H=str2mat('Compiled CC fit measures',...
            ['Patton, ' whenis(clock)], ...
            sprintf('subj#\t%s',h(size(h,1),:)) ) ;
  mat2txt('CCfitData.txd',H,D);

suptitle('Histograms of Model Analysis')
eval(['print -dpsc2 -append ' scriptName]);

fprintf('\n~ END %s ~', scriptName)
return
