
% ___setup___
set_params;
CCB=setupCopycat3([],M,L,R,K,B,0,0,CCwings,spreadScale);
for i=2:length(CCB), CCB(i)=[]; end % erase all but center point

% borrow more from the other protocols here
[CCB,r,aveErr,fracErr]=OptCC(CCB,maxTime,trialList,fitOrNot,verbose,plotIt);
