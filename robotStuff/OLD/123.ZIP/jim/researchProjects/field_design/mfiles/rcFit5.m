% ************** MATLAB "M" function (jim Patton) *************
% convert a fit of a copycat (cc) model to a robot control (rc) model 
% Uses the "numerical recipes in C" nomenclature and approach: construct an 
% A matrix and b vector, and a alpha matrix and beta vector from these.
% SYNTAX:    
% INPUTS:    
% OUTPUTS:   
% VERSIONS: 9/14/99     INITIATED by Patton from inverse_dynamics.m
%           9/20/99     changed name to rcFit from cc2rcFit, removed 
%                       History2 and put in trials loaded from files
%           9/23/99     changed name to rcFit2 from rcFit, added var "St"
%           9/23/99     changed name to rcFit2 from rcFit, added var "St"
%           9/24/99     changed name to rcFit3 from rcFit2, added var trialList
%           10/5/99     changed name to rcFit4, fit so that the subject learns a field 
%                       who's torque time history along s_hat(t) is the torque 
%                       necessary to swing it to t s_D(t) in after-effects.
%           10/15/99    changed name to rcFit5, add plotit input args, 
%                       removed RCB (it is global).
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

function [rc,r,norm_ssq]=rcFit5(cc,CCB,rhoD,maxTime,trialList,verbose,plotit);

%_________ SETUP ________
fcnName='rcFit5.m';
global DEBUGIT g RCB                                  % g=accel due to gravity
if ~exist('verbose'), verbose=1; end                  % if not passed
if ~exist('plotit'), plotit=1; end                    % if not passed
x=1;y=2;                                              % for indexing
A=[]; b=[]; trial=0; rho=-1;                          % Init
stopFlag=0;
cutoff=10;                                            % cutoff freq for filtering
Hz=100;                                               % sampling freq
Ntrials=length(trialList);
speed_thresh_for_move=.06;
len=maxTime*Hz;                                       % amount of time to analyze
FI=NaN;                                               % initialize to "not used yet"
L=CCB(length(CCB)).L;                                 % best guess at limb lengths

%__ MESSAGES __
if verbose,                                           %
  fprintf('\n ~ %s ~ \n',fcnName);                    %
  fprintf('  %d Trials, ',Ntrials);                   %
  fprintf('Fitting %d CCBASES w/ %d rcBASES ',   ...  %
       length(CCB),length(RCB));                      %  
  fprintf(', %.2f sec. ',maxTime);                    %
end                                                   %

%_________ load intended traject  ________
if verbose, fprintf('\nLoad "Intended:" '); end
filename=['FD-' num2str(trialList(1)) '.dat'];
[rhoI,forceI,Hz]=loadRobotData(filename,cutoff);      % load & transform to subj c.s.
qI=inverse_kinematics3(rhoI(:,1:2),1,L);              % joint (relative) ang intent
qD=inverse_kinematics3(rhoD(:,1:2),1,L);              % joint (relative) ang desire 
speedD=sqrt(rhoD(:,3).^2+rhoD(:,4).^2);

%_________ eval CC along desired traject  ________
if verbose, fprintf('\n - Eval CC along rhoD: '); end
for i=1:length(CCB)                                   % loop each basis function 
  if verbose,fprintf('%d',i); end                     % 
  if cc(i),                                           % if nonzero 
    if verbose,fprintf('.'); end                      % 
    [F,StD,StI,len]=ccEval4(rhoD,rhoI,CCB(i),len,g,0);% eval if intended is used
    if isnan(FI), FI=zeros(len+1,2); FD=FI; end;      % init to zero
    FI=FI+cc(i)*F;                                    %
    FD=FD +cc(i)*ccEval4(rhoD,rhoD,CCB(i),len,g,0);   % eval if desired is used
  else
   if verbose,fprintf(' '); end                       % 
  end  
end                                                   % END for i
FccD=-(FD-FI);                                        % cancel subj's & add Desire

%__ convert CC force along desired traject to torque __
j=0;
for i=StD:StD+len
  j=j+1;
  J=jacobian([qD(i,1); qD(i,2)-qD(i,1)], L);          % find jacobian (best guess of L)
  TccD(j,:)=((J')*FccD(j,:)')';                       % J' to convert to torque
end

%__ convert back to force along intended traject __
j=0;
for i=StI:StI+len
  j=j+1;
  J=jacobian([qI(i,1); qI(i,2)-qI(i,1)], L);          % find jacobian (best guess of L)
  FccI(j,:)=(inv(J')*TccD(j,:)')';                    % inv(J') to convert to force
end
stackedFccI=[FccI(:,x);FccI(:,y)];                    % stack x&y on top of ea other

%__ Construct ROBOT CONTROL BASIS (RCB) along rhoI __
gsf=4.2919;                                           % makes gaussian have a width 1
                                                      % at 1% of the total magnitude
%RCBwidth=.1;                                         % spacing between centers
RCBwidth=( rhoD(length(rhoD),2)-rhoD(1,2) )*1;        % for testing single rcb 
k=(gsf/RCBwidth)^2;                                   % for region of effectiveness
%anchor=[rhoI(StI,1) rhoI(StI,2)];                    % init for small distance
anchor=[9999 9999];                                   % init for big distance 
j=0;
for i=StI:StI+len                                     % drop down basis fields only for start
  dist=sqrt((rhoI(i,1)-anchor(1))^2 +            ...  %
            (rhoI(i,2)-anchor(2))^2);                 %
  if dist>RCBwidth/2,                                 % if gone far enough, make RCB
    %for k=1:4
      j=j+1;
      RCB(j).C=rhoI(i,1:2);                           % center of the basis
      RCB(j).B=[0 1; -1 0];                           % init CURL ONLY
      %RCB(j).B=[0 0; 0 0]; RCB(j).B(k)=1;            % init: set each one to 1
      RCB(j).K=k.*eye(2);                             % uniform gaussian width    
      anchor=rhoI(i,1:2);                             % init distance and start index
    %end
  end                                                 % END if dist          
end                                                   % END for i
%for k=1:4                                             % extra one at end
if 0
  j=j+1;                                              % 
  RCB(j).C=rhoI(i,1:2);                               % center of the basis
  %RCB(j).B=[0 0; 0 0];                                % init
  %RCB(j).B(k)=1;                                      % set one to 1
  RCB(j).B=[0 1; -1 0];                                % init
  RCB(j).K=k.*eye(2);                                 % uniform gaussian width   
end
%end

%__ evaluate RC model BASES ("A" MATRIX) __
if verbose,fprintf('\nEvlauating RC basis#: ');end    %
for i=1:length(RCB)                                   % LOOP FOR EACH rcBASIS
  if verbose,fprintf('%d ',i); end                    %
  Frc=rcEval3(rhoI,RCB(i),0);                         % rc force evaluations 
  stackedFrcI(:,i)=[Frc(StI:StI+len,x);           ... % stack x&y on topa ea other
                    Frc(StI:StI+len,y)];              %
end                                                   % END for i

A=[A; stackedFrcI]; b=[b; stackedFccI];               % trials on top of ea other

%_________ LEAST SQUARES SOLUTION ________
if verbose,   
  fprintf('\nLeast square (A<%d,%d>, b<%d,%d>)'   ... %
    ,size(A),size(b));%
end   
alpha=A'*A; beta=A'*b;                                % construct alpha and beta
%fprintf('QR decomposition'); rc=alpha\beta;          
%fprintf('NonNegative LS sln:'); rc=nnls(alpha,beta); % find nonnegative linear sln
fprintf('(pseudoinverse)..'); rc=pinv(alpha)*beta;    
if verbose,  fprintf('Done.'); end

%_______ plot ______
if plotit==1, 
  LW=3;
  clf;
  time=(0:length(rhoI(:,1))-1)/Hz; time=time';
  
  sumFrc=0*rhoI(:,1:2);                               % init
  for i=1:length(RCB)                                 % LOOP FOR EACH rcBASIS
    Frc=rcEval3(rhoI,RCB(i),0);                       % rc force evaluations 
    subplot(3,1,1), 
    plot(time,rc(i).*Frc(:,x),'b:'); hold on
    subplot(3,1,2), 
    plot(time,rc(i).*Frc(:,y),'b:'); hold on
    sumFrc=sumFrc+rc(i).*Frc;
  end                                                 % END for i
  
  subplot(3,1,1), 
  h=plot(time(StI:StI+len),FccI(:,x),'r',         ...
    time,sumFrc(:,x),'b:','linewidth',LW);
  legend(h,'CC','RC',0);
  hold on
  title('X forces (N)'); 

  subplot(3,1,2), 
  h=plot( time(StI:StI+len),FccI(:,y),'r',          ...
        time,sumFrc(:,y),'b:','linewidth',LW); 
      title('Y forces (N)'); 
  legend(h,'CC','RC',0);
  hold on
  xlabel('seconds')
  
  subplot(3,1,3)
  plot(time,rhoI(:,3:4)); title('velocity');
  
end % END if plotit

if plotit==2, % for adding a curve on top to already run
  time=(0:length(rhoI(:,1))-1)/Hz; time=time';
  subplot(3,1,1)
  plot(time(StI:StI+len),FccI(:,x),'k');
  subplot(3,1,2)
  plot(time(StI:StI+len),FccI(:,y),'k');
end % END if plotit

if plotit,
  suptitle('RC Model fit along unperturbed trajectory');
  if verbose, 
    fprintf('\nprinting figure to model_fit.ps..');
  end
  print -depsc2 model_fit
end % END if plotit

%_________ model fit measures ________
corMTX=corrcoef(A*rc,b);  r=corMTX(1,2);
norm_ssq=sum((A*rc-b).^2)/length(A(:,1));

%_________ DISPLAY ________
if verbose, 
  for i=1:length(rc),
    fprintf('\nrc(%d)=%.6f',i,rc(i)); 
  end;
  fprintf('\n rsquared (rc to cc)=%.4f',r^2);  
  fprintf('\n ~ END %s ~ \n',fcnName); 
end       

if verbose,fprintf(' ~ END %s ~ ',fcnName); end       %

return
