% ************** MATLAB "M" script (jim Patton) *************
% create robot control babis from data using copycat, & save.
% SYNTAX:    makeField(baseList,trialList,plotit,verbose)
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  11/2/99  pulled from pilot12 to main mfiles Dirsect.
%                     Changed from make_filed to makeField.m
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~


% __ SETUP __
global DEBUGIT M L R g EPpas Kpas Bpas 
global RCB rc
if ~exist('plotit'), plotit=1; end                    % if not passed
diary makeField.log                                   % keep record of this
fprintf('\n ~ makeField.m script: ~ \n')              % message
set_params                                            % setup most values 

% __ PLOT part 1 trials__
if ~exist('trajectories.ps'),
  figure(1); plot_trials4([],0)
end

% __ Ensemble Average some baseline trials __
fprintf('\nBaseline Ensembles:');
clf
baseList=[]; % init
for D=1:nDirs
  fprintf(['\nFor the %d degree Dirsection '      ...
    'in robot coordinates:'],Dirs(D));
  outName=['baseline' num2str(Dirs(D)) '.dat']; 
  if ~exist('baseList.txd'),
    dirCount=0;
    for i=startTrial:start1-1,   
      if trialData(i,7)==Dirs(D); 
        dirCount=dirCount+1;
        baseList(D,dirCount)=trialData(i,1); 
      end     % add trial to list
    end % for i
    baseList(D,:)
    ensembleTrials(baseList(D,:),outName); 
  else
    fprintf('\n (Ensemble "%s" already done)',outName)
    load 'baseList.txd'
  end % END if ~exist
  %disp(' pausing ..');   pause
end % END for D  
hdr=str2mat('% list of baseline trials.',         ... %
            '% Each column is a direction');       ... %
mat2txt('baseList.txd',hdr,baseList);
fprintf(' Ensebles DONE (see "baseList.txd"). ') 
baseList

load trialsStruct

fprintf('\n List of Perturbation trials: '); 
fprintf(' %d',trialsStruct(2).trials);fprintf('\n')

% ___ FIT COPYCAT ___
fprintf('\n ___ COPYCAT: ___: '); 
setupCopycat;                                         % assigns copycat bases
[cc,ccr]=ccFit5(CCB,maxTime,trialList);               % fit copycat model 
%[max_cc,winner]=max(cc); cc=0*cc; cc(winner)=1;      % winner-takes-all

% __ RC FIELD DESIGN __
fprintf('\n ___ REGIONAL CONTROL BASES: ___: '); 
if 0,
  setupRCB([1.2*Mag,1*Mag,1*Mag,1*Mag,1*Mag,],    ...
         [startPt+[0 0];                          ...
         startPt+[ .02  .02];                     ...
         startPt+[-.02  .02];                     ...
         startPt+[ .02 -.02];                     ...
         startPt+[-.02 -.02]]);
elseif 1
  setupRCB(.7*Mag,startPt)
else
end
%[rc,rcr]=rcFit7(cc,CCB,baseList,maxTime,startPt,Dirs,Mag,deflection)
[rc,rcr]=rcFit6(cc,CCB,maxTime,startPt,Dirs,Mag,deflection);

fprintf('\n ~ END makeField.m ~ \n');                 %  
diary off                                             % 
