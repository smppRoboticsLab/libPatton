% ************** MATLAB "M" script (jim Patton) *************
% put CC fit results together and plot.
% SYNTAX:   
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~

%___SETUP___
scriptName='assembleSensitivity.m';
analysisName='Sensitivity.m';
fprintf('\n*~ %s ~* \n', scriptName)
figure(1); clf; orient tall;
fsz=7; 
Colors=['brgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcy'];
numTimes=16;
counter=0;
D=[]; 
names=[ 'M11'             % see setupCopycat3.m
        'M12'
        'M21'
        'M22'
        'R1 '
        'R2 '
        'L1 '
        'L2 '
        'Bss'
        'Bee'
        'Bse'
        'Kss'
        'Kee'
        'Kse'
        'X  '
        'Y  '
      ]

% ____ SUBJ LOOP - LOAD AND ASSEMBLE DATA ____
for i=30:34, % subj loop
  eval(['cd pilot' num2str(i)]); 
  filename=['pilot' num2str(i) analysisName '.m.txd']
  [h,d]=hdrload(filename); len=size(d,1);
  varName=parse(h(size(h,1),:));
  StackedD(:,:,i-29)=d;
  cd ..  
end % END for i

% ____ STATS ____
subjD=StackedD(:,:,1:5);
MeanD=mean(subjD,3);  MaxD=max(subjD,3);  MinD=min(subjD,3);

% ____ SAVE DATA ____
H=str2mat('Compiled measures for',                  ... 
          analysisName,                             ... 
          ['Patton, ' whenis(clock)],               ... 
          sprintf('subj#\t%s',h(size(h,1),:)) ) ;   
mat2txt([analysisName '.txd'],H,D); 

% === PLOT ===
for J=5:6, % index to columns in datafile
  counter=counter+1;
  subplot(2,1,counter);
  h=patch([MeanD(:,8) ; flipud(MeanD(:,8))],			...
      [MeanD(:,J)+confidenceD(:,J);             ...
       flipud(MeanD(:,J)-confidenceD(:,J))],    ...
      [1 1 .8],'EdgeColor','none');
  hold on
  plot(MeanD(:,8),MeanD(:,J),'k','linewidth',4);  
  text(MeanD(numTimes,8),MeanD(numTimes,J),   ...
       ' Subject mean','fontSize',fsz,'fontWeight','bold');
  for i=1:7
    plot(StackedD(:,8,i),StackedD(:,J,i),Colors(i)); %'r'
    if     i==6, labelText=' Stochastic model';
    elseif i==7, labelText=' Deterministic model';
    else         labelText=['  ' num2str(i+29)];
    end
    text(StackedD(numTimes,8,i),StackedD(numTimes,J,i),   ...
       labelText,'fontSize',fsz);
  end
  xlabel('Seconds','fontSize',fsz);
  ylabel(deblank(varName(J,:)),'fontSize',fsz);
  %axis([0 1 0 1]);
end

suptitle([analysisName ' Fit vs. Amount of analysis time']) 
eval(['print -depsc2 ' analysisName '.ps']);


fprintf('\n ~ END %s ~ \n', scriptName)
