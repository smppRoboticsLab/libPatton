%************** MATLAB "M" script ************
% batch file to Analyze data
% SYNTAX:     analysis 
% REVISIONS:  10/25/00 (patton) INITIATED
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~

fprintf('\n~ Analysis.m (analysis batch file) ~')

% __SETUP__
confidenceInterval=0%.95;
doPlot=2; 
doPrint=1;

% __ANALYSIS__
doEnsembles(confidenceInterval);                  % ensemble avg's and plot
performMeas(doPlot,doPrint);                      % performance measures
learnCurves(doPlot);                              % learning curves 
stats(doPlot)                                     % statistical summary & plot

playwav('done.wav')
fprintf('\n~ END Analysis.m (analysis batch file) ~ \n')
