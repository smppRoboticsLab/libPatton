dt=1/100; 
dx =[0 0; 0 0];
ddx=[0 0; 0 0];

for i=3:length(x); 
  
  dx(i,:)= (x(i,:)-x(i-1,:))./dt;
  sdx(i,:)= (x(i,:)-x(i-2,:))./(2*dt);
  ssdx(i,:)= (3*x(i,:)-2*x(i-1,:)-x(i-2,:))./dt; 

  ddx(i,:)=(dx(i,:)-dx(i-1,:))./dt; 
  sddx(i,:)= (dx(i,:)-dx(i-2,:))./(2*dt);
  ssddx(i,:)= (3*dx(i,:)-2*dx(i-1,:)-dx(i-2,:))./dt;
  
end

clf; subplot(3,1,1)
plot(ddx,'.'); hold on; plot(ddx); 
subplot(3,1,2)
plot(sddx,'.'); hold on; plot(sddx); 
subplot(3,1,3)
plot(ssddx,'.'); hold on; plot(ssddx); 
