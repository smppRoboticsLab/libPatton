%************** MATLAB "M" fcn ************
% make an ensemble figure
% SYNTAX:     analysis 
% REVISIONS:  10/25/00 (patton) INITIATED
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~

% __SETUP__
CI=.95;
CI=0;
deflection=findInTxt('parameters.txt',          ... % desired bend in trajectory
        'trajectory deflection=')                   % 
      
%_this overrides "phasesOinterest" (see targ_?.txd)_
what2do(1).phases=[2 5];
what2do(2).phases=[2];
what2do(3).phases=[2 3 6];

plotDims=[2 3]
plotAxes=[-0.14,0.14,-0.125,0.09];
      
doEnsembles2(CI,deflection,what2do,plotDims,plotAxes);                        % ensemble avg's and plot
playwav('done.wav')
fprintf('\n~ END Analysis.m  ~ \n')

