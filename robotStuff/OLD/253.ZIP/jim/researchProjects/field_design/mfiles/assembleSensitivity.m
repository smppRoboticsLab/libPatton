% ************** MATLAB "M" script (jim Patton) *************
% put CC fit results together and plot.
% SYNTAX:   
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~

%___SETUP___
scriptName='assembleSensitivity.m';
analysisName='Sensitivity';
fprintf('\n*~ %s ~* \n', scriptName)
figure(1); clf; orient tall;
fsz=7; 
Colors=['brgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcy'];
numTimes=16;
counter=0;
D=[]; 
names=str2mat('Upper arm mass'  ,       ...      % see setupCopycat3.m
        'Upper arm inertia',            ...
        'Forarm arm mass',              ...
        'Forarm inertia',               ...
        'Upper arm length',             ...
        'Forarm length',                ...
        'Upper arm CM location',        ...
        'Forarm CM location ',          ...
        'Shoulder damping',             ...
        'Elbow damping',                ...
        'Interaction damping',          ...
        'Shoulder stiffness',           ...
        'Elbow stiffness',              ...
        'Interaction stiffness',        ...
        'Lateral shoulder position', ...
        'Anterior shoulder position' );
for i=1:1; figure(i); clf; put_fig(i,.1+i*.1,.1-i*.05,.4,.7); orient tall;; end
axises=[0 18 0 .7
  0 18 0 2.5];
varName=str2mat('VAF (r^2)','Force err (fraction of max)');

% ____ SUBJ LOOP - LOAD AND ASSEMBLE DATA ____
cd \jim\ResearchProjects\field_design\experiments
for i=30:34, % subj loop
  eval(['cd pilot' num2str(i)]); 
  filename=['pilot' num2str(i) analysisName '.m.txd'];
  [h,d]=hdrload(filename); [len,wid]=size(d);
  %varName=parse(h(size(h,1),:));
  D(:,:,i-29)=d;
  cd ..  
end % END for i

% ____ STATS ____
MeanD=mean(D,3);  MaxD=max(D,3);  MinD=min(D,3);
baseScores=MeanD(1,:)
for i=1:38
  pctChange(i,:)=100*abs(MeanD(i,:)-baseScores)./baseScores;
end

% ____ CONDENSE____
condensed=[ mean([pctChange(3:4,:)]);           ... % M11
            mean([pctChange(5:6,:)]);           ... % M12
            mean([pctChange(7:8,:)]);           ... % M21
            mean([pctChange(9:10,:)]);          ... % M22
            mean([pctChange(11:12,:)]);         ... % L1
            mean([pctChange(13:14,:)]);         ... % L2
            mean([pctChange(15:16,:)]);         ... % R1
            mean([pctChange(17:18,:)]);         ... % R2
            mean([pctChange(19:20,:)]);         ... % Bss
            mean([pctChange(21:22,:)]);         ... % Bee
            mean([pctChange(23:24,:)]);         ... % Bse
            mean([pctChange(25:26,:)]);         ... % Kss
            mean([pctChange(27:28,:)]);         ... % Kee
            mean([pctChange(29:30,:)]);         ... % Kse
            mean([pctChange(31:32,:)]);         ... % X
            mean([pctChange(33:34,:)])          ... % Y
          ];
size(condensed);
        
% ____ SAVE DATA ____
H=str2mat('Compiled measures for',                  ... 
          analysisName,                             ... 
          ['Patton, ' whenis(clock)],               ... 
          sprintf('subj#\t%s',h(size(h,1),:)) ) ;   
mat2txt([analysisName '.txd'],H,condensed); 

% === PLOT ===
counter=0;
for J=5:6, % index to columns in datafile
  subplot(2,1,J-4); %figure(J-4); %
  multbar3(condensed(:,J)',1:16,[1 1 1],names,[],[],[],[],'barTop');
  title(deblank(varName(J-4,:)));
  ylabel('Percent change')
  axis(axises(J-4,:))
end

  suptitle(['Paramter sensitivity to a 10% change in the paramters']) 
  eval(['print -depsc2 ' analysisName '.eps']);


fprintf('\n ~ END %s ~ \n', scriptName)
