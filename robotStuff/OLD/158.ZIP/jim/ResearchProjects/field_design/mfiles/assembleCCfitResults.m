% ************** MATLAB "M" script (jim Patton) *************
% put CC fit results together and plot.
% SYNTAX:   
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~

%___SETUP___
prog_name='assembleCCfitResults.m';
fprintf('\n*~ %s ~* \n', prog_name)
figure(1); clf
cd 
varName=str2mat('VAF (r^2)','Ave Force Err (fraction of max)','Err as a fraction of F');
fsz=9;

%if ~exist('CCfitData.txd');
  D=[]; 
  for i=30:35, % subj loop
    eval(['cd pilot' num2str(i)]); 
    filename=['pilot' num2str(i) 'CCfitHomogenious.txd'];
    cd; [h,d]=hdrload(filename); 
    D=[D; i*ones(size(d,1),1) d]; 
    
    for j=1:3 % measure loop
      [N,X]=hist(d(:,4+j));
      subplot(7,3,(i-30)*3+j); 
      bar(X,N); 
      set(gca,'fontsize',fsz);
      drawnow; pause(.01)
      switch j
      case 1, 
        ylabel(['subject ' num2str(i) ],'fontsize',fsz,'fontweight','bold')
        if i==35, ylabel('Simulation'); end
        axis([0 1 0 15]), 
      case 2, 
        axis([0 .02 0 15]), 
      case 3, 
        axis([0 2 0 15]), 
      end % END switch
      if i==30, 
        title(deblank(varName(j,:)),'fontsize',fsz,'fontweight','bold')
      end      
    end
    eval('cd ..');  
  end% for i
  suptitle('Histograms')
  H=str2mat('Compiled CC fit measures',...
            ['Patton, ' whenis(clock)], ...
            sprintf('subj#\t%s',h(size(h,1),:)) ) ;
  mat2txt('CCfitData.txd',H,D);
%end % END if ~exist..

%[H,D]=hdrload('CCfitData.txd');

%figure(2); clf
for j=1:3 % measure loop
  subplot(7,3,18+j); 
  [N,X]=hist(D(:,5+j));
  bar(X,N); 
  switch j
  case 1, 
    axis([0 1 0 50]), 
    ylabel('overall','fontsize',fsz,'fontweight','bold'); 
  case 2, 
    axis([0 .02 0 50]), 
  case 3, 
    axis([0 2 0 50]), 
  end % END switch
  %title(varName(j,:),'fontsize',fsz,'fontweight','bold')
end

suptitle('Histograms Over All Subjects')
print -depsc2 CCfitHomogenious

fprintf('\n~ END %s ~', prog_name)
return
