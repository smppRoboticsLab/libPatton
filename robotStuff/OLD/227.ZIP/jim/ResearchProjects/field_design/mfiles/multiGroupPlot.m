
figure(3); clf
label=1;

phasesOfInterest=[2 5 7 8 11 12 13 14 15];

phasesOfInterest=[7 12];
phasesOfInterest=[12 13 14 15];

cd D:\jim\ResearchProjects\field_design\experiments\ifd\ifd_11-18
groupAnalysis(1,11:18,'ifd',phasesOfInterest,[],'o','-',2,.02,label)

cd D:\jim\ResearchProjects\field_design\experiments\ifd\ifd_21-25
groupAnalysis(1,23:25,'ifd',phasesOfInterest,[],'s')


