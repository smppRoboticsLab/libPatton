%************** MATLAB "M" function  *************
% analyze data: overall group results
% SYNTAX:      
% REVISIONS:    9-1-00  INITIATED from fastLearnCurves (patton) 
%               9-10-0  changed name from analysis4 to groupAnalysis
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function groupAnalysis(plotIt,subjNums,prefix,phasesOfInterest,phases2highlight,symbol,linestyle,lw,stagger,label3)

% __SETUP__
prog_name='groupAnalysis.m';                              % name of this program
fprintf('\n\n\n~ %s ~ \n', prog_name);                    % message
if ~exist('plotIt'), plotIt=1; end                        % if not passed
if ~exist('subjNums'),subjNums=input('Subject #s: '); end % if not passed
if ~exist('prefix'),prefix=input('File prefix: ','s');end % if not passed
if ~exist('phasesOfInterest'),                            % if not passed
  phasesOfInterest=input(                             ... % 
   'phasesOfInterest (e.g., [2 5 7 8 11 12 13 14 15]): ');% 
end                                                       % 
if ~exist('phases2highlight'), phases2highlight=[]; end   % if not passed
if ~exist('symbol'),symbol='.'; end                       % if not passed
if ~exist('linestyle'),linestyle='-'; end                 % if not passed
if ~exist('lw'),lw=1; end                                 % if not passed
if ~exist('stagger'),stagger=0; end                       % if not passed
if ~exist('label3'),label3=0; end                         % if not passed
nPhases=length(phasesOfInterest);                         % number of phases
fsz=6; mkrSz=2;                                           % font & marker size
for i=1:2                                                 % loop to set figures
  figure(i);clf; put_fig(i,(i-1)*.25,.25,.27,.67);        % setup figure windows
end                                                       %
nSubj=length(subjNums);
subScale=.6/(nSubj+2);                                    % dist btwn subject lines
minSubj=min(subjNums);
subjCount=0;
baseDir=cd;
AX=[0   nPhases+1   0   .06                               % preferred axis bounds
    0   nPhases+1   0   .06                               % each row is for a measure
    0   nPhases+1  -30   90 ];

% ___load & reorganize data (each line a subject)___
for subj=subjNums,                                        % subj loop
  subjCount=subjCount+1;
  eval(['cd ' prefix num2str(subj)]);                     % change to directory
  fprintf('\nSubj %d Loading data..',subj)                % 
  
  % 95 confidence intervals
  filename=['bar95Width.txd'];
  if ~exist(filename),error(['!Not there:' filename]);end % process if not already
  [h,d]=hdrload(filename); [Nphases,Nmeas]=size(d); 
  d(:,1:2)=[]; cubePMS95(:,:,subjCount)=d;                % clip 1st 2 cols & stack 
  
  % means
  filename=['barMeans.txd'];
  if ~exist(filename),error(['!Not there:' filename]);end % process if not already 
  [h,d]=hdrload(filename); [Nphases,Nmeas]=size(d); 
  d(:,1:2)=[]; cubePMS(:,:,subjCount)=d;                  % clip 1st 2 cols & stack 
  
  % clip out 1st 2 cols
  measureNames=parse(h(size(h,1),:)); 
  measureNames(1:2,:)=[];                                 % remove trial and phase
  Nmeas=Nmeas-2;
  
  % phase names
  phaseNames=hdrload('phaseNames.txd');
  fprintf('Done. '); 
  cd ..
end % END for subj

% ___stats____ 
fprintf('\nStats.. ')   % 
phaseNames=phaseNames(phasesOfInterest,:);                % clip out intermediates
cubePMS95=cubePMS95(phasesOfInterest,:,:);                % clip out intermediates
cubePMS=cubePMS(phasesOfInterest,:,:);                    % clip out intermediates
cubeSPM=permute(cubePMS,[3 1 2]);                         % swap dimensions
if nPhases<8
  C=colorcube(8); 
else
  C=colorcube(nPhases); 
end
C=zeros(30,3);                                            % remark out for color
OAmeans=cubeStat(cubePMS,'mean');
OAconfidence=cubeStat(cubePMS,'confidence',.95);

%___ PLOTS___
fprintf('\nPlots.. ')                                     % 

% ___segment plots____ 
figure(2); clf
mkrStr='sdv^<>px+*oh';
for meas=1:Nmeas,
  fprintf('\nMeasure#%d(%s)',meas,measureNames(meas,:))   % 
  subplot(Nmeas,1,meas);
  for phase=1:nPhases
    patch(phase*ones(1,6)+.3*[1 1 -1 -1 1 1],    ...
     OAmeans(phase,meas)*ones(1,6)+OAconfidence(phase,meas)*...
     [ 0 1 1 -1 -1 0],[.9.9.9], ...
     'EdgeColor','none'); hold on
    plot(phase+.3*[-1 1],OAmeans(phase,meas)*[1 1],'k:');
    for subj=1:nSubj
      xpos=phase+subScale*(subj+.5-(nSubj+2)/2);          % x for this phase on plot
      yctr=cubePMS(phase,meas,subj);                      % y center
      yhi=yctr+cubePMS95(phase,meas,subj);                % plus 95
      ylo=yctr-cubePMS95(phase,meas,subj);                %
      %plot(xpos,yctr,'.','color',C(subj,:) );            % dot
      plot(xpos,yctr,mkrStr(subj),'markerSize', ...       % symbol
        6,'color',C(subj,:));                             %
      plot(xpos*[1 1],[yhi ylo],'-','color',C(subj,:) );  % line
      hold on
      set(gca,'XTickLabel',[],'Xtick',[], ...
              'box','off','XColor',[1 1 1])
    end    
    % box to highlight if chosen:
    for i=1:length(phases2highlight)
      if phase==phases2highlight(i),                      % if on list
        rectangle('position',                         ... % highlight box
          [phase-.5 AX(meas,3) 1 AX(meas,4)-AX(meas,3)]...% 
          ,'edgeColor',[1 1 0],'LineWidth',4);         
      end
    end % END for i
  end % END for phase
  % plot(OAmeans(:,meas),'k*')
  title(deblank(measureNames(meas,:)));
  ax=axis; plot([ax(1) ax(2)],[0 0],'k:'); % line
  
  % ___line wings plots____ 
  figure(3);  
  subplot(Nmeas,1,meas);
  plot(stagger+(1:size(OAmeans,1)),...
       OAmeans(:,meas)*[1 1],['k' linestyle],'linewidth',lw); 
  hold on
  plot(stagger+(1:size(OAmeans,1)),...
       OAmeans(:,meas)*[1 1],['k' symbol],'markersize',6);    
  for phase=1:nPhases
    plot(stagger+phase*ones(1,6)+.02*[-1 1 0 0 -1 1],     ...
      OAmeans(phase,meas)*ones(1,6)     ...
      +OAconfidence(phase,meas)*[-1 -1 -1 1 1 1],...
      ['k' linestyle],'linewidth',lw)
  end
  axis([0 nPhases+1 AX(meas,3) AX(meas,4)]); 
  set(gca,'XTickLabel',[],'Xtick',[], ...
     'box','off','XColor',[1 1 1])
  title(deblank(measureNames(meas,:)));
  ax=axis; plot([ax(1) ax(2)],[0 0],'k:'); % line
  figure(2)
  
end % END for meas

% ___overall barchart ___
figure(1); clf
for meas=1:Nmeas,
  fprintf('\nMeasure#%d(%s)',meas,measureNames(meas,:)) % 
  subplot(Nmeas,1,meas);
  multbar3(mean(cubeSPM(:,:,meas)),[],[.8 .8 .8],phaseNames,...
    .85,[],confidence(cubeSPM(:,:,meas),.95),0,'barInside'); %
  hold on
  title(deblank(measureNames(meas,:)));
end % END for meas

% __ finalize plots __
for i=1:3 
  figure(i) 
  ax=axis; 
  
  % __ phase labels __
  if(i==2|(i==3&label3)),
    for phase=1:nPhases 
      text(phase, ... 
       min(min(min(cubePMS))), ...                   %-max(max(max(cubePMS95))))
       [deblank(phaseNames(phase,:)) ''],  ...  
       'HorizontalAlignment','right',  ...  
       'VerticalAlignment','middle',  ...  
       'Rotation',90)      
    end
  end
  
  %__ ticks and labels __
  subplot(Nmeas,1,1); ax=axis; 
  axis([ax(1) ax(2) 0 .04]);
  set(gca,'fontsize',16,'YTick',[0 .04]);
  ylabel('m')

  subplot(Nmeas,1,2); ax=axis; 
  axis([ax(1) ax(2) 0 .04])
  set(gca,'fontsize',16,'YTick',[0 .04]);
  ylabel('m')

  subplot(Nmeas,1,3); ax=axis; 
  axis([ax(1) ax(2) -30 60])
  set(gca,'fontsize',16,'YTick',[-30 0 60]);
  ylabel('deg')

  orient tall
  %suptitle(str2mat('Errors between desired & actual trajectories','Each subject is a color')); 
  drawnow; pause(.001);
end
 
% __ print to eps files __
disp('');
figure(1); 
cmd=['print -depsc2 ' prefix 'GroupBarChart'];
disp(cmd); eval(cmd)% print to a file
figure(2); 
cmd=['print -depsc2 ' prefix 'GroupSegmentChart'];
disp(cmd); eval(cmd)% print to a file
figure(3); 
cmd=['print -depsc2 ' prefix 'GroupLineChart'];
disp(cmd); eval(cmd)% print to a file

% ____ set & save output data files ____
h=['Summary data for ' cd]; 
h=str2mat(h,... 
  ['Generated by ' prog_name ', ' whenis(clock)],... 
  ['each row is a subject"s mean data'],... 
  '____data:____');
col_labels=['Subject'];
for i=1:size(phaseNames,1),
  col_labels=[col_labels setstr(9)  ...                   % init w/tabSeparator
              deblank(phaseNames(i,:))];        
end
h=str2mat(h,col_labels);
for meas=1:Nmeas,
  groupData=[subjNums' cubeSPM(:,:,meas)];
  mat2txt([deblank(measureNames(meas,:)) ...
           'subject_means.txd'], h,groupData);
end

fprintf('DONE.'); 
fprintf('\n~ END %s ~ \n\n', prog_name); 

return

