%************** MATLAB "M" function  *************
% analyze data: overall group results
% SYNTAX:      groupAnalysis(plotIt,subjNums,prefix,phasesOfInterest,phases2highlight,symbol,linestyle,lw,stagger,label3)
% REVISIONS:    9-1-00  INITIATED from fastLearnCurves (patton) 
%               9-10-0  changed name from analysis4 to groupAnalysis
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function groupAnalysis(plotIt,subjNums,prefix,phasesOfInterest,phases2highlight,symbol,linestyle,lw,stagger,label3)

% __SETUP__
prog_name='groupAnalysis.m';                              % name of this program
fprintf('\n\n\n~ * %s * ~ \n', prog_name);                    % message
if ~exist('plotIt'), plotIt=1; end                        % if not passed
if ~exist('subjNums'),subjNums=input('Subject #s: '); end % if not passed
if ~exist('prefix'),prefix=input('File prefix: ','s');end % if not passed
if ~exist('phasesOfInterest'),                            % if not passed
  phasesOfInterest=input(                             ... % 
    ['phasesOfInterest (e.g., [2 5 7 8 11 12 13 15])' ...
     ' press enter for all of them']);% 
end                                                       % 
if ~exist('phases2highlight'), phases2highlight=[]; end   % if not passed
if ~exist('symbol'),symbol='.'; end                       % if not passed
if ~exist('linestyle'),linestyle='-'; end                 % if not passed
if ~exist('lw'),lw=1; end                                 % if not passed
if ~exist('stagger'),stagger=0; end                       % if not passed
if ~exist('label3'),label3=0; end                         % if not passed
fsz=6; mkrSz=2;                                           % font & marker size
for i=1:2                                                 % loop to set figures
  figure(i);clf; put_fig(i,(i-1)*.25+.1,.25,.27,.67);        % setup figure windows
end                                                       %
nPhases=length(phasesOfInterest);                         % number of phases
nSubj=length(subjNums);
subScale=.6/(nSubj+2);                                    % dist btwn subject lines
minSubj=min(subjNums);
subjCount=0;
AX=[0   nPhases+1   0   .06                               % preferred axis bounds
    0   nPhases+1   0   .06                               % each row is for a measure
    0   nPhases+1  -30   90 ];
singlePlots=1  % for splitting figure 2 into separate ones
baseDir=cd;
wd=parse(baseDir,'\'); wd=deTabBlank(wd(size(wd,1),:));   % get name of directory
 
% ___load & reorganize data (each line a subject)___
for subj=subjNums,                                        % subj loop
  subjCount=subjCount+1;
  cmd=(['cd ' prefix num2str(subj)]);disp(cmd);eval(cmd)  % change to directory
  fprintf('.       Subj %d Loading data..',subj)          % 
  
  if isempty(phasesOfInterest),                           % if not given presume all
    phasesOfInterest=1:size(hdrload('phaseNames.txd'),1)
    nPhases=length(phasesOfInterest);                     % number of phases
  end
    
  % 95 confidence intervals
  filename=['bar95Width.txd'];
  if ~exist(filename),error(['!Not there:' filename]);end % process if not already
  [h,d]=hdrload(filename); [Nphases,Ncols]=size(d);       % load
  if subjCount>1&Ncols~=Nmeas+2, 
    error(' Different # measures among subjects! ')       % ERR IF NO MATCH 
  end
  d(:,1:2)=[];   cubePMS95(:,:,subjCount)=d;              % clip 1st 2 cols & stack 
  
  % means
  filename=['barMeans.txd'];
  if ~exist(filename),error(['!Not there:' filename]);end % process if not already 
  [h,d]=hdrload(filename); [Nphases,Ncols]=size(d)        % load
  d(:,1:2)=[];  cubePMS(:,:,subjCount)=d;                 % clip 1st 2 cols & stack 
  
  % clip out 1st 2 cols
  measureNames=parse(h(size(h,1),:)); 
  measureNames(1:2,:)=[];                                 % remove trial and phase  
  Nmeas=Ncols-2;                                          % FIRST 2 ARE NOT  MEASURES
  
  % phase names
  phaseNames=hdrload('phaseNames.txd');
  fprintf('Done. '); 
  cd ..
end % END for subj

% ___stats____ 
fprintf('\nStats.. ')   % 
phaseNames=phaseNames(phasesOfInterest,:);                % clip out intermediates
cubePMS95=cubePMS95(phasesOfInterest,:,:);                % clip out intermediates
cubePMS=cubePMS(phasesOfInterest,:,:);                    % clip out intermediates
cubeSPM=permute(cubePMS,[3 1 2]);                         % swap dimensions
if nPhases<8
  C=colorcube(8); 
else
  C=colorcube(nPhases); 
end
%C=zeros(30,3);                                            % remark out for color
OAmeans=cubeStat(cubePMS,'mean');
OAconfidence=cubeStat(cubePMS,'confidence',.95);

%___ PLOTS___
fprintf('\nPlots.. ')                                     % 
for i=4:Nmeas+3,
  figure(i);clf; put_fig(i,i*.03+.3,.3-i*.02,.3,.7);      % setup figure windows
end

% ___segment plots____ 
figure(2); clf
mkrStr='sdv^<>px+*oh';
for meas=1:Nmeas,
  fprintf('\nMeasure#%d(%s)',meas,measureNames(meas,:))   % 
  if singlePlots, 
    figure(3+meas); clf
  else
    subplot(Nmeas,1,meas);
  end
  fprintf('  Phase: ')   % 
  for phase=1:nPhases
    fprintf('%d ',phase)   % 
    patch(phase*ones(1,6)+.3*[1 1 -1 -1 1 1],    ...
      OAmeans(phase,meas)*ones(1,6)+OAconfidence(phase,meas)*...
      [ 0 1 1 -1 -1 0], [.7 .7 .7], ...
      'EdgeColor','none'); hold on
    plot(phase+.3*[-1 1],OAmeans(phase,meas)*[1 1],'k:');
    ax=axis;
    if singlePlots,       
      text(phase, ... 
        OAmeans(phase,meas)-OAconfidence(phase,meas), ...
        [num2str(phase) '. '                       ...
         deblank(phaseNames(phase,:)) '      '],  ...  
        'HorizontalAlignment','right',  ...  
        'VerticalAlignment','middle',  ...  
        'Rotation',90)      
    end    
    for subj=1:nSubj
      xpos=phase+subScale*(subj+.5-(nSubj+2)/2);          % x for this phase on plot
      yctr=cubePMS(phase,meas,subj);                      % y center
      yhi=yctr+cubePMS95(phase,meas,subj);                % plus 95
      ylo=yctr-cubePMS95(phase,meas,subj);                %
      %plot(xpos,yctr,'.','color',C(subj,:) );            % dot
      plot(xpos,yctr,mkrStr(subj),'markerSize', ...       % symbol
        4,'color',C(subj,:));                             %
      plot(xpos*[1 1],[yhi ylo],'-','color',C(subj,:) );  % line
      hold on
      set(gca,'XTickLabel',[],'Xtick',[], ...
        'box','off','XColor',[1 1 1])
    end    
    
    % box to highlight if chosen:
    for i=1:length(phases2highlight)
      if phase==phases2highlight(i),                      % if on list
        ax=axis; 
        rectangle('position',                         ... % highlight box
          [phase-.5 ax(3) 1 ax(4)-ax(3)]...% 
          ,'edgeColor',[1 1 0],'LineWidth',4);         
      end
    end % END for i
  end % END for phase
  % plot(OAmeans(:,meas),'k*')
  title(deblank(measureNames(meas,:)));
  ax=axis; plot([ax(1) ax(2)],[0 0],'k:'); % line
  
  % ___line wings plots____ 
  figure(3);  
  subplot(Nmeas,1,meas);
  plot(stagger+(1:size(OAmeans,1)),...
    OAmeans(:,meas)*[1 1],['k' linestyle],'linewidth',lw); 
  hold on
  plot(stagger+(1:size(OAmeans,1)),...
    OAmeans(:,meas)*[1 1],['k' symbol],'markersize',6);    
  for phase=1:nPhases
    plot(stagger+phase*ones(1,6)+.02*[-1 1 0 0 -1 1],     ...
      OAmeans(phase,meas)*ones(1,6)     ...
      +OAconfidence(phase,meas)*[-1 -1 -1 1 1 1],...
      ['k' linestyle],'linewidth',lw)
  end
  %axis([0 nPhases+1 AX(meas,3) AX(meas,4)]); 
  set(gca,'XTickLabel',[],'Xtick',[], ...
    'box','off','XColor',[1 1 1])
  title(deblank(measureNames(meas,:)));
  ax=axis; plot([ax(1) ax(2)],[0 0],'k:'); % line
  figure(2)
  
end % END for meas

% ___overall barchart ___
figure(1); clf
for meas=1:Nmeas,
  fprintf('\nMeasure#%d(%s)',meas,measureNames(meas,:)) % 
  subplot(Nmeas,1,meas);
  multbar3(mean(cubeSPM(:,:,meas)),[],[.8 .8 .8],phaseNames,...
    .85,[],confidence(cubeSPM(:,:,meas),.95),0,'barInside'); %
  hold on
  title(deblank(measureNames(meas,:)));
end % END for meas

% __ print plots __
figure(1) 
cmd=['print -dpsc2 GroupCharts'];disp(cmd); eval(cmd)         % print to PS file
hgsave(gcf,'GroupBarChart');                                  % save in matlabFig format
figure(3) 
cmd=['print -dpsc2 -append GroupCharts']; disp(cmd);eval(cmd) % print to PS file
hgsave(gcf,'lineChart');                                      % save in matlabFig format

% __ finalize plots __
fprintf('\nFinalize plots.. ')   % 
for meas=1:Nmeas 
  if singlePlots, figure(3+meas);
  else            subplot(Nmeas,1,meas);
  end  
  drawnow;
  ax=axis; 
  
  % __ phase labels __
  if ~singlePlots&meas==Nmeas                                 % only if all on one
  ax=axis; 
    for phase=1:nPhases 
      text(phase,ax(3)+.1, ... 
        ...%min(min(min(cubePMS))), ...                       %-max(max(max(cubePMS95))))
        [num2str(phase) '. '      ...
        deblank(phaseNames(phase,:)) ''],  ...  
        'HorizontalAlignment','right',  ...  
        'VerticalAlignment','middle',  ...  
        'Rotation',90)      
      deblank(phaseNames(phase,:));
    end
  end
  
  orient tall
  hdl=textonplot(['(' wd ')'],.93,.93); 
  set(hdl,'fontsize',8)
  drawnow; pause(.001);
  
  % __ print post script & fig files __
  cmd=['print -dpsc2 -append GroupCharts'];
  disp(cmd); eval(cmd)% print to PS file
  hgsave(gcf,[deblank(measureNames(meas,:))       ...
      '_GroupSegmentChart']);  % save in matlabFig format
  
end % END for meas

cmd=['print -dpsc2 -append GroupCharts'];
disp(cmd); eval(cmd)% print to PS file

% ____ set & save output data files ____
fprintf('\nStore output.. ')   % 
h=['Summary data for ' cd]; 
h=str2mat(h,... 
  ['Generated by ' prog_name ', ' whenis(clock)],... 
  ['each row is a subject"s mean data'],... 
  '____data:____');
col_labels=['Subject'];
for i=1:size(phaseNames,1),
  col_labels=[col_labels setstr(9)  ...                   % init w/tabSeparator
              deblank(phaseNames(i,:))];        
end
h=str2mat(h,col_labels);
for meas=1:Nmeas,
  groupData=[subjNums' cubeSPM(:,:,meas)];
  mat2txt([deblank(measureNames(meas,:)) ...
           '_subject_means.txd'], h,groupData);
end

fprintf('DONE.'); 
fprintf('\n~ END %s ~ \n\n', prog_name); 

return

