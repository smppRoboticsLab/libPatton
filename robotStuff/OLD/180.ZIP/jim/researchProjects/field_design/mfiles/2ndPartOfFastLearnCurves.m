% ____ finalize plot ____
fprintf('\nFinalizing plot & printing to a file..'); 
subplot(3,ceil(Nmeas/3),1);
ax=axis; lgndX=.1*(ax(2)-ax(1));
for i=1:length(trialsStruct)                          % loop for exp phase
  mkr=[colors(i) 'o']; 
  lgndY=ax(3)+.98*(ax(4)-ax(3))-.03*i*(ax(4)-ax(3));
  plot(lgndX,lgndY,mkr,'markersize',mkrSz); hold on
  text(lgndX,lgndY,['  ' trialsStruct(i).name],'fontsize',fsz);
end % END for i
drawnow; pause(.001);
suptitle(['Learning curves for ' cd]);
print -depsc2 FastLearnCurves

% ____ GROUP the DATA for Barcharts ____
temp=[]; barMeans=[]; barStd=[];
for i=1:length(trialsStruct(3).trials)
  temp=[temp; EM(trialsStruct(3).trials(i),:)];
end
barMeans=[barMeans; mean(temp)];
barStd=[barStd; std(temp)];
bar95Width=[bar95Width; confidence(temp,.95)];

temp=[]; 
for i=1:length(trialsStruct(7).trials)
  temp=[temp; EM(trialsStruct(7).trials(i),:)];
end
barMeans=[barMeans; mean(temp)];
barStd=[barStd; std(temp)];
bar95Width=[bar95Width; confidence(temp,.95)];

temp=[]; 
for i=1:length(trialsStruct(8).trials) 
  temp=[temp; EM(trialsStruct(8).trials(i),:)];
end
barMeans=[barMeans; mean(temp)];
barStd=[barStd; std(temp)];
bar95Width=[bar95Width; confidence(temp,.95)];

% ____ make the Barcharts ____
figure(2); clf;
C=colorcube(8); C=C(4:8,:); 
for meas=1:Nmeas,
  meas
  subplot(3,ceil(Nmeas/3),meas)
  multbar3(barMeans(:,meas),1,C,str2mat(' '),...
           0.2,0.2,bar95Width(:,meas));
  title(measureNames(meas,:));
end % END for meas

suptitle(['Error measures for ' cd]);
orient landscape
print -dpsc2 barchart                     % print to a file
