%************** MATLAB "M" function  *************
% test & compare Figural error, velocity inner product, and 
% SYNTAX:      
%  -7777,trial,samplingRate(Hz),field_on(1=yes; 0=no),0,0
%  -7777,field_type(1=stiff,2=visc,3=inertial),Gain_xx,Gain_xy,Gain_yx,Gain_yy
% REVISIONS:    2/8/2000  (patton) INITIATED
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function EM=FastLearnCurves()

% ____ SETUP ____
prog_name='FastLearnCurves.m';            % name of this program
fprintf('\n~ %s ~ ', prog_name); 
set_params;                               %
drawnow;
verbose=1; plotIt=1;                      % switches for display
fsz=8;                                    % font size
mkrSz=2;                                  % marker size
names=[];
spacing=0.005;                            % figural error
cutoff=10;
colors='cgrybmcgrybm';
lastPhaseTrial=0;                                       % init
measureNames=str2mat(                               ... % measure names
     'Resampled Figural error',                     ... %
     'Infinity Norm',                               ... %
     'initial direction error'                      ... %
     );
Nmeas=size(measureNames,1);
for i=1:Nmeas+1
  figure(i);clf; put_fig(i,(i-1)*.2,.6,.3,.35);       % setup figure window
end
   
%__ GET MVMTS "DESIRED" OF EXPERIMENTER __
for Dir=1:nDirs
  fName=['sin-morphed.txd'];
  if verbose, 
    fprintf('\nLoad "Desired" (%s)',fName); 
    fprintf(', direction %d...',Dir); 
  end
  rhoD{Dir}=getIdealTrajectory(fName,L              ... %
    ,startPt,Dirs(Dir)*pi/180-pi,Mag,deflection     ... %
    ,speedThresh,0);
  if verbose, fprintf('Done. '); end
end
 
% ____ LOOP for EACH PHASE & TRIAL  ____
for phase=1:2,
  fprintf('\n\nPhase %d Trials:\n~~~~~~\n',phase); 
  load trialsStruct
  for trial=1:size(trialData,1) 
    fprintf(' %d',trial); 
    if trial/10==round(trial/10), fprintf('\n'); end
    
    % ____ load TRAJECTORY ____
    filename=['FD-' num2str(trial) '.dat'];
    %[D,v1,v2]=loadDataman(filename,verbose);   
    [D,F,Hz]=loadRobotData(filename,cutoff,~verbose);
    t=0:size(D,1)-1; t=t./Hz; t=t'; D=[t D]; % add time col
    
    % ____ Find the direction for IDEAL TRAJECTORY ____
    subjCSdirection=trialData(trial,7)+180;
    if subjCSdirection>360, 
      subjCSdirection=subjCSdirection-360; 
    end
    fprintf('\n direction: %f ',trialData(trial,7));
    fprintf('\n direction in Subj Coords: %f ',subjCSdirection);
    trialData(trial,7)
    for Dir=1:nDirs,                                        % determine direction
      Dir,Dirs(Dir)
      if trialData(trial,6)==Dirs(Dir); 
        fprintf('\n Match for direction %d. ',Dir)
        break; 
      end
    end
    d=getTrajectory('sin-morphed.txd'                   ... % nominal (ideal) traj
     ,L,Dirs(Dir)/180*pi,Mag,startPt);

    % __plot ENVIRONMENT __
    figure(1); clf
    for i=-.1:.01:pi+.1,                                    % setup arc of workspace
      tempX=[tempX; sum(L)*cos(i)];  
      tempY=[tempY; sum(L)*sin(i)];
    end
    plot(tempX,tempY,'g'); 
    hold on; axis image; % axis off;
    ellipse(-.2,0,.2,.2/3,0,20,[.8 .8 .9]);                 % body
    plot(-.2,.2/3,'^');                                     % nose triangle
    ellipse(-.2,0,.2/4,.2/3,0,20,'k');                      % head 
    plot(0,0,'o');                                          % shoulder joint

    % __plot current trial__
    plot(d(:,2),d(:,3),'r.', D(:,2),D(:,3),'b.')
    drawnow; pause(.001)
    
    % ____ MEASURES ____
    [FigErr,InfNorm]=figuralError(d(:,1:3),...
       D(:,1:3),spacing,~verbose,~plotIt); 
    InitDirErr=initial_direction_error(d(:,2:3),...
       D(:,2:3),.25,~verbose,~plotIt);
    EM(trial,:)=[FigErr InfNorm InitDirErr];                % stack into EM matrix

    % ___ LOOP thru each measure and plot ___
    Nmeas=size(EM,2);
    for meas=1:Nmeas,
      mkr='ks';                                             % init
      for i=1:length(trialsStruct)                          % loop for exp phase
        for j=1:length(trialsStruct(i).trials)              % loop for trials in phase list 
          if trial==trialsStruct(i).trials(j),  
            mkr=[colors(i) 'o']; 
            break
          end
        end % END for j
      end % END for i
      figure(meas+1); %subplot(3,ceil(Nmeas/3),meas)
      cumTrial=lastPhaseTrial+trial;                        % cumulative trials
      plot(trial,EM(cumTrial,meas),mkr,'markersize',mkrSz);
      if trial==1, 
        hold on; set(gca,'fontsize',fsz); 
        title(deblank(measureNames(meas,:)));
        xlabel('trial','fontsize',fsz);
      end
      
    end % END for meas
    
    drawnow; pause(.001);
    EM, return
  
  end % END for trial
  fprintf('\nDONE with trials for phase %d. ',phase); 
  if phase==1;
    cd part2
    cd 
  end % END if phase
end % END for phase

% ____ store file ____
fprintf('\nStoring data..'); 
save EM EM -ascii -double -tabs 
h=['Measures of performance (& error) for ' cd]; 
h=str2mat(h,... 
  ['Generated by ' prog_name ', ' whenis(clock)],... 
  '____data:____');
col_labels=deblank(measureNames(1,:)); 
for meas=2:Nmeas,  
  col_labels=[col_labels setstr(9) ... 
      deblank(measureNames(meas,:))]; 
end % END for meas 
h=str2mat(h,col_labels); 
mat2txt([prog_name '_results.txd'],h,EM); 


fprintf('\n~ END %s ~ ', prog_name); 
