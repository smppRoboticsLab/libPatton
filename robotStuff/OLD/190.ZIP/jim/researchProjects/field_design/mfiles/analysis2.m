%************** MATLAB "M" function  *************
% analyze data, part 2: learning curves
% SYNTAX:      
% REVISIONS:    9-1-00 INITIATED from fastLearnCurves (patton) 
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~

function analysis2(plotIt)

% __SETUP__
prog_name='analysis2.m';                                  % name of this program
fprintf('\n~ %s ~ ', prog_name); 
if ~exist('plotIt'), plotIt=1; end                        % if not passed
set_params;                                               % set plethora o params
fsz=8;                                                  % font size
mkrSz=2;                                                % marker size
colors='mcrgby';
for i=1:2%Nmeas+1
  figure(i);clf; put_fig(i,(i-1)*.25,.25,.27,.67);         % setup figure windows
end

% __LOAD__
fprintf('\nLoading data..')
[EMh,EM]=hdrload('performMeas.txd');                      % LOAD MEASURES
colLabels=EMh(size(EMh,1),:);                             % GET MEAURE NAMES
colNames=parse(colLabels);                                % GET MEAURE NAMES
[Ntrials,Nmeas]=size(EM);                                 % dimensions
measureNames=colNames(3:Nmeas,:)  
Nmeas=Nmeas-2;                                            % DONT COUNT 1st 2COLs
fprintf('.DONE. %d measures, %d trials. ',Nmeas,Ntrials); % display
load trialsStruct
partSwitch=1;

%___LOOP FOR TRIALS___
for cumTrial=1:Ntrials,
  trial=EM(cumTrial,1);
  part=EM(cumTrial,2);
  if (partSwitch &  part==2),                                 
    cd part2                                              % goto Part2directory
    pwd
    load trialsStruct; 
    partSwitch=0;
    for meas=1:Nmeas,
      subplot(Nmeas,1,meas)
      ax=axis;plot([cumTrial cumTrial],[ax(3) ax(4)],'k:')% 
    end
    colors='rgbymc';
  end
  

  % ___ PLOT MEASURES ON LEARN CURVES___
  for meas=1:Nmeas,
    mkr='ks';                                             % init
    for i=1:length(trialsStruct)                          % loop for exp part
      for j=1:length(trialsStruct(i).trials)              % loop for trials in part list 
        if trial==trialsStruct(i).trials(j),  
          mkr=[colors(i) 'o']; 
          break
        end
      end % END for j
    end % END for i
    %figure(meas+1); 
    figure(2); 
    %subplot(3,ceil(Nmeas/3),meas)
    subplot(Nmeas,1,meas)
    plot(cumTrial,EM(cumTrial,meas+2),mkr,'markersize',mkrSz);
    if trial==1, 
      hold on; set(gca,'fontsize',fsz); 
      title(deblank(measureNames(meas,:)));
      xlabel('Trial','fontsize',fsz);
    end
  end % END for meas
  if trial/25==round(trial/25),drawnow;pause(.001);end    % update display every 10
    
end % END for trial

  
% ____ finalize plot ____
fprintf('\nFinalizing plot & printing to a file..'); 
subplot(3,ceil(Nmeas/3),1);
ax=axis; lgndX=.1*(ax(2)-ax(1));
for i=1:length(trialsStruct)                              % loop for exp part
  mkr=[colors(i) 'o']; 
  lgndY=ax(3)+.98*(ax(4)-ax(3))-.03*i*(ax(4)-ax(3));
  plot(lgndX,lgndY,mkr,'markersize',mkrSz); hold on
  text(lgndX,lgndY,['  ' trialsStruct(i).name],'fontsize',fsz);
end % END for i
drawnow; pause(.001);
suptitle(['Learning curves for ' cd]);

fprintf('\nFinalizing plot & printing to a file..'); 
cd ..
print -depsc2 learnCurves

fprintf('DONE.'); 
fprintf('\n~ END %s ~ \n\n', prog_name); 

