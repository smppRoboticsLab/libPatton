
function [St,len]=startAndLength(v,len);

speed_thresh_for_move=.15;

  speed=sqrt(v(:,1).^2+v(:,2).^2);
  for St=4:length(v(:,1))                         % Loop for each v time sample
    if speed(St)>speed_thresh_for_move, break; end; % find where mvmt begins
  end
  if St+len>length(v(:,1))-2,                     % if amount to eval exceeds length
    len=length(v(:,1))-St-2;                      % reduce len (# frames to eval)
  end
  
  
  
  