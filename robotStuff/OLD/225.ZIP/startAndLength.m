%************** MATLAB "M" function  *************
% find the starting frame and ending frame of a movement, based on velocity threshold
% SYNTAX:     
% REVISIONS:  10-25-0 renamed performMeas.m
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~~~~~~~~~~


function [St,len]=startAndmaxLength(v,maxLen,speedThresh);

if ~exist('speedThresh'), speedThresh=.1, end    % if not passed

speed=sqrt(v(:,1).^2+v(:,2).^2);                  % speed calc
for St=4:length(v(:,1))                           % Loop for each v time sample
  if speed(St)>speedThresh, break; end;           % find where mvmt begins
end
if St+maxLen>length(v(:,1))-2,                    % if amount to eval exceeds maxLength
  len=length(v(:,1))-St-2;                        % reduce len (# frames to eval)
else
  len=maxLen;
end



