% ************** MATLAB "M" script (jim Patton) *************
% put CC fit results together and plot.
% SYNTAX:   
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~

% __ SETUP __
%if ~exist('CCfitData.txd');
  D=[]; 
  for i=30:33, 
    eval(['cd pilot' num2str(i)]); 
    cd; [h,d]=hdrload(filename); 
    D=[D; i*ones(size(d,1),1) d]; 
    
    for j=1:3
      [N,X]=hist(d(:,4+j));
      subplot(3,4,(i-30)*3+j); 
      bar(X,N);
      if j==1, axis([0 100 0 10]), end
    end
    eval('cd ..');  
  end% for i
  H=str2mat('Compiled CC fit measures',...
            ['Patton, ' whenis(clock)], ...
            sprintf('subj#\t%s',h(size(h,1),:)) ) ;
  mat2txt('CCfitData.txd',H,D);
%end % END if ~exist..

[H,D]=hdrload('CCfitData.txd');

i=1; 
while i<size(D,1)
  subj=D(i,1);
  


end % END while i