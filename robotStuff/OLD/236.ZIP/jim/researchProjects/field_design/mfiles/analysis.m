%************** MATLAB "M" fcn ************
% batch file to Analyze data
% SYNTAX:     analysis 
% REVISIONS:  10/25/00 (patton) INITIATED
%~~~~~~~~~~~~~~~~~~~~~ Begin : ~~~~~~~~~~~~~~~

function analysis(verbose)
fprintf('\n~ Analysis.m (analysis function) ~')

% __SETUP__
CI=.95;
doPlot=2; 
doPrint=1;
Hz=100;
analFrames=findInTxt('parameters.txt',          ... % duration of the force field
        'force field duration=')*Hz;                % 
deflection=findInTxt('parameters.txt',          ... % desired bend in trajectory
        'trajectory deflection=');                  % 

% __ANALYSIS__
plotIFDForces
disp('  menu...  ')
if (menu('do ensembles? ','no','yes')-1)
  doEnsembles2(CI,deflection);                      % ensemble avg's and plot
end
performMeas(doPlot,doPrint,analFrames,deflection);  % performance measures
learnCurves(doPlot);                                % learning curves 
stats(doPlot)                                       % statistical summary & plot

playwav('done.wav')
fprintf('\n~ END Analysis.m  ~ \n')
