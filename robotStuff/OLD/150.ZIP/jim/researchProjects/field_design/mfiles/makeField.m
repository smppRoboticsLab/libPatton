% ************** MATLAB "M" script (jim Patton) *************
% create robot control babis from data using copycat, & save.
% SYNTAX:    makeField(baseList,trialList,plotit,verbose)
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  11/2/99  pulled from pilot12 to main mfiles Dirsect.
%                     Changed from make_filed to makeField.m
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~

% __ SETUP __
global DEBUGIT M L R g EPpas Kpas Bpas field_gain field_type
global RCB rc
if ~exist('plotit'), plotit=1; end                      % if not passed
diary makeField.log                                     % keep record of this
fprintf('\n ~ makeField.m script: ~ \n')                % message
set_params                                              % setup most values 

% __ put header on output file __                             
textappend('Copycat Bootstratp Data','CCfit.txd');      % create a line of text
textappend(['Patton, 'whenis(clock)],'CCfit.txd');
textappend('See "makeField.m"','CCfit.txd');
Str=sprintf(['NumCCB\tCCr\tCCaveErr\tCCfracErr'      ...
            '\tvCCr\tvCCaveErr\tvCCfracErr']);
textappend(Str,'CCfit.txd');  

% __ PLOT part 1 trials__                             
if ~exist('trajectories.ps'),
  figure(1); plot_trials4([],0)
end

% __ Ensemble Average some baseline trials __
fprintf('\nBaseline Ensembles:');
clf
baseList=[]; % init
for D=1:nDirs
  fprintf(['\nFor the %d degree Dirsection '        ...
    'in robot coordinates:'],Dirs(D));
  outName=['baseline' num2str(Dirs(D)) '.dat']; 
  if ~exist('baseList.txd'),
    dirCount=0;
    for i=startTrial:max(trialsStruct(1).trials),   
      if trialData(i,7)==Dirs(D); 
        dirCount=dirCount+1;
        baseList(D,dirCount)=trialData(i,1); 
      end     % add trial to list
    end % for i
    baseList(D,:)
    ensembleTrials(baseList(D,:),outName); 
  else
    fprintf('\n (Ensemble "%s" already done)',outName)
    load 'baseList.txd'
  end % END if ~exist
  %disp(' pausing ..');   pause
end % END for D  
hdr=str2mat('% list of baseline trials.',           ... %
            '% Each column is a direction');        ... %
mat2txt('baseList.txd',hdr,baseList);
fprintf(' Ensebles DONE (see "baseList.txd"). ') 
baseList
load trialsStruct
trialsStruct(2).trials=trialsStruct(2).trials(1:8);    % for debug

NperturbTrials=length(trialsStruct(2).trials);
trialCut=ceil(NperturbTrials/2);                        % find half of the trials
perturbTrials=trialsStruct(2).trials(1:trialCut);
validationTrials=                                   ... % 
  trialsStruct(2).trials(trialCut+1:NperturbTrials);
fprintf('\n%d perturbation trials :',NperturbTrials); 
fprintf(' %d',trialsStruct(2).trials);

% ___ FIT COPYCAT ___
fprintf('\n\n\n ___ Begin Fitting CCBs: ___: '); 
for i=1:NperturbTrials                                  % jacknife iterations
  fprintf('\n\n\n\n~~~ Jacknife Iteration %d: ~~~',i);  %
  fprintf('\n  %d Fitting trials    :',             ... %
   length(perturbTrials)); 
  fprintf(' %d',perturbTrials);
  fprintf('\n  %d Validation trials :',             ... %
   length(validationTrials)); 
  fprintf(' %d',validationTrials);
  
  fprintf('\n\n  Fitting: ');
  CCB=[];
  CCB=setupCopycat3(CCB,M,L,R,Kact,Bact,0,0         ... % initialize copycat bases
                    ,CCwings,spreadScale)               %
  [CCB,CCr,CCaveErr,CCfracErr]=                     ... % fit copycat model 
    ccFit8(CCB,maxTime,perturbTrials,fitIt,CCwings);            
  
  fprintf('\n\n  Validation: '); 
  [CCB,vCCr,vCCaveErr,vCCfracErr]=                  ... % check copycat model
    ccFit8(CCB,maxTime,validationTrials,~fitIt);
  
  Str=sprintf(                                      ... %
   '%d\t%0.5g\t%0.5g\t%0.5g\t%0.5g\t%0.5g\t%0.5g',  ... %
   length(CCB),CCr,CCaveErr,CCfracErr,              ... % 
   vCCr,vCCaveErr,vCCfracErr);
  textappend(Str,'CCfit.txd');
  perturbTrials=[perturbTrials validationTrials(1)];    % move 1st to end of other list
  validationTrials=[validationTrials perturbTrials(1)]; % move 1st to end of other list
  perturbTrials(1)=[];                                  % clip 1st off
  validationTrials(1)=[];                               % clip 1st off
end                                                     % END for i

fprintf('\n END CopyCat processing. \n '); 

% __ FINAL ___
diary off                                               % 
playwav('done.wav');                                    % play sound       
return 

% __ RC FIELD DESIGN __
fprintf('\n ___ REGIONAL CONTROL BASES (RCB): ___: '); 
widths=[]; centers=[];                                  % init
if 1,
  for i=1:nDirs
    widths(i)=1.3*Mag;
    centers(i,:)=startPt+0.3*Mag*[cos(Dirs(i)/180*pi)...
                                sin(Dirs(i)/180*pi)];
  end
  widths(i+1)=1.8*Mag; centers(i+1,:)=startPt;
  setupRCB(widths,centers);                             %
else
  setupRCB(1.9*Mag,startPt)
end
[RCB,rcr]=rcFit8(CCB,maxTime,startPt,Dirs,Mag,deflection);
field_gain=zeros(2,2); 
for i=1:length(RCB), 
  field_gain=field_gain+RCB(i).rc*RCB(i).B; 
end; 
field_type='viscous'; 
figure(2); clf; field_plot(8); axis equal
title('field at centerpoint')

saveRCB
save RCB RCB

% __ FINAL ___
fprintf('\n ~ END makeField.m ~ \n');                   %  
diary off                                               % 
playwav('done.wav');                                    % play sound      
return

