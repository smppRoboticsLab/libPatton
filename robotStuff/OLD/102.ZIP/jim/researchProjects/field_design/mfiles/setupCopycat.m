%___________________*** MATLAB "M" script (jim Patton) ***____________________
% Sets up parameters for the copycat basis functions for 2-joint link & controller:
%
%                                                     phi2  `
%            o==>F                                 o==>F   `
%             \                                     \     `                
%             (m2)                                  (m2) `                      
%               \  q2                                 \ `               
%                o ` ` ` ` `                          o     
%               /                                    /           
%             (m1)                                 (m1)    phi1        
%             / q1                                 / 
%          __o___` ` ` ` ` `                    __o___` ` ` ` ` `  
%          \\\\\\\                              \\\\\\\                 
%
% VERSIONS:	  INITIATED 11/17/99 by patton, split off from set_params.m
%
%__________________________________ BEGIN: ____________________________________


fprintf('\n ~ setupCopycat.m script ~ ')

if ~exist('winner'), winner=0; end
if ~exist('spreadScale'), spreadScale=1; end

% ___ COPYCAT BASIS (CCB) PARAMETERs ___
for i=1:37                                  % init. best guess into all CCB's  
  if winner                                 % if recently there was a best fit CCB
    CCB(i).M=CCB(winner).M;    
    CCB(i).L=CCB(winner).L;   
    CCB(i).R=CCB(winner).R;   
    CCB(i).K=CCB(winner).K; 
    CCB(i).B=CCB(winner).B; 
    CCB(i).X=CCB(winner).X;    
    CCB(i).Y=CCB(winner).Y;
  else                                      % otherwise, use default
    CCB(i).M=M;    CCB(i).L=L;   CCB(i).R=R;   
    CCB(i).K=Kact; CCB(i).B=Bact; 
    CCB(i).X=0;    CCB(i).Y=0;
  end  
end

%__ Now vary each param in 1 direction __
impedanceSpread=.3;                          % fractional plus or minus amount 
massSpread=.1;                               % fractional plus or minus amount 
geometrySpread=.025;                         % absolute plus or minus amount 
shoulderSpread=.01;                          % absolute plus or minus amount 
CCB(1).M(1,1)=CCB(1).M(1,1)*(1+massSpread*spreadScale);            
CCB(2).M(1,1)=CCB(2).M(1,1)*(1-massSpread*spreadScale);     
CCB(3).M(1,2)=CCB(3).M(1,2)*(1+massSpread*spreadScale);
CCB(4).M(1,2)=CCB(4).M(1,2)*(1-massSpread*spreadScale);
CCB(5).M(2,1)=CCB(5).M(2,1)*(1+massSpread*spreadScale);
CCB(6).M(2,1)=CCB(6).M(2,1)*(1-massSpread*spreadScale);
CCB(7).M(2,2)=CCB(7).M(2,2)*(1+massSpread*spreadScale);
CCB(8).M(2,2)=CCB(8).M(2,2)*(1-massSpread*spreadScale);
CCB(9).R(1)=CCB(9).R(1)*(1+geometrySpread/2*spreadScale);
CCB(10).R(1)=CCB(10).R(1)*(1-geometrySpread/2*spreadScale);
CCB(11).R(2)=CCB(11).R(2)*(1+geometrySpread/2*spreadScale);
CCB(12).R(2)=CCB(12).R(2)*(1-geometrySpread/2*spreadScale);
CCB(13).L(1)=CCB(13).L(1)*(1+geometrySpread*spreadScale);
CCB(14).L(1)=CCB(14).L(1)*(1-geometrySpread*spreadScale);
CCB(15).L(2)=CCB(15).L(2)*(1+geometrySpread*spreadScale);
CCB(16).L(2)=CCB(16).L(2)*(1-geometrySpread*spreadScale);
CCB(17).B(1,1)=CCB(17).B(1,1)*(1+impedanceSpread*spreadScale);
CCB(18).B(1,1)=CCB(18).B(1,1)*(1-impedanceSpread*spreadScale);
CCB(19).B(2,2)=CCB(19).B(2,2)*(1+impedanceSpread*spreadScale);
CCB(20).B(2,2)=CCB(20).B(2,2)*(1-impedanceSpread*spreadScale);
CCB(21).B(2,1)=CCB(21).B(2,1)*(1+impedanceSpread*spreadScale);
CCB(21).B(1,2)=CCB(21).B(1,2)*(1+impedanceSpread*spreadScale);% SYMMETRIC, SO KEEP THE SAME CCB
CCB(22).B(2,1)=CCB(22).B(2,1)*(1-impedanceSpread*spreadScale);        
CCB(22).B(1,2)=CCB(22).B(1,2)*(1-impedanceSpread*spreadScale);% SYMMETRIC, SO KEEP THE SAME CCB
CCB(23).K(1,1)=CCB(23).K(1,1)*(1+impedanceSpread*spreadScale);
CCB(24).K(1,1)=CCB(24).K(1,1)*(1-impedanceSpread*spreadScale);
CCB(25).K(2,2)=CCB(25).K(2,2)*(1+impedanceSpread*spreadScale);
CCB(26).K(2,2)=CCB(26).K(2,2)*(1-impedanceSpread*spreadScale);
CCB(27).K(2,1)=CCB(27).K(2,1)*(1+impedanceSpread*spreadScale);
CCB(27).K(1,2)=CCB(27).K(1,2)*(1+impedanceSpread*spreadScale);% SYMMETRIC, SO KEEP THE SAME CCB
CCB(28).K(2,1)=CCB(28).K(2,1)*(1-impedanceSpread*spreadScale);
CCB(28).K(1,2)=CCB(28).K(1,2)*(1-impedanceSpread*spreadScale);% SYMMETRIC, SO KEEP THE SAME CCB
CCB(29).X=CCB(29).X-shoulderSpread*spreadScale;            
CCB(30).X=CCB(30).X+shoulderSpread*spreadScale;            
CCB(31).Y=CCB(31).Y-shoulderSpread*spreadScale;            
CCB(32).Y=CCB(32).Y+shoulderSpread*spreadScale;    

CCB(33).X=CCB(33).X-shoulderSpread;            
CCB(33).Y=CCB(33).Y-shoulderSpread;            

CCB(34).X=CCB(34).X+shoulderSpread;           
CCB(34).Y=CCB(34).Y-shoulderSpread;            

CCB(35).X=CCB(35).X+shoulderSpread;            
CCB(35).Y=CCB(35).Y+shoulderSpread;        

CCB(36).X=CCB(36).X-shoulderSpread;         
CCB(36).Y=CCB(36).Y+shoulderSpread;                             

CCB                                           % Note: final CCB is "best guess"

fprintf(' ~ END setupCopycat.m script ~ \n')
