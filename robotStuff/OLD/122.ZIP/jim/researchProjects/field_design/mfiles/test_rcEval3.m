% ************** MATLAB "M" script (jim Patton) *************
% 
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~~~

% SETUP: 
clf
i=0;
for X=-.25:.03:.15,
  for Y=.1:.03:.7,
    i=i+1;
    test(i,:)=[X,Y,5,5];
  end
end

% test using:  
F=zeros(length(test),2);
for i=1:length(RCB),
  F=F+rcEval3(test,RCB(i),0);
  fprintf('.')
  plot(RCB(i).C(1),RCB(i).C(2),'.'); hold on
end
quiver(test(:,1),test(:,2),F(:,1),F(:,2));
axis equal


% or
clf
for i=1:length(RCB), 
    plot(RCB(i).C(1),RCB(i).C(2),'r.'); hold on
end
axis equal
F=rcEval3(test,RCB(5),0);
quiver(test(:,1),test(:,2),F(:,1),F(:,2));
plot(rho(:,1),rho(:,2),'g','linewidth',2)

% or use
F=rcEval3(test,RCB(5),0)+rcEval3(test,RCB(30),0)+rcEval3(test,RCB(50),0);
