% ************** MATLAB "M" script (jim Patton) *************
% put CC fit results together and plot.
% SYNTAX:   
% INPUTS:    
% OUTPUTS:  
% VERSIONS:  
%~~~~~~~~~~~~~~~~~~~~~~ Begin Program: ~~~~~~~~~~~~~~~~~~~~~~~~

%___SETUP___
scriptName='assembleAnalResults.m';
if(menu('choose:','homogenious','opto')-1),
  analysisName='OptoBatch';
else
  analysisName='CCanalHomogenous';
end
fprintf('\n*~ %s ~* \n', scriptName)
figure(1); clf
cd 
fsz=9;
varName=str2mat('VAF (r^2)','Ave Force Err (fraction of max)','Processing time (s)');
cols=[5 6 8];

  % _____ subject data _____
  D=[]; 
  AVG=[];
  for i=30:34, % subj loop
    eval(['cd pilot' num2str(i)]); 
    filename=['pilot' num2str(i) analysisName '.m.txd']
    cd; [h,d]=hdrload(filename); 
    varName=parse(h(size(h,1),:));
    D=[D; i*ones(size(d,1),1) d]; 
    AVG=[AVG; i mean(D)];
    for j=1:3 % measure loop
      [N,X]=hist(d(:,cols(j)));
      subplot(5,3,(i-30)*3+j); bar(X,N); 
      switch j
      case 1,          
        ylabel(['subject ' num2str(i) ],'fontsize',fsz,'fontweight','bold')
        axis([0 1 0 25])
      case 2,         
        axis([0 .025 0 25])
      case 3,         
        axis([0 3600 0 25])
      end % END switch
      set(gca,'fontsize',fsz); drawnow; 
      if i==30, 
        title(deblank(varName(cols(j),:)),'fontsize',fsz,'fontweight','bold')
      end      
      set(textOnPlot(['(mean=' num2str(mean(X),3) ')'],.05,.9),'fontsize',fsz); 
    end
    eval('cd ..');  
    %disp(' pause. . . ');    pause
  end% for i
  
  suptitle([analysisName ' Histograms']) 
  eval(['print -dpsc2 ' analysisName '.ps']);

% _____ summary data _____
figure(2); clf
for j=1:3 % measure loop
  subplot(3,3,j); 
  [N,X]=hist(D(:,cols(j)+1));
  bar(X,N); 
  set(gca,'fontsize',fsz); drawnow; 
  switch j
  case 1,     axis([0 1 0 60]), 
    ylabel('all subjects','fontsize',fsz,'fontweight','bold'); 
  case 2,     axis([0 .025 0 60]), 
  case 3,     axis([0 3600 0 60]), 
  end % END switch j
  title(deblank(varName(cols(j),:)),'fontsize',fsz,'fontweight','bold')
  set(textOnPlot(['(mean=' num2str(mean(X),3) ')'],.05,.9),'fontsize',fsz); 
end

  % _____ simulation data _____
  for i=35:36, % subj loop
    eval(['cd pilot' num2str(i)]); 
    filename=['pilot' num2str(i) 'CCanalHomogenous.m.txd'];
    cd; [h,d]=hdrload(filename); 
    varName=parse(h(size(h,1),:));
    D=[D; i*ones(size(d,1),1) d]; 
    AVG=[AVG; i mean(D)];
    for j=1:3 % measure loop
      [N,X]=hist(d(:,cols(j)));
      subplot(3,3,(i-34)*3+j); bar(X,N); 
      set(gca,'fontsize',fsz); drawnow; 
      switch j
      case 1,          
        if i==35, ylabel('Noisy model','fontsize',fsz,'fontweight','bold'); end
        if i==36, ylabel('Plain model','fontsize',fsz,'fontweight','bold'); end
        ylabel(['subject ' num2str(i) ],'fontsize',fsz,'fontweight','bold')
        axis([0 1 0 25])
      case 2,         
        axis([0 .025 0 25])
      case 3,         
        axis([0 3600 0 25])
      end % END switch
      set(textOnPlot(['(mean=' num2str(mean(X),3) ')'],.05,.9),'fontsize',fsz); 
    end
    eval('cd ..');  
  end% for i
  H=str2mat('Compiled CC fit measures',...
            ['Patton, ' whenis(clock)], ...
            sprintf('subj#\t%s',h(size(h,1),:)) ) ;
          mat2txt([analysisName '.txd'],H,D);
          H=str2mat(H,'AVERAGES FOR EACH SUBJECT')
  mat2txt([analysisName '.txd'],H,AVG);
  
  suptitle([analysisName ' Histograms']) 
  eval(['print -dpsc2 -append ' analysisName '.ps']);

fprintf('\n~ END %s ~\n', scriptName)
return
