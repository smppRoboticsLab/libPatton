%X:\programs\mfiles\contrib\eztools as of 8/24/1998 at 12:33:13
%arrow.m                              arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16, ...                         
%axiscall.m   % This function is a callback for makemenus.                                       
%crsshair.m   %         crsshair                                                       
%degrees.m   % d = degrees(r)                     
%ezarrow.m   %                                                                                                 
%ezaxes.m   %                                                                           
%ezlabels.m   %                                                                              
%ezlegend.m   %                                                                                
%eztext.m   %                                                                              
%eztools.m   %  put up eztools menu on current plot                                        
%findcntr.m   %                                                            
%findfig.m   % function handle = findfig(FIGNAME)       
%gcm.m   %GCM    Return handle of current menu.           
%input2.m   %                                                                        
%isobj.m   % ISOBJ	True for objects                                
%movetext.m   % FUNCTION MOVETEXT(COMMAND)                                                
%ms2strv.m   %       str=ms2strv(mat)                                   
%myarrow.m   function h=myarrow()                                          
%pageset.m                                                                                                
%printerf.m   %   example:                                
%radians.m   % r = radians(d)                                 
%rot4x.m   % r = rot4x(theta)                                
%rot4y.m   % r = rot4y(theta)                                
%rot4z.m   % r = rot4z(theta)                                
%scalhand.m   %                                             
%sliderca.m   % This function is a sub callback for axiscall. 
%subzoom.m   % Written by : Doug Harriman                                            
%textcall.m   % This function is a callback for makemenus.                            
%textinpu.m   %                         
%trnslate.m   %                                                                    
%tsel.m   % This function, called with no arguments,              
%vec2str.m   %       string=vec2str(vector)                                         
%viewer.m   %function viewer()                                                
%vwrcback.m   % This function is a callback for viewer.                    
%workcall.m   %  because it modifies the workspace.  We know which function to
%wysiwyg.m   %WYSIWYG -- this function is called with no args and merely     
%zoom3d.m   % This function is meant to be called only from            
